--
-- PostgreSQL database dump
--

\restrict xaZQXDBDVVoh9zKwMdy0ZLTpmlaecfYRZqMoRCEOFsyhI2B7ErakRjPv1PSA2Kr

-- Dumped from database version 15.19
-- Dumped by pg_dump version 15.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttendanceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttendanceStatus" AS ENUM (
    'PRESENT',
    'ABSENT',
    'LATE',
    'EXCUSED',
    'VERY_LATE'
);


--
-- Name: DonationCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DonationCategory" AS ENUM (
    'FULL',
    'REDUCED',
    'EXEMPT'
);


--
-- Name: DonationPaymentAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DonationPaymentAction" AS ENUM (
    'CREATED',
    'UPDATED',
    'DELETED'
);


--
-- Name: GuardianStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."GuardianStatus" AS ENUM (
    'ACTIVE',
    'ARCHIVED'
);


--
-- Name: Sex; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Sex" AS ENUM (
    'MALE',
    'FEMALE'
);


--
-- Name: StudentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StudentStatus" AS ENUM (
    'WAITING_LIST',
    'ACTIVE',
    'ARCHIVED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp(3) without time zone,
    "refreshTokenExpiresAt" timestamp(3) without time zone,
    scope text,
    password text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" text NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    image text,
    role text DEFAULT 'teacher'::text NOT NULL,
    phone text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "mustChangePassword" boolean DEFAULT false NOT NULL
);


--
-- Name: Verification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Verification" (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_years (
    id text NOT NULL,
    name text NOT NULL,
    "startDate" date,
    "endDate" date,
    "isCurrent" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "classId" text NOT NULL,
    "sessionId" text NOT NULL,
    date date NOT NULL,
    status public."AttendanceStatus" NOT NULL,
    note text,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: class_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_comments (
    id text NOT NULL,
    "classId" text NOT NULL,
    "authorId" text,
    body text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: class_session_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_session_links (
    id text NOT NULL,
    "classId" text NOT NULL,
    "sessionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: class_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_sessions (
    id text NOT NULL,
    label text NOT NULL,
    day text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "endTime" text,
    "startTime" text
);


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "levelId" text NOT NULL,
    "roomId" text,
    "teacherId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: donation_payment_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_payment_logs (
    id text NOT NULL,
    "paymentId" text,
    "studentId" text NOT NULL,
    "academicYearId" text NOT NULL,
    action public."DonationPaymentAction" NOT NULL,
    "amountBefore" numeric(10,2),
    "amountAfter" numeric(10,2),
    "paidAtBefore" date,
    "paidAtAfter" date,
    note text,
    "actorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: donation_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_payments (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "academicYearId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    "paidAt" date NOT NULL,
    note text,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: donation_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_settings (
    id text DEFAULT 'default'::text NOT NULL,
    "defaultAmount" numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollments (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "classId" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDate" timestamp(3) without time zone,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: exams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exams (
    id text NOT NULL,
    "classId" text NOT NULL,
    "subjectId" text NOT NULL,
    "termId" text NOT NULL,
    "academicYearId" text NOT NULL,
    date date NOT NULL,
    coefficient integer DEFAULT 1 NOT NULL,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    title text NOT NULL
);


--
-- Name: grades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grades (
    id text NOT NULL,
    "studentId" text NOT NULL,
    score integer,
    remark text,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "examId" text NOT NULL
);


--
-- Name: guardian_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardian_comments (
    id text NOT NULL,
    "guardianId" text NOT NULL,
    "authorId" text,
    body text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: guardian_registration_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardian_registration_tokens (
    id text NOT NULL,
    "guardianId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: guardians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardians (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    address text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "donationNumber" text,
    "educationNumber" text,
    status public."GuardianStatus" DEFAULT 'ACTIVE'::public."GuardianStatus" NOT NULL,
    "enrolledAt" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "archivedAt" date
);


--
-- Name: levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.levels (
    id text NOT NULL,
    name text NOT NULL,
    "sortOrder" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: period_report_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.period_report_observations (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "termId" text NOT NULL,
    "academicYearId" text NOT NULL,
    body text NOT NULL,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: registration_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_settings (
    id text DEFAULT 'default'::text NOT NULL,
    "linkValidityDays" integer DEFAULT 30 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "archiveRetentionMonths" integer DEFAULT 24 NOT NULL
);


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rooms (
    id text NOT NULL,
    name text NOT NULL,
    capacity integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text
);


--
-- Name: student_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_comments (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "authorId" text,
    body text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: student_donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_donations (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "academicYearId" text NOT NULL,
    "expectedAmount" numeric(10,2) NOT NULL,
    category public."DonationCategory" DEFAULT 'FULL'::public."DonationCategory" NOT NULL,
    note text,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: student_guardians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_guardians (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "guardianId" text NOT NULL,
    relation text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: student_status_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_status_events (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "fromStatus" public."StudentStatus",
    "toStatus" public."StudentStatus" NOT NULL,
    "changedById" text,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    sex public."Sex",
    "dateOfBirth" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    image text,
    status public."StudentStatus" DEFAULT 'WAITING_LIST'::public."StudentStatus" NOT NULL,
    "enrolledAt" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "archivedAt" date
);


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subjects (
    id text NOT NULL,
    "levelId" text NOT NULL,
    name text NOT NULL,
    "sortOrder" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    image text
);


--
-- Name: terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms (
    id text NOT NULL,
    name text NOT NULL,
    "sortOrder" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "startMonth" integer NOT NULL,
    "endMonth" integer NOT NULL
);


--
-- Name: year_report_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.year_report_observations (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "academicYearId" text NOT NULL,
    body text NOT NULL,
    "recordedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
d6002f80-265a-428b-be09-6ab54601c67d	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	credential	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	\N	\N	\N	\N	\N	\N	d86b1b2797c82e7b60fcbde20be6fb43:a64fea3319652938c75d19b759f0e98aeb75ce5709be2ecb5f0785d7f3abf90cc76f438b8746a1361da8b2d708d2af37c8609573af3fc96f485ebac97631640a	2026-09-25 20:26:27.533	2026-09-25 20:26:27.533
abc2639f-2e15-4696-b2c1-1b1c04d585cf	4e130fd1-f214-4f10-bf5c-1c4b727d1930	credential	4e130fd1-f214-4f10-bf5c-1c4b727d1930	\N	\N	\N	\N	\N	\N	1dd3198f6f02df0deb3438d0e2843cce:5bac38633d184f4ca39322b5dca00eed211e4ed99f327ab5c61385001e5a224b383a69ad71e35c4dac2c4083771031fc20dd872614b100b0c1ffa71d2412c8f6	2026-10-02 20:54:18.807	2026-10-02 20:54:18.807
00104c71-14ea-461a-8832-67edd9de7aff	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	credential	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	\N	\N	\N	\N	\N	\N	242f914dc36338c1241a4cfa6b27aae0:79fc7f4f62b0b5b4dddc46618038ffb7cb6f0aa252ffca5f2f2f5ecfd919ce1249820a32624f2cfb88d99df734afd2f38724c9f9c2a588251c1f8e6bc3a58546	2026-10-17 10:24:08.744	2026-10-17 10:24:08.744
b91aa4ee-5537-49bf-91fb-a585c0a14b91	4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	credential	4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	\N	\N	\N	\N	\N	\N	da7dc857fe1ab2dbcb7dda976892f9a3:182869c06b6ba7510cccaf595c296ff942f7c68e7aedbcbd5fb8312040e9bfc6813b48598535fc0cd316ac485af5df049d9b5351d42cad2e0e611c3bc9702450	2026-10-17 10:39:45.005	2026-10-17 17:39:04.31
1d112b1b-3f9d-400a-a4b0-847d833b4305	7ec0c017-0360-4b28-85f0-d221049d853c	credential	7ec0c017-0360-4b28-85f0-d221049d853c	\N	\N	\N	\N	\N	\N	3982febd37ca161827d4b4cef9a8449c:6b0257765703388d0818ed870b29211aea42fff8a47b00da78936d75e07011444f174dafb70aa8a4fb8a6044d87e8663daca0fea05e77fe2ea85a2e723239d6e	2026-10-18 14:39:44.816	2026-10-18 14:39:44.816
b0a1344a-116e-4361-979f-40990e4e60a6	c58b9161-c77a-4b86-b6d0-40ada6443228	credential	c58b9161-c77a-4b86-b6d0-40ada6443228	\N	\N	\N	\N	\N	\N	ebb4f8299eecbbbc3b05020838619377:75f542e48fe755b94169f45d60d2f0cdef0fc3306f68b9bcefc062002222544554978429f66135a152aafe8525d6d6b6b5e98ec8f5b0b95f33657fa1b3702727	2026-10-18 14:41:16.426	2026-10-18 14:41:16.426
dbd4ff38-7644-4e60-85f8-0d83c3cc0e8f	75a28c9d-3d13-4e65-af64-d5686958c9db	credential	75a28c9d-3d13-4e65-af64-d5686958c9db	\N	\N	\N	\N	\N	\N	8660c70fff66e0dc528b5a63573e9322:4cc11e08076d9197b931771ff4a3ebaf9bcd434dbbe5ae7007318cec57a437fd9bfaae8f4c6665f2b4b9aee47162160a57f237a600b34c87a86b87b4d86fb790	2026-10-18 14:43:50.966	2026-10-18 14:43:50.966
7311b567-aeae-443e-bf50-599b34bf4111	127ebc4a-10f9-4cef-8397-b4e64cec18ae	credential	127ebc4a-10f9-4cef-8397-b4e64cec18ae	\N	\N	\N	\N	\N	\N	f7255dd7a921baa8779bc9a53a8d6e18:84a6464e10f2e8c4eb63033b041a3dbaf979446de77233657c43ade8320c9be9cb2608f2f5d4de6dace939e45014c7057a1bb12461764b0a9e94b28bd0d8c572	2026-10-18 14:44:49.19	2026-10-18 14:44:49.19
24fd2622-6031-4f06-b7f4-82e3eabe429d	b3bbf9e1-bb20-45b0-bc17-ae808a748173	credential	b3bbf9e1-bb20-45b0-bc17-ae808a748173	\N	\N	\N	\N	\N	\N	c03d184dd64b403469f52e215769bede:a59d6fa01c1eae5e91b841884b76fc369843dc9d09f69ab4697e92fcfc9e50f086543d695f21fd2a08706467953f6bc07c4890cb443bb0c5235af3e7f1a3fa5a	2026-10-18 14:46:05.523	2026-10-18 14:46:05.523
39c65044-1238-47b8-bfbb-3c038997a593	179fdc67-4f5c-4e79-ad8a-c26918615647	credential	179fdc67-4f5c-4e79-ad8a-c26918615647	\N	\N	\N	\N	\N	\N	279e0f5d1148d0d0b2bd200dcf5fdc7c:2ba91d856960cd2a5f945c157a69eaa48c83608b0b01bdc8171fbbc43d09fe5c3ddbb717017770e80840748ad9527a13cbff5773b00156b132d5c7c1e273e5d7	2026-10-18 14:48:16.049	2026-10-18 14:48:16.049
94aa7b5a-2c0f-4f30-b85b-f78f0758088f	b122adab-ea31-469e-a8c7-83b554aaa57a	credential	b122adab-ea31-469e-a8c7-83b554aaa57a	\N	\N	\N	\N	\N	\N	088254d419193869064b0ce5ffa3a669:a8996e9db00b83c74498b6d32ee7402af68490f7c939fa6b31783b9a4a835e6e0bdbd99aedad477987faacd95356df01edbc4c545b9843d016f20b4c713521dd	2026-10-18 14:49:15.455	2026-10-18 14:49:15.455
4b7dc5c2-159d-4376-b428-4bb942614e6e	a69e10b7-f6a6-44bc-aa38-d6587f3b6fe9	credential	a69e10b7-f6a6-44bc-aa38-d6587f3b6fe9	\N	\N	\N	\N	\N	\N	fd9ab3fc3444c78a930024911aa8a0d6:27cc2142d2a880b9af04fec141b00ae0f3f764192c76c048e0f03800f770184cdf323ec0261078fc5841e2e6a16676b6f0fc988a62bc4a12760ba64254c2dd80	2026-10-18 14:51:29.696	2026-10-18 14:51:29.696
43033a23-45ca-44ef-9b8f-55345821ec7c	e9c3b6cd-c6ac-405d-97cc-9b25ee91f2ad	credential	e9c3b6cd-c6ac-405d-97cc-9b25ee91f2ad	\N	\N	\N	\N	\N	\N	af9302fd6b965da18df415b7625d9d7d:e1986e4496552f0cf27b5b059e2dcdaaacdf62d6160b9deb24061898dc08fa610b7769de5530476daf58abd4630d32d86e2bbc21bb15b97cddbb2d5800ba8953	2026-09-25 21:02:38.459	2026-10-18 14:55:17.195
b45c2d5f-34f6-4591-b8f6-56f42bad853c	4f07d991-ee7e-4477-ae61-220cee7d59db	credential	4f07d991-ee7e-4477-ae61-220cee7d59db	\N	\N	\N	\N	\N	\N	78da04b464cd34ffe7b33629eed9456f:117389cbe1de5c8ce0983a67aeb44e62c2ee37902240d60249dc943a6cd48cd187bef59809888cd5765a040dd88e08b583ad41c1c29c3a24ae0ba0a58495f9e8	2026-10-22 13:11:17.182	2026-10-22 13:11:17.182
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId") FROM stdin;
Zbqoz9dk9lh6Z6QmgHvT5h2byZbxUthe	2026-10-02 21:46:23.522	gBzjvESrSfMNqOQvdoMI276eJ7xQbemH	2026-09-25 21:46:23.522	2026-09-25 21:46:23.522	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
UVhzWY1Cz7veSnBGHcdMRHweg7re9L10	2026-10-06 21:03:16.329	39pCLT8K9fzm0AbSxDv61If82BCkeJEK	2026-09-29 21:03:16.332	2026-09-29 21:03:16.332			c724d280-7f41-4b0f-bb24-fc29e1e7f73b
H7TXirxQLUzkUNIAcpjgR6fo15ubY5tI	2026-10-06 21:03:44.009	sHKYc6XoxcEvmHjjMWvRHt5R15pFLzSB	2026-09-29 21:03:44.01	2026-09-29 21:03:44.01	0000:0000:0000:0000:0000:0000:0000:0000	curl/8.7.1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
z3uqPkfiFIpMJuC8Fi2lpqRtRBihIQZj	2026-10-06 21:03:52.501	SLcr8Xi3TGs2UQ4EphrwtFsnlwlwIkL1	2026-09-29 21:03:52.502	2026-09-29 21:03:52.502	0000:0000:0000:0000:0000:0000:0000:0000	curl/8.7.1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
qa0uXyryXEGn9V3Xl5PnqFFSGxTrpZVW	2026-10-09 20:56:06.017	sfGAVeC4PduUd0GC715GmMpZ7t6W1YE4	2026-10-02 20:56:06.017	2026-10-02 20:56:06.017	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0.1 Safari/605.1.15	4e130fd1-f214-4f10-bf5c-1c4b727d1930
4ScogaTdezPhXfFt7toJ5uwEPftx7X0b	2026-10-15 18:59:30.583	rJ3ksIkL42X3dlw8jjlt8iHNZTgbbwSn	2026-10-02 19:52:29.905	2026-10-08 18:59:30.583	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
wWoPYsaAusbkgSdaFUW5SYG24LhwRnjY	2026-10-18 20:57:08.782	8re4N5Vel6zpRSzGKjIg5D3laTapCISD	2026-10-11 20:57:08.783	2026-10-11 20:57:08.783	0000:0000:0000:0000:0000:0000:0000:0000	curl/8.7.1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
1LBRC0bVXTfdWHgAClJtKi9HjkbGmkQU	2026-10-23 20:36:00.171	so6QEn9ETrQ2DcNbSGhX4r8yBvhHnfrZ	2026-10-11 19:29:40.474	2026-10-16 20:36:00.171	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
AGb03aht5TXSCpJPxfApNy0asa0ys7uQ	2026-10-23 20:43:34.212	P9YlqDqEXxhGahmX0jCXM3B1RmTJJB0r	2026-10-16 20:43:34.213	2026-10-16 20:43:34.213	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
Atl2K7467BEVi3dlG7JR1Ku136NyKNJH	2026-10-23 20:44:14	jpvOWa3x55sVhiMTLxgk5Y2osiYlz9MQ	2026-10-16 20:44:14	2026-10-16 20:44:14	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
l8b6I5NbSrtoy5ANgw5bhOblAfmqg7C1	2026-10-24 18:00:35.005	2Wesgxq7V2KwXVJmOqD9q1YFB4vippvk	2026-10-17 18:00:35.005	2026-10-17 18:00:35.005	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
9vdZrAWYGuigsFnMrZwx4qwlwg9JXi30	2026-10-24 18:11:15.055	F6wgWAsssX8FdQ2SJ2TcDkXAh5TGiSv0	2026-10-17 18:11:15.055	2026-10-17 18:11:15.055	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
G0GDVPVNSAbfSErQq881UuoWYnepIm65	2026-10-24 18:16:33.205	V6Yuv7bqtx4AYT26ZiVirho4kVHOTafM	2026-10-17 18:16:33.205	2026-10-17 18:16:33.205	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
9BVvQYVTsSEhruM0gzVyq61I60rBP8ws	2026-10-24 18:16:52.836	3F5IYRfUK2ZxnD3tecAf8T6Ii4CGOxwc	2026-10-17 18:16:52.837	2026-10-17 18:16:52.837	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
emAwllRfJ6p8AkKDTxA9VlOjfQEtcxZA	2026-10-24 19:18:43.479	GtS6KIIGL0JoowfUPZzP1zniHVAI5uct	2026-10-17 19:18:43.479	2026-10-17 19:18:43.479	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
6SFou8bM0vjx3GjL41Fy3u4H75xzp9Wg	2026-10-24 20:00:30.754	pvzD6V7xPz8iXSpZxkimyB71qHwA8pRP	2026-10-17 20:00:30.755	2026-10-17 20:00:30.755	194.76.131.42	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
PWmLy9VXcUK3Kzqvojr0A5gzP92GGsLJ	2026-10-24 20:54:15.23	YdhmT11kWjhrwJubSvlLTHeVbYmFLOhZ	2026-10-17 20:54:15.231	2026-10-17 20:54:15.231	5.132.34.188	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/155.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
0OdCj7U7VVxOqpwt26J7LSUoHuI9D8oK	2026-10-26 08:30:42.119	vCKk7jBQvnTbnC6gyU2pPfKlxX9KndB5	2026-10-17 21:01:08.214	2026-10-19 08:30:42.119	87.210.192.180	Mozilla/5.0 (iPhone; CPU iPhone OS 27_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/155.0.8059.37 Mobile/15E148 Safari/604.1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
tO4QraT0YMeDyaIqNK2Alo204BoBbEf6	2026-10-29 18:56:56.587	t638ojheDlOyxEcNydWLr0c3pTzKlAX3	2026-10-22 18:56:56.587	2026-10-22 18:56:56.587	109.37.138.233	Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.47 Mobile/15E148 Safari/604.1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
DT4LKkNxo8m6kHxJQaox7fPTXEqzojfR	2026-10-29 20:14:08.995	j42iYbE2cAtYkbrfm9dcjuDnoeTPTKWH	2026-10-22 20:14:08.996	2026-10-22 20:14:08.996	87.210.192.180	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36	c724d280-7f41-4b0f-bb24-fc29e1e7f73b
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "emailVerified", image, role, phone, "createdAt", "updatedAt", "mustChangePassword") FROM stdin;
c724d280-7f41-4b0f-bb24-fc29e1e7f73b	Hassan lefqih	manager@moskee.local	t	\N	manager	\N	2026-09-25 20:26:27.533	2026-09-25 21:04:23.64	f
4e130fd1-f214-4f10-bf5c-1c4b727d1930	mustapha	mustapha@qadri.nl	t	\N	teacher	\N	2026-10-02 20:54:18.807	2026-10-02 20:54:18.807	f
de9554a3-14cd-46fa-8f73-ffe9ae4d5643	Mustapha	hanifi@casema.nl	t	\N	manager	\N	2026-10-17 10:24:08.744	2026-10-17 10:24:08.744	f
4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	Ahmed	ahmed@ahmed.com	t	\N	teacher	\N	2026-10-17 10:39:45.005	2026-10-17 17:39:04.313	f
c58b9161-c77a-4b86-b6d0-40ada6443228	Imane	imane@gmail.com	t	\N	teacher	\N	2026-10-18 14:41:16.426	2026-10-18 14:41:16.426	f
127ebc4a-10f9-4cef-8397-b4e64cec18ae	Hajar	hajar@gmail.com	t	\N	teacher	\N	2026-10-18 14:44:49.19	2026-10-18 14:44:49.19	f
b3bbf9e1-bb20-45b0-bc17-ae808a748173	Abdelilaah	abdelilaah@gmail.com	t	\N	teacher	\N	2026-10-18 14:46:05.523	2026-10-18 14:46:05.523	f
179fdc67-4f5c-4e79-ad8a-c26918615647	Issa	issa@gmail.com	t	\N	teacher	\N	2026-10-18 14:48:16.049	2026-10-18 14:48:16.049	f
b122adab-ea31-469e-a8c7-83b554aaa57a	Mohammed	lhrach@gmail.com	t	\N	teacher	\N	2026-10-18 14:49:15.455	2026-10-18 14:49:15.455	f
a69e10b7-f6a6-44bc-aa38-d6587f3b6fe9	Khalid	khalid@gmail.vom	t	\N	manager	\N	2026-10-18 14:51:29.696	2026-10-18 14:51:29.696	f
e9c3b6cd-c6ac-405d-97cc-9b25ee91f2ad	Qadri	mohammed@qadri.nl	t	\N	manager	\N	2026-09-25 21:02:38.459	2026-10-18 14:55:17.198	f
4f07d991-ee7e-4477-ae61-220cee7d59db	Farida	farida@gmail.com	t	\N	teacher	\N	2026-10-22 13:11:17.182	2026-10-22 13:11:17.182	f
75a28c9d-3d13-4e65-af64-d5686958c9db	Nassira & Hajar	nassira@gmail.com	t	\N	teacher	\N	2026-10-18 14:43:50.966	2026-10-24 14:31:43.273	f
7ec0c017-0360-4b28-85f0-d221049d853c	Zaynab & Imane	zaynab@gmail.com	t	\N	teacher	\N	2026-10-18 14:39:44.816	2026-10-24 15:00:18.804	f
\.


--
-- Data for Name: Verification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Verification" (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d3503a82-c1a4-4381-9781-2e7df8383421	b86cf3c399c8a040314611e1f2f8a30714501dfdf7c493eb3ea0ea5772b0cfea	2026-10-08 19:45:45.382351+00	20261008120000_add_exams	\N	\N	2026-10-08 19:45:45.326536+00	1
28665d8d-0326-4635-8923-338b70fc5b1c	8c3000784bda6d5601fd3d2c8452e9641cee3af6d38dfa94732162f8f9eb1c6d	2026-10-08 20:14:58.024849+00	20261008130000_add_exam_title	\N	\N	2026-10-08 20:14:58.015092+00	1
b59fce3f-7028-4274-9c62-7ec19183745c	f6ebafac98265d0e161476625032096ced6510b36c89ad5563aa62a5d255a628	2026-09-18 21:19:21.108982+00	20260918211921_add_grades_subjects	\N	\N	2026-09-18 21:19:21.066552+00	1
95902c7c-32cf-4ad2-92bc-959572a4a844	89936aca5ce35ff000c8f708837fabc12d9eee82b7328e9a9741905a0d2d4155	2026-09-18 19:59:05.210559+00	20260918195905_init	\N	\N	2026-09-18 19:59:05.115032+00	1
2e7a69e9-8b01-4c43-871c-71a453710199	4f0ec7a50621ce03f6bb99a5e3a023728940324698ecfda3e338b80f819b5af6	2026-09-18 20:52:57.223438+00	20260918205257_add_attendance	\N	\N	2026-09-18 20:52:57.204812+00	1
7fe522bb-f025-4267-8fef-3dd910659940	2561f3c8fd3e81073d838e95a4be87d18ed5ab481de988939ec1ffb1bf2a3c3e	2026-09-18 21:41:22.273552+00	20260918214122_add_donations	\N	\N	2026-09-18 21:41:22.252142+00	1
0a41d69a-8cd7-46a1-8fb5-827161c89dc5	dcc0e56a872f4b92d73124517edb432346827389ee75ed4e34df52097327ff84	2026-09-25 19:59:12.015117+00	20260925120000_add_guardian_numbers	\N	\N	2026-09-25 19:59:11.997804+00	1
a3e87ef2-3823-46ba-8beb-3971dffcbe23	6de04985b507de067c06122f10f50126626e4ee2bf60095f256f9d5886fb91d8	2026-10-08 21:25:10.628062+00	20261008140000_add_report_messages	\N	\N	2026-10-08 21:25:10.592526+00	1
21cc7697-0b5d-4856-879b-09994d07c587	58b18f9f791fdfdb3a036ecff2bbfaa8bd0a3ff27f65ff93b7ec51b9ddbe712b	2026-09-25 22:22:46.499099+00	20260926120000_rooms_competencies_timeslots	\N	\N	2026-09-25 22:22:46.475805+00	1
4f57de6e-8b3d-4841-a418-d669573f6d19	fd44b9581f06cc97a30f2d3c60413790078b166cf88fa20d6075caa3bac52830	2026-10-02 20:18:06.917786+00	20260927120000_global_periods_subject_image	\N	\N	2026-10-02 20:18:06.883481+00	1
c521f333-c3e2-478d-b27a-2814c39b3996	49feb615fa9a797e2880a44ebfa48ca1ce1c59af23ea25be495b5a64847ef5d9	2026-10-02 20:25:52.389645+00	20260927130000_drop_competencies	\N	\N	2026-10-02 20:25:52.377818+00	1
f6b90a0c-a009-41bc-92a4-bc4dcd16d602	f6e7eda5accb4b1078bec6a72b6c9d465812fe23e2a2572cabc7f58e188f1b52	2026-10-08 21:43:21.710196+00	20261008150000_rename_report_observations	\N	\N	2026-10-08 21:43:21.693166+00	1
bd47136d-0f53-4677-a42a-31440e20d217	a1e4573b2f225c24c61176cc76d615d1a720d638cfbc7976cf8b7c20c45594c8	2026-10-02 20:45:12.173392+00	20260927140000_must_change_password	\N	\N	2026-10-02 20:45:12.163152+00	1
22648ed8-ab2d-4b79-8a3c-4f395349df2a	e08516685c7f12135bbe5fbbc654e82e079b90c1fa833680a3035ccaa5009384	2026-10-02 21:02:40.345424+00	20260927150000_drop_primary_and_sex_other	\N	\N	2026-10-02 21:02:40.324665+00	1
32180de7-7c73-4f7c-a894-5a1a6dfbbd0e	f9515a6adec47ba7ebe973bbdbaecfe684f6e33b89f6d8d89369c5d3053c5c44	2026-10-02 21:28:18.399297+00	20260927160000_add_very_late_attendance	\N	\N	2026-10-02 21:28:18.389673+00	1
56de7846-a2cc-4383-959d-46f79df11d28	2ed8d875391252d5f1eda520efc541b36ca68ff3a645c58e9c5b026cd413c290	2026-10-11 20:49:34.958805+00	20261011204916_student_status_and_payments	\N	\N	2026-10-11 20:49:34.916779+00	1
ac0bfdbd-b4aa-4f7d-8c9a-9c0b376219f5	604a5a2bba2cbe654532f9aae7853545d496b10e3b662cef14dbb8f2c1abbd32	2026-10-02 21:54:19.050637+00	20260927170000_add_student_image	\N	\N	2026-10-02 21:54:19.041646+00	1
fafac343-8119-4e73-bbda-13e49a04963b	0107f611c5da92be68480dd4af599c685ef3c131f1667537f2403603cafd567f	2026-10-17 19:18:09.310068+00	20261017185714_guardian_registration_links	\N	\N	2026-10-17 19:18:09.141081+00	1
55de5bea-5c30-4472-b4b9-efc36f92d2a0	df3573b66298cc42070af10112e452f2e84b9166613f81d30e7df32d4b970802	2026-10-17 19:59:57.851716+00	20261017194900_backfill_education_numbers	\N	\N	2026-10-17 19:59:57.816404+00	1
1b448bdd-b897-4874-bb81-91cb0d3f02db	0ad9abcbd3e5bcab3c15e84f8a2a9d09bcdda0517a558e8e40452e2575e77e46	2026-10-22 21:39:29.619207+00	20261022120000_add_enrollment_archive_dates	\N	\N	2026-10-22 21:39:29.491792+00	1
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_years (id, name, "startDate", "endDate", "isCurrent", "createdAt", "updatedAt") FROM stdin;
cmuzz99nt000oe26divmsytcg	2025 - 2026	2025-09-01	2026-06-30	f	2026-10-08 20:16:55.337	2026-10-22 21:39:58.152
cmuhjm5hy00007g6di3jovxng	2026 - 2027	2026-09-12	2027-06-27	t	2026-09-25 22:39:11.446	2026-10-22 21:39:58.164
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance (id, "studentId", "classId", "sessionId", date, status, note, "recordedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: class_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_comments (id, "classId", "authorId", body, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: class_session_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_session_links (id, "classId", "sessionId", "createdAt", "updatedAt") FROM stdin;
cmvf3lnsj000b01n4s8pvy24j	cmvf3lnsd000a01n4cf7vrggg	cmuhhi7t800003j6ds4rzl4v5	2026-10-19 10:15:04.621	2026-10-19 10:15:04.621
cmvf3lnsj000c01n4s387gd7r	cmvf3lnsd000a01n4cf7vrggg	cmuhhi7u400033j6d04y9ccks	2026-10-19 10:15:04.621	2026-10-19 10:15:04.621
cmvf3me9y000e01n4y7g34f7x	cmvf3me9p000d01n47nyq7jbz	cmuhhi7u000013j6d1hcns7ja	2026-10-19 10:15:38.941	2026-10-19 10:15:38.941
cmvf3mea0000f01n4nvso0ulx	cmvf3me9p000d01n47nyq7jbz	cmuhhi7u600043j6d0ykpb96r	2026-10-19 10:15:38.941	2026-10-19 10:15:38.941
cmvf3n2z3000h01n4eorqucuv	cmvf3n2yz000g01n4tb3b3riz	cmuhhi7u300023j6df6dk0val	2026-10-19 10:16:10.956	2026-10-19 10:16:10.956
cmvf3n2z3000i01n46c6b95oj	cmvf3n2yz000g01n4tb3b3riz	cmuhhi7u700053j6dwa7p265o	2026-10-19 10:16:10.956	2026-10-19 10:16:10.956
cmvf3sz0c000n01n47pc34qoh	cmvf3sz07000m01n4lwmfsd5y	cmuhhi7u000013j6d1hcns7ja	2026-10-19 10:20:45.751	2026-10-19 10:20:45.751
cmvf3sz0c000o01n4lrz3qu97	cmvf3sz07000m01n4lwmfsd5y	cmuhhi7u600043j6d0ykpb96r	2026-10-19 10:20:45.751	2026-10-19 10:20:45.751
cmvf3u5hx000q01n4jzgupmzo	cmvf3u5ht000p01n443gsqgeg	cmuhhi7u300023j6df6dk0val	2026-10-19 10:21:40.817	2026-10-19 10:21:40.817
cmvf3u5hx000r01n4ngz0i3gt	cmvf3u5ht000p01n443gsqgeg	cmuhhi7u700053j6dwa7p265o	2026-10-19 10:21:40.817	2026-10-19 10:21:40.817
cmvf3vi1l000t01n412rfon6d	cmvf3vi1f000s01n4dpx60bmu	cmuhhi7t800003j6ds4rzl4v5	2026-10-19 10:22:43.731	2026-10-19 10:22:43.731
cmvf3vi1l000u01n4m3nplhpq	cmvf3vi1f000s01n4dpx60bmu	cmuhhi7u400033j6d04y9ccks	2026-10-19 10:22:43.731	2026-10-19 10:22:43.731
cmvf3whkm000w01n426kz9r6y	cmvf3whkj000v01n4ykwe3g2y	cmuhhi7u300023j6df6dk0val	2026-10-19 10:23:29.779	2026-10-19 10:23:29.779
cmvf3whkm000x01n4c6pgq083	cmvf3whkj000v01n4ykwe3g2y	cmuhhi7u700053j6dwa7p265o	2026-10-19 10:23:29.779	2026-10-19 10:23:29.779
cmvf3xccj000z01n4byspgyci	cmvf3xcce000y01n4gn481r7q	cmuhhi7u300023j6df6dk0val	2026-10-19 10:24:09.662	2026-10-19 10:24:09.662
cmvf3xccj001001n4wqd93cu2	cmvf3xcce000y01n4gn481r7q	cmuhhi7u700053j6dwa7p265o	2026-10-19 10:24:09.662	2026-10-19 10:24:09.662
cmvf3z2td001501n4cbfp238w	cmvf3z2t8001401n4dxyjy90w	cmuhhi7u000013j6d1hcns7ja	2026-10-19 10:25:30.62	2026-10-19 10:25:30.62
cmvf3z2td001601n4wvqesu8a	cmvf3z2t8001401n4dxyjy90w	cmuhhi7u600043j6d0ykpb96r	2026-10-19 10:25:30.62	2026-10-19 10:25:30.62
cmvf3zhrl001801n4hsd8ylv5	cmvf3zhrf001701n4isd1bv51	cmuhhi7u300023j6df6dk0val	2026-10-19 10:25:49.995	2026-10-19 10:25:49.995
cmvf3zhrl001901n4vfz0xoyc	cmvf3zhrf001701n4isd1bv51	cmuhhi7u700053j6dwa7p265o	2026-10-19 10:25:49.995	2026-10-19 10:25:49.995
cmvkslds2000b01qqjr3k8mzh	cmvf3s76a000j01n45dn103g9	cmuhhi7t800003j6ds4rzl4v5	2026-10-23 09:53:32.917	2026-10-23 09:53:32.917
cmvkslds2000c01qq4w4042tx	cmvf3s76a000j01n45dn103g9	cmuhhi7u400033j6d04y9ccks	2026-10-23 09:53:32.917	2026-10-23 09:53:32.917
cmvmhsb7n003e01qqdjxqnve8	cmvk2e0vr009y10qo7yam17hh	cmuhhi7t800003j6ds4rzl4v5	2026-10-24 14:26:32.764	2026-10-24 14:26:32.764
cmvmiy2et003f01qqeojwp3y2	cmvf3yg7i001101n4g8wmjtf0	cmuhhi7t800003j6ds4rzl4v5	2026-10-24 14:59:00.9	2026-10-24 14:59:00.9
cmvmiy2et003g01qqdsl7ac3o	cmvf3yg7i001101n4g8wmjtf0	cmuhhi7u400033j6d04y9ccks	2026-10-24 14:59:00.9	2026-10-24 14:59:00.9
cmvmj120f003h01qqzye60ss8	cmvc9nx0r000601rytht9l9lj	cmuhhi7u000013j6d1hcns7ja	2026-10-24 15:01:20.351	2026-10-24 15:01:20.351
cmvmj120f003i01qqaowk4a3o	cmvc9nx0r000601rytht9l9lj	cmuhhi7u600043j6d0ykpb96r	2026-10-24 15:01:20.351	2026-10-24 15:01:20.351
cmvmjk84b003k01qqcp3tzbsv	cmvf3il9z000401n44094dbvs	cmuhhi7u000013j6d1hcns7ja	2026-10-24 15:16:14.732	2026-10-24 15:16:14.732
cmvmjk84b003l01qqbt1x69o4	cmvf3il9z000401n44094dbvs	cmuhhi7u600043j6d0ykpb96r	2026-10-24 15:16:14.732	2026-10-24 15:16:14.732
cmvmjnn5h003m01qqas69f28w	cmvf3k9w0000701n4r93hf29x	cmuhhi7u300023j6df6dk0val	2026-10-24 15:18:54.185	2026-10-24 15:18:54.185
cmvmjnn5h003n01qqnpo3t348	cmvf3k9w0000701n4r93hf29x	cmuhhi7u700053j6dwa7p265o	2026-10-24 15:18:54.185	2026-10-24 15:18:54.185
\.


--
-- Data for Name: class_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_sessions (id, label, day, "createdAt", "updatedAt", "endTime", "startTime") FROM stdin;
cmuhhi7t800003j6ds4rzl4v5	Zaterdag ochtend	Zaterdag	2026-09-25 21:40:08.589	2026-10-16 21:34:52.74	12:00	09:00
cmuhhi7u400033j6d04y9ccks	Zondag ochtend	Zondag	2026-09-25 21:40:08.62	2026-10-16 21:34:52.842	12:00	09:00
cmuhhi7u000013j6d1hcns7ja	Zaterdag middag	Zaterdag	2026-09-25 21:40:08.616	2026-10-18 05:11:25.615	14:30	12:30
cmuhhi7u300023j6df6dk0val	Zaterdag namiddag	Zaterdag	2026-09-25 21:40:08.619	2026-10-18 05:11:57.421	17:00	15:00
cmuhhi7u600043j6d0ykpb96r	Zondag middag	Zondag	2026-09-25 21:40:08.622	2026-10-18 05:12:33.297	14:30	12:30
cmuhhi7u700053j6dwa7p265o	Zondag namiddag	Zondag	2026-09-25 21:40:08.623	2026-10-18 05:13:30.834	17:00	15:00
cmvddgupu000901n4drbt89xb	Zondag namiddag 2	Zondag	2026-10-18 05:15:44.13	2026-10-18 05:15:44.13	06:30	02:30
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, name, description, "levelId", "roomId", "teacherId", "createdAt", "updatedAt") FROM stdin;
cmvf3lnsd000a01n4cf7vrggg	BG2A	\N	cmuhhs8tp0001b16dttc1x8ci	cmuhhvzri0006b16dujdfvuxx	\N	2026-10-19 10:15:04.621	2026-10-19 10:15:04.621
cmvf3me9p000d01n47nyq7jbz	BG2B	\N	cmuhhshwq0002b16dmj4ohr4u	cmuhhvzri0006b16dujdfvuxx	\N	2026-10-19 10:15:38.941	2026-10-19 10:15:38.941
cmvf3n2yz000g01n4tb3b3riz	BG2C	\N	cmuhhshwq0002b16dmj4ohr4u	cmuhhvzri0006b16dujdfvuxx	\N	2026-10-19 10:16:10.956	2026-10-19 10:16:10.956
cmvf3sz07000m01n4lwmfsd5y	E3B	\N	cmuhhshwq0002b16dmj4ohr4u	cmvdcxzvz000301n4c4so4dhf	\N	2026-10-19 10:20:45.751	2026-10-19 10:20:45.751
cmvf3u5ht000p01n443gsqgeg	E3C	\N	cmuhhshwq0002b16dmj4ohr4u	cmvdcxzvz000301n4c4so4dhf	\N	2026-10-19 10:21:40.817	2026-10-19 10:21:40.817
cmvf3vi1f000s01n4dpx60bmu	E4A	\N	cmuhhs8tp0001b16dttc1x8ci	cmvdczzmi000401n46qbaitqr	\N	2026-10-19 10:22:43.731	2026-10-19 10:22:43.731
cmvf3whkj000v01n4ykwe3g2y	E4B	\N	cmuhhs8tp0001b16dttc1x8ci	cmvdczzmi000401n46qbaitqr	\N	2026-10-19 10:23:29.779	2026-10-19 10:23:29.779
cmvf3xcce000y01n4gn481r7q	E4C	\N	cmuhhshwq0002b16dmj4ohr4u	cmvdczzmi000401n46qbaitqr	\N	2026-10-19 10:24:09.662	2026-10-19 10:24:09.662
cmvf3z2t8001401n4dxyjy90w	E5B	\N	cmvdd6wdh000601n4v1jiqxle	cmvdd0s19000501n4hcu9habd	\N	2026-10-19 10:25:30.62	2026-10-19 10:25:30.62
cmvf3zhrf001701n4isd1bv51	E5C	\N	cmvdd7cl8000801n4shqb3ahd	cmvdd0s19000501n4hcu9habd	\N	2026-10-19 10:25:49.995	2026-10-19 10:25:49.995
cmvf3s76a000j01n45dn103g9	E3A	\N	cmuhhs8tp0001b16dttc1x8ci	cmvdcxzvz000301n4c4so4dhf	179fdc67-4f5c-4e79-ad8a-c26918615647	2026-10-19 10:20:09.682	2026-10-23 09:53:32.917
cmvk2e0vr009y10qo7yam17hh	BG2D	\N	cmvdd6wdh000601n4v1jiqxle	cmuhhvzri0006b16dujdfvuxx	4f07d991-ee7e-4477-ae61-220cee7d59db	2026-10-22 21:39:59.607	2026-10-24 14:26:32.764
cmvf3yg7i001101n4g8wmjtf0	E5A	\N	cmvdd7108000701n4jz3ooq5j	cmvdd0s19000501n4hcu9habd	75a28c9d-3d13-4e65-af64-d5686958c9db	2026-10-19 10:25:01.326	2026-10-24 14:59:00.9
cmvc9nx0r000601rytht9l9lj	BG1A	\N	cmuhhshwq0002b16dmj4ohr4u	cmuhhvtow0005b16dvond9z61	7ec0c017-0360-4b28-85f0-d221049d853c	2026-10-17 10:41:29.067	2026-10-24 15:01:20.351
cmvf3il9z000401n44094dbvs	BG1B	\N	cmuhhshwq0002b16dmj4ohr4u	cmuhhvtow0005b16dvond9z61	4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	2026-10-19 10:12:41.4	2026-10-24 15:16:14.732
cmvf3k9w0000701n4r93hf29x	BG1C	\N	cmuhhs3tw0000b16dt3vyjoxl	cmuhhvtow0005b16dvond9z61	4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	2026-10-19 10:13:59.952	2026-10-24 15:18:54.185
\.


--
-- Data for Name: donation_payment_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donation_payment_logs (id, "paymentId", "studentId", "academicYearId", action, "amountBefore", "amountAfter", "paidAtBefore", "paidAtAfter", note, "actorId", "createdAt") FROM stdin;
\.


--
-- Data for Name: donation_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donation_payments (id, "studentId", "academicYearId", amount, "paidAt", note, "recordedById", "createdAt", "updatedAt") FROM stdin;
cmvk2e34r00qm10qoet617hpo	cmvk2e0f8005j10qop7xz3aez	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.425	2026-10-22 21:40:02.425
cmvk2e35h00qo10qojwf2s6su	cmvk2e0fr005m10qoxk85a4gx	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.544	2026-10-22 21:40:02.544
cmvk2e35p00qq10qon60i8co5	cmvk2e0g3005p10qomvyxe6dj	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.555	2026-10-22 21:40:02.555
cmvk2e37r00qt10qovmbnaosv	cmvk2e0gp005v10qom1efo6sv	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.581	2026-10-22 21:40:02.581
cmvk2e38e00qx10qol2grrd6f	cmvk2e0hi006410qoeec2qw1j	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.65	2026-10-22 21:40:02.65
cmvk2e38o00qz10qoefttq26d	cmvk2e0hu006710qokk2xy663	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.661	2026-10-22 21:40:02.661
cmvk2e38x00r110qoqoccrm47	cmvk2e0id006a10qo4fp7ykud	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.671	2026-10-22 21:40:02.671
cmvk2e39300r310qoqqvkc6cl	cmvk2e0io006d10qo3rpuu4jx	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.676	2026-10-22 21:40:02.676
cmvk2e39900r510qo4476zyuz	cmvk2e0iy006g10qop9g8g78n	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.682	2026-10-22 21:40:02.682
cmvk2e39f00r710qocdou2f5c	cmvk2e0j9006j10qooapareag	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.688	2026-10-22 21:40:02.688
cmvk2e39t00rb10qoa3fnm68g	cmvk2e0kd006s10qowzu5tucn	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.701	2026-10-22 21:40:02.701
cmvk2e3a100rd10qo0582ea6t	cmvk2e0ko006v10qocpipelf3	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.708	2026-10-22 21:40:02.708
cmvk2e3a800rf10qowwj0ysis	cmvk2e0l2006y10qok6uxeupm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.717	2026-10-22 21:40:02.717
cmvk2e3af00rh10qo5eqzn3vc	cmvk2e0lf007110qox7244gt0	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.725	2026-10-22 21:40:02.725
cmvk2e3b700rj10qonivv68re	cmvk2e0lo007410qophya3uil	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.736	2026-10-22 21:40:02.736
cmvk2e3bm00rl10qovll60a88	cmvk2e0lw007710qotmosrlq5	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.767	2026-10-22 21:40:02.767
cmvk2e3c100rn10qoyuagm028	cmvk2e0m4007a10qotbwxc7eb	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.782	2026-10-22 21:40:02.782
cmvk2e3cc00rp10qoxeay6s2y	cmvk2e0md007d10qo9zsykd0a	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.792	2026-10-22 21:40:02.792
cmvk2e3cm00rr10qorha6y89j	cmvk2e0mn007g10qogjizo77d	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.801	2026-10-22 21:40:02.801
cmvk2e3d600rt10qocd5zbkee	cmvk2e0mx007j10qow4xt9f1o	cmuhjm5hy00007g6di3jovxng	15.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.825	2026-10-22 21:40:02.825
cmvk2e3dx00rv10qozmy3my2m	cmvk2e0n7007m10qo74e8y9jm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.842	2026-10-22 21:40:02.842
cmvk2e3eg00rx10qo1a8y7oz8	cmvk2e0nk007p10qoaxw6gch4	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.864	2026-10-22 21:40:02.864
cmvk2e3ff00rz10qo80glg4gf	cmvk2e0nu007s10qo0xmaj30h	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.901	2026-10-22 21:40:02.901
cmvk2e3fp00s110qoov82iudt	cmvk2e0o6007v10qoxdixzsrp	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.914	2026-10-22 21:40:02.914
cmvk2e3gf00s810qomw5rspph	cmvk2e0qh008d10qoanwe1tei	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.941	2026-10-22 21:40:02.941
cmvk2e3gl00sa10qot8m5oi9j	cmvk2e0qs008g10qo49tbyhpf	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.947	2026-10-22 21:40:02.947
cmvk2e3gs00sc10qo4t6p1bpz	cmvk2e0r6008j10qow2kjqodr	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.954	2026-10-22 21:40:02.954
cmvk2e3h000sf10qodpbaflxt	cmvk2e0rp008p10qohkq8qlhx	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.962	2026-10-22 21:40:02.962
cmvk2e3h800sh10qox1wh0icg	cmvk2e0rz008s10qojfdjm4m8	cmuhjm5hy00007g6di3jovxng	35.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.97	2026-10-22 21:40:02.97
cmvk2e3hh00sj10qoi8zmw8rg	cmvk2e0s5008v10qopeicutss	cmuhjm5hy00007g6di3jovxng	115.00	2026-03-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.979	2026-10-22 21:40:02.979
cmvk2e3hs00sl10qohltqdb4j	cmvk2e0sg008y10qo3jv48tmq	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.988	2026-10-22 21:40:02.988
cmvk2e3hz00sn10qossq5fzcm	cmvk2e0sq009110qorf0zejq7	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:02.997	2026-10-22 21:40:02.997
cmvk2e3i300sp10qoly7l303s	cmvk2e0sy009410qo6gdrb9th	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.002	2026-10-22 21:40:03.002
cmvk2e3ib00sr10qo2w5h0zir	cmvk2e0t4009710qo6y5w6a8d	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.006	2026-10-22 21:40:03.006
cmvk2e3in00st10qo1m321csw	cmvk2e0tc009a10qopmfmhk8v	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.019	2026-10-22 21:40:03.019
cmvk2e3iz00sv10qodzue8a5m	cmvk2e0tp009d10qotj9m8qof	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.031	2026-10-22 21:40:03.031
cmvk2e3jf00sx10qo80lc13a0	cmvk2e0u4009g10qojvw6fzq2	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.046	2026-10-22 21:40:03.046
cmvk2e3js00sz10qobtdip4pe	cmvk2e0uf009j10qonmsrbolk	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.062	2026-10-22 21:40:03.062
cmvk2e3kb00t210qozv5slkrn	cmvk2e0v8009p10qoxvtkgw0e	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.079	2026-10-22 21:40:03.079
cmvk2e3km00t410qoyt2q7ila	cmvk2e0ve009s10qocx5lazvz	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.091	2026-10-22 21:40:03.091
cmvk2e3m100t610qo5v2azkbs	cmvk2e0vk009v10qocx5xules	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.142	2026-10-22 21:40:03.142
cmvk2e3mj00t810qofbkocn3c	cmvk2e0vz00a010qoqk2qppbc	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.16	2026-10-22 21:40:03.16
cmvk2e3nt00tb10qozoddumi8	cmvk2e0we00a610qocxbkzyuy	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.207	2026-10-22 21:40:03.207
cmvk2e3o500td10qolt95tm1p	cmvk2e0wm00a910qoj3lq7cib	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.214	2026-10-22 21:40:03.214
cmvk2e3on00tf10qoogggkcdt	cmvk2e0wt00ac10qo7vfmjd0a	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.234	2026-10-22 21:40:03.234
cmvk2e3pl00th10qopnt4azoq	cmvk2e0x200af10qogjjlyhze	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.247	2026-10-22 21:40:03.247
cmvk2e3sd00tj10qovubx0mhy	cmvk2e0xb00ai10qokuc5bs2q	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.317	2026-10-22 21:40:03.317
cmvk2e3t800to10qoy6uawrxp	cmvk2e0y200au10qouns1kkb0	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.402	2026-10-22 21:40:03.402
cmvk2e3tk00tr10qol6u1rfpp	cmvk2e0yj00b010qowwfl1nln	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.414	2026-10-22 21:40:03.414
cmvk2e3tq00tt10qouey5fbfy	cmvk2e0ys00b310qomfp2y9kx	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.42	2026-10-22 21:40:03.42
cmvk2e3ty00tv10qowqicxc1b	cmvk2e0z200b610qoz3wbt9k3	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.428	2026-10-22 21:40:03.428
cmvk2e3u600tx10qov2c7nf4i	cmvk2e0z900b910qorgtkuon9	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.436	2026-10-22 21:40:03.436
cmvk2e3uc00tz10qo35xguq6x	cmvk2e0ze00bc10qogbcciv39	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.441	2026-10-22 21:40:03.441
cmvk2e3uh00u110qo2zbhb1wf	cmvk2e0zl00bf10qouw396q6q	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.448	2026-10-22 21:40:03.448
cmvk2e3us00u310qo85ei63zp	cmvk2e0zr00bi10qofdc5fch4	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.456	2026-10-22 21:40:03.456
cmvk2e3uw00u510qo3tdpqh7i	cmvk2e10200bl10qoxc22xsjq	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.462	2026-10-22 21:40:03.462
cmvk2e3v200u710qogwehwddd	cmvk2e10c00bo10qoclc4ctlx	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.468	2026-10-22 21:40:03.468
cmvk2e3v600u910qox6tks470	cmvk2e10m00br10qo701zsodd	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.473	2026-10-22 21:40:03.473
cmvk2e3vc00ub10qo3bra0ot3	cmvk2e10v00bu10qocjrna6gx	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.479	2026-10-22 21:40:03.479
cmvk2e3vk00ud10qomqspwqvn	cmvk2e11500bx10qoey8wmotp	cmuhjm5hy00007g6di3jovxng	70.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.486	2026-10-22 21:40:03.486
cmvk2e3vt00uf10qocreeg932	cmvk2e11d00c010qoryncqogm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.493	2026-10-22 21:40:03.493
cmvk2e3vz00uh10qo6ky35x7b	cmvk2e11m00c310qoopdaoqx8	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.501	2026-10-22 21:40:03.501
cmvk2e3w800uj10qowtrr8d5x	cmvk2e11s00c610qo5ocm5vo0	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.509	2026-10-22 21:40:03.509
cmvk2e3wp00ul10qoy51k74jt	cmvk2e11y00c910qoplfuiyvr	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.526	2026-10-22 21:40:03.526
cmvk2e3xn00un10qo0ha1r58d	cmvk2e12800cc10qouya3fezi	cmuhjm5hy00007g6di3jovxng	100.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.551	2026-10-22 21:40:03.551
cmvk2e3yy00uq10qowarlrlsn	cmvk2e12q00ci10qoual19fsm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.605	2026-10-22 21:40:03.605
cmvk2e3za00us10qowwwiny0i	cmvk2e12y00cl10qok0tp3x9k	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.617	2026-10-22 21:40:03.617
cmvk2e3zy00uu10qos4x933vk	cmvk2e13600co10qofwnaqw2z	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.642	2026-10-22 21:40:03.642
cmvk2e40g00uy10qoiok623ku	cmvk2e13w00cx10qo8dkntsp3	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.66	2026-10-22 21:40:03.66
cmvk2e40r00v010qo9q0g31b5	cmvk2e14400d010qoperb2tqj	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.671	2026-10-22 21:40:03.671
cmvk2e41800v410qoddd98ugb	cmvk2e14v00d910qojo53f9k3	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-18	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.689	2026-10-22 21:40:03.689
cmvk2e41j00v610qomcdmn6zq	cmvk2e15700dc10qoiwgsj8f9	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-18	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.699	2026-10-22 21:40:03.699
cmvk2e42400vb10qo1fqyfn0g	cmvk2e16700do10qoked9sudv	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.722	2026-10-22 21:40:03.722
cmvk2e42900vd10qojfqfp3yb	cmvk2e16h00dr10qotnvucg70	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.728	2026-10-22 21:40:03.728
cmvk2e42g00vf10qowgrhjjrh	cmvk2e16w00du10qoskeyh0lb	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.733	2026-10-22 21:40:03.733
cmvk2e42y00vi10qoca2jnynk	cmvk2e18k00e010qokp92c4cf	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.749	2026-10-22 21:40:03.749
cmvk2e43800vk10qoeivhcox2	cmvk2e19600e310qoc9g43cye	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.761	2026-10-22 21:40:03.761
cmvk2e43s00vm10qoz7hq21tz	cmvk2e19m00e610qovhbftiyr	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.774	2026-10-22 21:40:03.774
cmvk2e44700vo10qog9yxbjsl	cmvk2e1af00e910qoj9m97yrh	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.793	2026-10-22 21:40:03.793
cmvk2e44f00vq10qo53nz70ha	cmvk2e1c800ec10qofadi7fwm	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.804	2026-10-22 21:40:03.804
cmvk2e45600vu10qok3k29byc	cmvk2e1hr00el10qorft4v8hb	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.832	2026-10-22 21:40:03.832
cmvk2e45b00vw10qoj3jgzap7	cmvk2e1i300eo10qoactgc813	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.838	2026-10-22 21:40:03.838
cmvk2e45h00vy10qo84wnkc9f	cmvk2e1ib00er10qo0dxjt8q4	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.844	2026-10-22 21:40:03.844
cmvk2e45l00w010qo9nsbu7tn	cmvk2e1ii00eu10qouggo8ohv	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.848	2026-10-22 21:40:03.848
cmvk2e45r00w210qo32dexx9e	cmvk2e1iq00ex10qolv7h3znf	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.853	2026-10-22 21:40:03.853
cmvk2e46100w410qo8zg0v2bx	cmvk2e1iw00f010qouldd0whw	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.862	2026-10-22 21:40:03.862
cmvk2e46b00w610qocqv4oqji	cmvk2e1j300f310qokwlctw42	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.873	2026-10-22 21:40:03.873
cmvk2e47200w910qoxjbf0mef	cmvk2e1jb00f910qoxwwq9wec	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-18	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.898	2026-10-22 21:40:03.898
cmvk2e47s00wb10qoesr6epug	cmvk2e1jf00fc10qodoqzhons	cmuhjm5hy00007g6di3jovxng	115.00	2026-03-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.921	2026-10-22 21:40:03.921
cmvk2e47y00wd10qo6rnp8rdk	cmvk2e1jn00ff10qo6b20bk1d	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.932	2026-10-22 21:40:03.932
cmvk2e48800wf10qo8bje1cdp	cmvk2e1js00fi10qoblhlylqf	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.941	2026-10-22 21:40:03.941
cmvk2e48i00wh10qo4syf2x7x	cmvk2e1k100fl10qohvdgqlc8	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.952	2026-10-22 21:40:03.952
cmvk2e49b00wl10qofwzvoisu	cmvk2e1lh00fu10qodi34nlo8	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.979	2026-10-22 21:40:03.979
cmvk2e49r00wn10qom00bufmj	cmvk2e1ln00fx10qob4gtsuxb	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:03.995	2026-10-22 21:40:03.995
cmvk2e4ak00wp10qo2gvbe5l0	cmvk2e1lz00g010qor4spgnh3	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.015	2026-10-22 21:40:04.015
cmvk2e4au00wr10qobfd1az64	cmvk2e1m500g310qogosi93ht	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.035	2026-10-22 21:40:04.035
cmvk2e4b700wt10qo3lr3n6xy	cmvk2e1mc00g610qokmrvsajm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.046	2026-10-22 21:40:04.046
cmvk2e4bj00wv10qoswy4nyx3	cmvk2e1mh00g910qof9zdk9s0	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.06	2026-10-22 21:40:04.06
cmvk2e4ca00wx10qol087kvvk	cmvk2e1n100gc10qoy5htea82	cmuhjm5hy00007g6di3jovxng	115.00	2026-03-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.086	2026-10-22 21:40:04.086
cmvk2e4ck00wz10qo9ig3sq0c	cmvk2e1n800gf10qopkdmfra7	cmuhjm5hy00007g6di3jovxng	115.00	2026-03-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.097	2026-10-22 21:40:04.097
cmvk2e4d800x410qobvkm2pq8	cmvk2e1o600gr10qourhjh39x	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.121	2026-10-22 21:40:04.121
cmvk2e4dk00x610qod250bqp6	cmvk2e1oc00gu10qoce37z8sn	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.132	2026-10-22 21:40:04.132
cmvk2e4dt00x810qotfew0mav	cmvk2e1oh00gx10qobcvz39da	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.143	2026-10-22 21:40:04.143
cmvk2e4e200xa10qowhxmj1du	cmvk2e1on00h010qoznju2wm0	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.151	2026-10-22 21:40:04.151
cmvk2e4ef00xc10qoop2fbvkp	cmvk2e1p000h310qoy77ot97c	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.163	2026-10-22 21:40:04.163
cmvk2e4ep00xe10qo0buafw7u	cmvk2e1pb00h610qohomlnt99	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.174	2026-10-22 21:40:04.174
cmvk2e4f000xg10qoropus82n	cmvk2e1pn00h910qo26r9kzvv	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.184	2026-10-22 21:40:04.184
cmvk2e4f800xi10qom7n461we	cmvk2e1pv00hc10qo70s7eud4	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.192	2026-10-22 21:40:04.192
cmvk2e4fn00xk10qouhy5xkh2	cmvk2e1qc00hf10qolumdg9rh	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.207	2026-10-22 21:40:04.207
cmvk2e4fy00xm10qogk4ijnnb	cmvk2e1ql00hi10qomvtqdm69	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.217	2026-10-22 21:40:04.217
cmvk2e4g700xo10qocfeq4to6	cmvk2e1qu00hl10qol44lbi9l	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.228	2026-10-22 21:40:04.228
cmvk2e4go00xq10qo8ekyhqik	cmvk2e1r300ho10qoohbq1j9b	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.235	2026-10-22 21:40:04.235
cmvk2e4h300xs10qo7gn6kocz	cmvk2e1rl00hr10qoln6c107h	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.259	2026-10-22 21:40:04.259
cmvk2e4he00xu10qoazwdd3i6	cmvk2e1s000hu10qovy3i6l19	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.271	2026-10-22 21:40:04.271
cmvk2e4hj00xw10qomd3opk47	cmvk2e1t400hx10qody17xdw5	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.278	2026-10-22 21:40:04.278
cmvk2e4ip00xy10qondmeigkk	cmvk2e1tk00i010qonijxikwe	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.285	2026-10-22 21:40:04.285
cmvk2e4ix00y010qog7u7fy04	cmvk2e1tz00i310qoo67eujha	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.326	2026-10-22 21:40:04.326
cmvk2e4j900y210qo1ai4rqzm	cmvk2e1ug00i610qo7n6jek1u	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.336	2026-10-22 21:40:04.336
cmvk2e4jm00y410qouk9gjm4j	cmvk2e1ut00i910qocffcgu3k	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.349	2026-10-22 21:40:04.349
cmvk2e4jv00y610qo1v6o2aun	cmvk2e1v700ic10qont684rtb	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.362	2026-10-22 21:40:04.362
cmvk2e4k800y810qog9q8ijfi	cmvk2e1vn00if10qoa5gn8yl7	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.371	2026-10-22 21:40:04.371
cmvk2e4ku00yd10qojnzby56v	cmvk2e1wl00ir10qozqju3tjf	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.395	2026-10-22 21:40:04.395
cmvk2e4l400yf10qoe3vwavr3	cmvk2e1wx00iu10qocetv78hy	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.404	2026-10-22 21:40:04.404
cmvk2e4lc00yh10qo9e4ysshb	cmvk2e1xx00ix10qo5qpio2jr	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.412	2026-10-22 21:40:04.412
cmvk2e4lg00yj10qofa87lgwe	cmvk2e1ya00j010qocpb43z1p	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.419	2026-10-22 21:40:04.419
cmvk2e4lq00ym10qovuaxq27c	cmvk2e1yv00j610qo8qsw1g91	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.427	2026-10-22 21:40:04.427
cmvk2e4lx00yo10qo954oek68	cmvk2e1z300j910qoprojkzkj	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.433	2026-10-22 21:40:04.433
cmvk2e4m300yq10qoc7x6b7zv	cmvk2e1zd00jc10qoekwj6a2m	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.442	2026-10-22 21:40:04.442
cmvk2e4m700ys10qouz6tznk9	cmvk2e1zq00jf10qon2rqyrl1	cmuhjm5hy00007g6di3jovxng	115.00	2026-11-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.446	2026-10-22 21:40:04.446
cmvk2e4me00yw10qoeymnfg23	cmvk2e20p00jo10qoxqql70bo	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-27	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.453	2026-10-22 21:40:04.453
cmvk2e4n400z510qouqi3iqa5	cmvk2e22q00kc10qomrp1weci	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.478	2026-10-22 21:40:04.478
cmvk2e4n700z710qo0pjjb23l	cmvk2e23200kf10qo6q0e2tic	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.482	2026-10-22 21:40:04.482
cmvk2e4nb00z910qoubnvcjod	cmvk2e23m00ki10qoulyqnae4	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.486	2026-10-22 21:40:04.486
cmvk2e4nf00zb10qolfxcf5ys	cmvk2e24100kl10qorjekwidz	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-17	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.489	2026-10-22 21:40:04.489
cmvk2e4nm00zd10qodd9iog9j	cmvk2e24f00ko10qowjirabgu	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.496	2026-10-22 21:40:04.496
cmvk2e4nt00zg10qofnruvlm0	cmvk2e25200ku10qofc0p978p	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.503	2026-10-22 21:40:04.503
cmvk2e4o300zk10qocynmcquk	cmvk2e26d00l310qo5tfcm5iv	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.514	2026-10-22 21:40:04.514
cmvk2e4oi00zp10qo3o6vcgzu	cmvk2e27w00lf10qom9p26wiz	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.527	2026-10-22 21:40:04.527
cmvk2e4oq00zr10qoy3qzgqe2	cmvk2e28200li10qovdat671z	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.535	2026-10-22 21:40:04.535
cmvk2e4ow00zt10qov8l9whau	cmvk2e28e00ll10qowlkawpgt	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.541	2026-10-22 21:40:04.541
cmvk2e4p900zx10qop9uhmp9q	cmvk2e29b00lu10qog7rpgkcr	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.555	2026-10-22 21:40:04.555
cmvk2e4pg00zz10qowj4sm1ar	cmvk2e29m00lx10qo101embvd	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-20	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.562	2026-10-22 21:40:04.562
cmvk2e4po010110qomdflmtvg	cmvk2e2ac00m010qo5ptppc5o	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-27	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.569	2026-10-22 21:40:04.569
cmvk2e4px010310qoq6oeb784	cmvk2e2bg00m310qo6pqqxpjl	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-27	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.578	2026-10-22 21:40:04.578
cmvk2e4ql010510qotfseuwsx	cmvk2e2c200m610qoor5xfdo6	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-18	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.602	2026-10-22 21:40:04.602
cmvk2e4r4010810qowya25gdm	cmvk2e2cr00mc10qobys4bvnw	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.618	2026-10-22 21:40:04.618
cmvk2e4rf010a10qost25nyw6	cmvk2e2d700mf10qoox604aky	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.633	2026-10-22 21:40:04.633
cmvk2e4rp010c10qoqku1r6xc	cmvk2e2dk00mi10qob19yp1hd	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.642	2026-10-22 21:40:04.642
cmvk2e4rt010e10qovp0hxdjb	cmvk2e2e600ml10qoxvm5sc2r	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.648	2026-10-22 21:40:04.648
cmvk2e4rw010g10qo5jspzpac	cmvk2e2eg00mo10qokzbvud3z	cmuhjm5hy00007g6di3jovxng	115.00	2026-04-10	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.651	2026-10-22 21:40:04.651
cmvk2e4s6010i10qont7lb2i2	cmvk2e2fa00mr10qok97kyvqg	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.657	2026-10-22 21:40:04.657
cmvk2e4se010k10qovx08l6op	cmvk2e2fr00mu10qohapjlfv8	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-27	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.667	2026-10-22 21:40:04.667
cmvk2e4t6010o10qo2sbom7dq	cmvk2e2h100n310qoxejneoi1	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.696	2026-10-22 21:40:04.696
cmvk2e4tt010s10qo4fdxsz7w	cmvk2e2i200nc10qoy0x32f8q	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.716	2026-10-22 21:40:04.716
cmvk2e4u8010w10qowhhhhonr	cmvk2e2ja00nl10qoc5fvj7au	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-27	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.735	2026-10-22 21:40:04.735
cmvk2e4uk010y10qoy8g5btim	cmvk2e2kl00no10qo92hh1f3b	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.742	2026-10-22 21:40:04.742
cmvk2e4v0011310qoqac3a7br	cmvk2e2oa00o010qo3nqbcmwy	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.763	2026-10-22 21:40:04.763
cmvk2e4v5011510qoacwy4gbd	cmvk2e2ox00o310qo1fp7jf9k	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-12	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.768	2026-10-22 21:40:04.768
cmvk2e4ve011910qo68y99mkb	cmvk2e2q300oc10qot2xa2ayx	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.777	2026-10-22 21:40:04.777
cmvk2e4vo011d10qo9gkwe9iv	cmvk2e2r400ol10qo3w3iir2x	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.786	2026-10-22 21:40:04.786
cmvk2e4vx011f10qo3lmtliua	cmvk2e2rf00oo10qoel5fv9j7	cmuhjm5hy00007g6di3jovxng	85.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.794	2026-10-22 21:40:04.794
cmvk2e4wh011l10qof52lhmzw	cmvk2e2tc00p310qoefmn8evv	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-26	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.814	2026-10-22 21:40:04.814
cmvk2e4x2011r10qolfa8nvas	cmvk2e2w500pi10qovwf8e6aw	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.837	2026-10-22 21:40:04.837
cmvk2e4xa011t10qomumtadx1	cmvk2e2wt00pl10qor4zldg40	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.843	2026-10-22 21:40:04.843
cmvk2e4xo011v10qozt710d7s	cmvk2e2x500po10qomph1l3p6	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.858	2026-10-22 21:40:04.858
cmvk2e4xx011x10qo31facxvh	cmvk2e2xi00pr10qoyc5wzqn7	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.864	2026-10-22 21:40:04.864
cmvk2e4y9012010qoap935zdp	cmvk2e2yc00px10qoh5przmtm	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.878	2026-10-22 21:40:04.878
cmvk2e4yg012210qo6k94basf	cmvk2e2yn00q010qonug7nlo4	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-13	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.886	2026-10-22 21:40:04.886
cmvk2e4yq012410qoiwxcgvhi	cmvk2e2z200q310qobwzccw2u	cmuhjm5hy00007g6di3jovxng	115.00	2026-12-09	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.895	2026-10-22 21:40:04.895
cmvk2e4yy012610qoskv8bmlc	cmvk2e2zb00q610qopmdhaaas	cmuhjm5hy00007g6di3jovxng	115.00	2026-09-19	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.905	2026-10-22 21:40:04.905
cmvk2e4z9012a10qo2ggmbq5c	cmvk2e30p00qf10qo2i71tdoy	cmuhjm5hy00007g6di3jovxng	115.00	2026-10-18	Geïmporteerd uit het oude systeem	\N	2026-10-22 21:40:04.916	2026-10-22 21:40:04.916
\.


--
-- Data for Name: donation_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donation_settings (id, "defaultAmount", "createdAt", "updatedAt") FROM stdin;
default	115.00	2026-09-18 21:41:53.831	2026-10-17 20:53:48.459
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollments (id, "studentId", "classId", "startDate", "endDate", status, "createdAt", "updatedAt") FROM stdin;
cmvk2e0fl005l10qorizaxu15	cmvk2e0f8005j10qop7xz3aez	cmvf3sz07000m01n4lwmfsd5y	2022-03-05 00:00:00	\N	active	2026-10-22 21:39:59.025	2026-10-22 21:39:59.025
cmvk2e0fx005o10qo9ytr9c7a	cmvk2e0fr005m10qoxk85a4gx	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:39:59.037	2026-10-22 21:39:59.037
cmvk2e0gb005r10qo1aqe0h44	cmvk2e0g3005p10qomvyxe6dj	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.051	2026-10-22 21:39:59.051
cmvk2e0gl005u10qo733cp9nf	cmvk2e0ge005s10qo7a1ppbs9	cmvf3whkj000v01n4ykwe3g2y	2024-01-13 00:00:00	\N	active	2026-10-22 21:39:59.061	2026-10-22 21:39:59.061
cmvk2e0gw005x10qokrzftif2	cmvk2e0gp005v10qom1efo6sv	cmvf3s76a000j01n45dn103g9	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.072	2026-10-22 21:39:59.072
cmvk2e0h6006010qot8gdxxym	cmvk2e0gz005y10qotwaklrmg	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.082	2026-10-22 21:39:59.082
cmvk2e0hf006310qoxafiilcd	cmvk2e0h9006110qoy3bg7l30	cmvf3yg7i001101n4g8wmjtf0	2025-10-21 00:00:00	\N	active	2026-10-22 21:39:59.091	2026-10-22 21:39:59.091
cmvk2e0hq006610qobfxdie1s	cmvk2e0hi006410qoeec2qw1j	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.102	2026-10-22 21:39:59.102
cmvk2e0i4006910qoxaxklvyx	cmvk2e0hu006710qokk2xy663	cmvf3me9p000d01n47nyq7jbz	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.116	2026-10-22 21:39:59.116
cmvk2e0il006c10qowjmxhclu	cmvk2e0id006a10qo4fp7ykud	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.133	2026-10-22 21:39:59.133
cmvk2e0iu006f10qov2husjb0	cmvk2e0io006d10qo3rpuu4jx	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.142	2026-10-22 21:39:59.142
cmvk2e0j5006i10qool4p36ll	cmvk2e0iy006g10qop9g8g78n	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.153	2026-10-22 21:39:59.153
cmvk2e0jh006l10qoo533zcns	cmvk2e0j9006j10qooapareag	cmvf3yg7i001101n4g8wmjtf0	2026-10-04 00:00:00	\N	active	2026-10-22 21:39:59.165	2026-10-22 21:39:59.165
cmvk2e0jr006o10qo32lyadc3	cmvk2e0jk006m10qo671j2ft1	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.175	2026-10-22 21:39:59.175
cmvk2e0k1006r10qopv0poopc	cmvk2e0ju006p10qo8s1059sq	cmvf3il9z000401n44094dbvs	2021-10-10 00:00:00	\N	active	2026-10-22 21:39:59.186	2026-10-22 21:39:59.186
cmvk2e0kl006u10qowa0kzoqg	cmvk2e0kd006s10qowzu5tucn	cmvf3k9w0000701n4r93hf29x	2026-05-24 00:00:00	\N	active	2026-10-22 21:39:59.205	2026-10-22 21:39:59.205
cmvk2e0ky006x10qohw414dl9	cmvk2e0ko006v10qocpipelf3	cmvf3k9w0000701n4r93hf29x	2026-05-24 00:00:00	\N	active	2026-10-22 21:39:59.218	2026-10-22 21:39:59.218
cmvk2e0lb007010qo8zyos80l	cmvk2e0l2006y10qok6uxeupm	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.231	2026-10-22 21:39:59.231
cmvk2e0lm007310qo6hkcejvf	cmvk2e0lf007110qox7244gt0	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.242	2026-10-22 21:39:59.242
cmvk2e0lu007610qoca80wy4r	cmvk2e0lo007410qophya3uil	cmvf3lnsd000a01n4cf7vrggg	2022-03-05 00:00:00	\N	active	2026-10-22 21:39:59.25	2026-10-22 21:39:59.25
cmvk2e0m1007910qo8ddhuz9d	cmvk2e0lw007710qotmosrlq5	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.257	2026-10-22 21:39:59.257
cmvk2e0ma007c10qo300dfelx	cmvk2e0m4007a10qotbwxc7eb	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.266	2026-10-22 21:39:59.266
cmvk2e0mi007f10qoa736bwyv	cmvk2e0md007d10qo9zsykd0a	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.274	2026-10-22 21:39:59.274
cmvk2e0mv007i10qo00gqex4i	cmvk2e0mn007g10qogjizo77d	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.287	2026-10-22 21:39:59.287
cmvk2e0n3007l10qow5b5s1nj	cmvk2e0mx007j10qow4xt9f1o	cmvf3k9w0000701n4r93hf29x	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.295	2026-10-22 21:39:59.295
cmvk2e0ne007o10qoi52vv2xo	cmvk2e0n7007m10qo74e8y9jm	cmvf3yg7i001101n4g8wmjtf0	2025-10-11 00:00:00	\N	active	2026-10-22 21:39:59.306	2026-10-22 21:39:59.306
cmvk2e0nr007r10qokrk7k2p3	cmvk2e0nk007p10qoaxw6gch4	cmvf3lnsd000a01n4cf7vrggg	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.319	2026-10-22 21:39:59.319
cmvk2e0o3007u10qoi59rs7zk	cmvk2e0nu007s10qo0xmaj30h	cmvf3yg7i001101n4g8wmjtf0	2025-05-24 00:00:00	\N	active	2026-10-22 21:39:59.331	2026-10-22 21:39:59.331
cmvk2e0oe007x10qo58rhspep	cmvk2e0o6007v10qoxdixzsrp	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.342	2026-10-22 21:39:59.342
cmvk2e0ox008010qovq6pn7zn	cmvk2e0oi007y10qo7g8zg9md	cmvf3s76a000j01n45dn103g9	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.361	2026-10-22 21:39:59.361
cmvk2e0p5008310qoxmp0eex1	cmvk2e0oz008110qox0ws44dw	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.369	2026-10-22 21:39:59.369
cmvk2e0pf008610qohz1eyyo5	cmvk2e0pa008410qo4r0eavjw	cmvf3whkj000v01n4ykwe3g2y	2025-10-04 00:00:00	\N	active	2026-10-22 21:39:59.379	2026-10-22 21:39:59.379
cmvk2e0pq008910qoxepzo2j5	cmvk2e0pi008710qo1720qe77	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.39	2026-10-22 21:39:59.39
cmvk2e0q4008c10qoc8cfkr16	cmvk2e0pt008a10qo5f82vua2	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.404	2026-10-22 21:39:59.404
cmvk2e0qp008f10qobua5ecfv	cmvk2e0qh008d10qoanwe1tei	cmvf3s76a000j01n45dn103g9	2021-11-06 00:00:00	\N	active	2026-10-22 21:39:59.425	2026-10-22 21:39:59.425
cmvk2e0r2008i10qohugs9lpt	cmvk2e0qs008g10qo49tbyhpf	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.438	2026-10-22 21:39:59.438
cmvk2e0rc008l10qo8pyams9u	cmvk2e0r6008j10qow2kjqodr	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.448	2026-10-22 21:39:59.448
cmvk2e0rl008o10qo6bhxch4g	cmvk2e0re008m10qoh4nxmdu8	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.457	2026-10-22 21:39:59.457
cmvk2e0rv008r10qoeapqi20j	cmvk2e0rp008p10qohkq8qlhx	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.467	2026-10-22 21:39:59.467
cmvk2e0s3008u10qosb137ujx	cmvk2e0rz008s10qojfdjm4m8	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.475	2026-10-22 21:39:59.475
cmvk2e0se008x10qo2t5xmpcm	cmvk2e0s5008v10qopeicutss	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.486	2026-10-22 21:39:59.486
cmvk2e0so009010qo7cobavca	cmvk2e0sg008y10qo3jv48tmq	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.496	2026-10-22 21:39:59.496
cmvk2e0sw009310qo399vxktw	cmvk2e0sq009110qorf0zejq7	cmvf3s76a000j01n45dn103g9	2026-10-04 00:00:00	\N	active	2026-10-22 21:39:59.504	2026-10-22 21:39:59.504
cmvk2e0t2009610qob6u1h4s1	cmvk2e0sy009410qo6gdrb9th	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.51	2026-10-22 21:39:59.51
cmvk2e0ta009910qojxxngwdi	cmvk2e0t4009710qo6y5w6a8d	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.518	2026-10-22 21:39:59.518
cmvk2e0tl009c10qox5appd2s	cmvk2e0tc009a10qopmfmhk8v	cmvf3s76a000j01n45dn103g9	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.529	2026-10-22 21:39:59.529
cmvk2e0u1009f10qo9zi9ynr3	cmvk2e0tp009d10qotj9m8qof	cmvf3vi1f000s01n4dpx60bmu	2026-10-09 00:00:00	\N	active	2026-10-22 21:39:59.545	2026-10-22 21:39:59.545
cmvk2e0ub009i10qok2k0bd3u	cmvk2e0u4009g10qojvw6fzq2	cmvf3whkj000v01n4ykwe3g2y	2023-10-14 00:00:00	\N	active	2026-10-22 21:39:59.555	2026-10-22 21:39:59.555
cmvk2e0us009l10qo6nzfa2ol	cmvk2e0uf009j10qonmsrbolk	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:39:59.572	2026-10-22 21:39:59.572
cmvk2e0v4009o10qoy401m1jo	cmvk2e0ux009m10qompgb7v0d	cmvf3yg7i001101n4g8wmjtf0	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.584	2026-10-22 21:39:59.584
cmvk2e0vc009r10qogdhhcli9	cmvk2e0v8009p10qoxvtkgw0e	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.592	2026-10-22 21:39:59.592
cmvk2e0vj009u10qodpczr81v	cmvk2e0ve009s10qocx5lazvz	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:39:59.599	2026-10-22 21:39:59.599
cmvk2e0vn009x10qob51hgpmu	cmvk2e0vk009v10qocx5xules	cmvf3whkj000v01n4ykwe3g2y	2025-10-04 00:00:00	\N	active	2026-10-22 21:39:59.604	2026-10-22 21:39:59.604
cmvk2e0w300a210qoznw6o0zi	cmvk2e0vz00a010qoqk2qppbc	cmvk2e0vr009y10qo7yam17hh	2021-08-06 00:00:00	\N	active	2026-10-22 21:39:59.619	2026-10-22 21:39:59.619
cmvk2e0wb00a510qonrdf34bp	cmvk2e0w600a310qomk482mit	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.627	2026-10-22 21:39:59.627
cmvk2e0wk00a810qo82ihz1i8	cmvk2e0we00a610qocxbkzyuy	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.636	2026-10-22 21:39:59.636
cmvk2e0wq00ab10qoe3j6hi8l	cmvk2e0wm00a910qoj3lq7cib	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.642	2026-10-22 21:39:59.642
cmvk2e0wz00ae10qo1azx27ku	cmvk2e0wt00ac10qo7vfmjd0a	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.651	2026-10-22 21:39:59.651
cmvk2e0x800ah10qoctx0gn75	cmvk2e0x200af10qogjjlyhze	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:39:59.66	2026-10-22 21:39:59.66
cmvk2e0xh00ak10qoluzdptba	cmvk2e0xb00ai10qokuc5bs2q	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.669	2026-10-22 21:39:59.669
cmvk2e0xu00aq10qokyksspm5	cmvk2e0xp00ao10qol3ssoyki	cmvf3s76a000j01n45dn103g9	2022-03-05 00:00:00	\N	active	2026-10-22 21:39:59.682	2026-10-22 21:39:59.682
cmvk2e0y000at10qomavy0xqx	cmvk2e0xw00ar10qo73ok5r4k	cmvf3vi1f000s01n4dpx60bmu	2026-10-18 00:00:00	\N	active	2026-10-22 21:39:59.688	2026-10-22 21:39:59.688
cmvk2e0y800aw10qovazv4gcd	cmvk2e0y200au10qouns1kkb0	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.696	2026-10-22 21:39:59.696
cmvk2e0yo00b210qoy4huve97	cmvk2e0yj00b010qowwfl1nln	cmvf3me9p000d01n47nyq7jbz	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.712	2026-10-22 21:39:59.712
cmvk2e0z000b510qos3us8eke	cmvk2e0ys00b310qomfp2y9kx	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:39:59.724	2026-10-22 21:39:59.724
cmvk2e0z700b810qom1k2gm1k	cmvk2e0z200b610qoz3wbt9k3	cmvf3whkj000v01n4ykwe3g2y	2023-03-03 00:00:00	\N	active	2026-10-22 21:39:59.731	2026-10-22 21:39:59.731
cmvk2e0zc00bb10qo2ndbr7xz	cmvk2e0z900b910qorgtkuon9	cmvf3il9z000401n44094dbvs	2023-03-03 00:00:00	\N	active	2026-10-22 21:39:59.736	2026-10-22 21:39:59.736
cmvk2e0zj00be10qoa97uvlmy	cmvk2e0ze00bc10qogbcciv39	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:39:59.743	2026-10-22 21:39:59.743
cmvk2e0zp00bh10qou4husuwa	cmvk2e0zl00bf10qouw396q6q	cmvc9nx0r000601rytht9l9lj	2025-10-11 00:00:00	\N	active	2026-10-22 21:39:59.749	2026-10-22 21:39:59.749
cmvk2e0zz00bk10qobads81kx	cmvk2e0zr00bi10qofdc5fch4	cmvc9nx0r000601rytht9l9lj	2025-10-11 00:00:00	\N	active	2026-10-22 21:39:59.759	2026-10-22 21:39:59.759
cmvk2e10a00bn10qoxs78arxc	cmvk2e10200bl10qoxc22xsjq	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.77	2026-10-22 21:39:59.77
cmvk2e10j00bq10qoha58m0ac	cmvk2e10c00bo10qoclc4ctlx	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:39:59.779	2026-10-22 21:39:59.779
cmvk2e10t00bt10qo3rnwhjho	cmvk2e10m00br10qo701zsodd	cmvf3il9z000401n44094dbvs	2020-03-15 00:00:00	\N	active	2026-10-22 21:39:59.789	2026-10-22 21:39:59.789
cmvk2e11200bw10qolhlyq4hx	cmvk2e10v00bu10qocjrna6gx	cmvf3sz07000m01n4lwmfsd5y	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.798	2026-10-22 21:39:59.798
cmvk2e11a00bz10qocvk10rut	cmvk2e11500bx10qoey8wmotp	cmvf3sz07000m01n4lwmfsd5y	2022-03-05 00:00:00	\N	active	2026-10-22 21:39:59.806	2026-10-22 21:39:59.806
cmvk2e11q00c510qo7irg1af4	cmvk2e11m00c310qoopdaoqx8	cmvf3il9z000401n44094dbvs	2023-04-16 00:00:00	\N	active	2026-10-22 21:39:59.822	2026-10-22 21:39:59.822
cmvk2e11v00c810qoxoackw88	cmvk2e11s00c610qo5ocm5vo0	cmvf3il9z000401n44094dbvs	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.827	2026-10-22 21:39:59.827
cmvk2e12600cb10qowcof7nkm	cmvk2e11y00c910qoplfuiyvr	cmvf3whkj000v01n4ykwe3g2y	2024-01-13 00:00:00	\N	active	2026-10-22 21:39:59.838	2026-10-22 21:39:59.838
cmvk2e12c00ce10qosq7o3hus	cmvk2e12800cc10qouya3fezi	cmvf3me9p000d01n47nyq7jbz	2024-01-13 00:00:00	\N	active	2026-10-22 21:39:59.844	2026-10-22 21:39:59.844
cmvk2e12o00ch10qoahjry43p	cmvk2e12e00cf10qosb0eh1aq	cmvf3whkj000v01n4ykwe3g2y	2025-11-15 00:00:00	\N	active	2026-10-22 21:39:59.856	2026-10-22 21:39:59.856
cmvk2e12v00ck10qofv21azth	cmvk2e12q00ci10qoual19fsm	cmvf3lnsd000a01n4cf7vrggg	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.863	2026-10-22 21:39:59.863
cmvk2e13300cn10qoni8wcoh9	cmvk2e12y00cl10qok0tp3x9k	cmvf3yg7i001101n4g8wmjtf0	2023-03-04 00:00:00	\N	active	2026-10-22 21:39:59.871	2026-10-22 21:39:59.871
cmvk2e13c00cq10qo0p1n8mpx	cmvk2e13600co10qofwnaqw2z	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.88	2026-10-22 21:39:59.88
cmvk2e13i00ct10qos3yx4ci7	cmvk2e13e00cr10qox5qbg0cz	cmvf3sz07000m01n4lwmfsd5y	2024-01-14 00:00:00	\N	active	2026-10-22 21:39:59.886	2026-10-22 21:39:59.886
cmvk2e13t00cw10qoi06pdzw5	cmvk2e13l00cu10qoti1pe8e6	cmvf3sz07000m01n4lwmfsd5y	2024-01-13 00:00:00	\N	active	2026-10-22 21:39:59.897	2026-10-22 21:39:59.897
cmvk2e14000cz10qoj88hh4wf	cmvk2e13w00cx10qo8dkntsp3	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:39:59.904	2026-10-22 21:39:59.904
cmvk2e14a00d210qo3lfe63me	cmvk2e14400d010qoperb2tqj	cmvf3vi1f000s01n4dpx60bmu	2026-10-17 00:00:00	\N	active	2026-10-22 21:39:59.914	2026-10-22 21:39:59.914
cmvk2e14i00d510qo9tu3pmoa	cmvk2e14c00d310qoag2wsgyp	cmvf3whkj000v01n4ykwe3g2y	2024-01-13 00:00:00	\N	active	2026-10-22 21:39:59.922	2026-10-22 21:39:59.922
cmvk2e14s00d810qodjc6ebqx	cmvk2e14k00d610qob0botcsz	cmvf3vi1f000s01n4dpx60bmu	2026-10-09 00:00:00	\N	active	2026-10-22 21:39:59.932	2026-10-22 21:39:59.932
cmvk2e15400db10qo8q34yhfz	cmvk2e14v00d910qojo53f9k3	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.944	2026-10-22 21:39:59.944
cmvk2e15b00de10qodxg2rc3h	cmvk2e15700dc10qoiwgsj8f9	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.951	2026-10-22 21:39:59.951
cmvk2e15k00dh10qo8za8gnv4	cmvk2e15e00df10qoad1n2rjx	cmvf3me9p000d01n47nyq7jbz	2025-11-16 00:00:00	\N	active	2026-10-22 21:39:59.96	2026-10-22 21:39:59.96
cmvk2e15s00dk10qo1nemg5xz	cmvk2e15o00di10qo657spol2	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.968	2026-10-22 21:39:59.968
cmvk2e16600dn10qoxe50z415	cmvk2e16200dl10qobzwefbsi	cmvf3whkj000v01n4ykwe3g2y	2025-11-16 00:00:00	\N	active	2026-10-22 21:39:59.982	2026-10-22 21:39:59.982
cmvk2e16d00dq10qo9ssa73g7	cmvk2e16700do10qoked9sudv	cmvf3s76a000j01n45dn103g9	2025-09-14 00:00:00	\N	active	2026-10-22 21:39:59.989	2026-10-22 21:39:59.989
cmvk2e16q00dt10qo5577xuf6	cmvk2e16h00dr10qotnvucg70	cmvc9nx0r000601rytht9l9lj	2025-09-14 00:00:00	\N	active	2026-10-22 21:40:00.002	2026-10-22 21:40:00.002
cmvk2e17p00dw10qozjz64kd2	cmvk2e16w00du10qoskeyh0lb	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.038	2026-10-22 21:40:00.038
cmvk2e18b00dz10qo8ajee8nb	cmvk2e17u00dx10qonhsbuina	cmvf3sz07000m01n4lwmfsd5y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.059	2026-10-22 21:40:00.059
cmvk2e19200e210qoxpjx5703	cmvk2e18k00e010qokp92c4cf	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.086	2026-10-22 21:40:00.086
cmvk2e19f00e510qovkwvaty1	cmvk2e19600e310qoc9g43cye	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:40:00.099	2026-10-22 21:40:00.099
cmvk2e0yg00az10qok8er4q2e	cmvk2e0yb00ax10qopadd4f4c	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	2026-10-23 09:03:45.566	withdrawn	2026-10-22 21:39:59.704	2026-10-23 09:03:45.567
cmvk2e0xn00an10qod7wo4s0z	cmvk2e0xj00al10qovd7t53vj	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:39:59.675	2026-10-24 15:10:26.044
cmvk2e19w00e810qocij51fkj	cmvk2e19m00e610qovhbftiyr	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:40:00.116	2026-10-22 21:40:00.116
cmvk2e1by00eb10qov7mu0mpb	cmvk2e1af00e910qoj9m97yrh	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.19	2026-10-22 21:40:00.19
cmvk2e1cs00ee10qo4zvq2f3y	cmvk2e1c800ec10qofadi7fwm	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.22	2026-10-22 21:40:00.22
cmvk2e1dl00eh10qosf8efjm8	cmvk2e1d700ef10qoj7lafdi6	cmvf3whkj000v01n4ykwe3g2y	2025-10-04 00:00:00	\N	active	2026-10-22 21:40:00.249	2026-10-22 21:40:00.249
cmvk2e1ho00ek10qo0qpoyloi	cmvk2e1dq00ei10qo1e12120n	cmvf3whkj000v01n4ykwe3g2y	2025-10-04 00:00:00	\N	active	2026-10-22 21:40:00.396	2026-10-22 21:40:00.396
cmvk2e1hy00en10qos7c086vq	cmvk2e1hr00el10qorft4v8hb	cmvf3me9p000d01n47nyq7jbz	2022-03-05 00:00:00	\N	active	2026-10-22 21:40:00.406	2026-10-22 21:40:00.406
cmvk2e1i600eq10qo7kafhg6f	cmvk2e1i300eo10qoactgc813	cmvc9nx0r000601rytht9l9lj	2025-10-04 00:00:00	\N	active	2026-10-22 21:40:00.414	2026-10-22 21:40:00.414
cmvk2e1ie00et10qo6njbgoyr	cmvk2e1ib00er10qo0dxjt8q4	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:40:00.422	2026-10-22 21:40:00.422
cmvk2e1io00ew10qodbk0upgt	cmvk2e1ii00eu10qouggo8ohv	cmvf3il9z000401n44094dbvs	2024-11-02 00:00:00	\N	active	2026-10-22 21:40:00.432	2026-10-22 21:40:00.432
cmvk2e1is00ez10qo7j9954iz	cmvk2e1iq00ex10qolv7h3znf	cmvf3sz07000m01n4lwmfsd5y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.436	2026-10-22 21:40:00.436
cmvk2e1iz00f210qoo7th4b8f	cmvk2e1iw00f010qouldd0whw	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.443	2026-10-22 21:40:00.443
cmvk2e1j600f510qocixt3bzn	cmvk2e1j300f310qokwlctw42	cmvf3s76a000j01n45dn103g9	2022-11-05 00:00:00	\N	active	2026-10-22 21:40:00.45	2026-10-22 21:40:00.45
cmvk2e1j900f810qofwftx1zj	cmvk2e1j700f610qoqieb3sy7	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.453	2026-10-22 21:40:00.453
cmvk2e1jd00fb10qonikhapuk	cmvk2e1jb00f910qoxwwq9wec	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.457	2026-10-22 21:40:00.457
cmvk2e1jm00fe10qo4fmtdp94	cmvk2e1jf00fc10qodoqzhons	cmvf3s76a000j01n45dn103g9	2020-01-03 00:00:00	\N	active	2026-10-22 21:40:00.466	2026-10-22 21:40:00.466
cmvk2e1jq00fh10qoomxs55vm	cmvk2e1jn00ff10qo6b20bk1d	cmvf3whkj000v01n4ykwe3g2y	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.47	2026-10-22 21:40:00.47
cmvk2e1jv00fk10qogxwrtk9q	cmvk2e1js00fi10qoblhlylqf	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.475	2026-10-22 21:40:00.475
cmvk2e1ko00fn10qoltlykxxf	cmvk2e1k100fl10qohvdgqlc8	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.504	2026-10-22 21:40:00.504
cmvk2e1l400fq10qoipwaj819	cmvk2e1ku00fo10qodpfpq0ib	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.52	2026-10-22 21:40:00.52
cmvk2e1le00ft10qoud9v29w7	cmvk2e1l900fr10qo6euq3n2l	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.53	2026-10-22 21:40:00.53
cmvk2e1ll00fw10qomuf0fpci	cmvk2e1lh00fu10qodi34nlo8	cmvf3me9p000d01n47nyq7jbz	2023-03-04 00:00:00	\N	active	2026-10-22 21:40:00.537	2026-10-22 21:40:00.537
cmvk2e1lu00fz10qob2aydcwx	cmvk2e1ln00fx10qob4gtsuxb	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:40:00.546	2026-10-22 21:40:00.546
cmvk2e1m200g210qoijui9r2g	cmvk2e1lz00g010qor4spgnh3	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.554	2026-10-22 21:40:00.554
cmvk2e1ma00g510qok5c7ez2s	cmvk2e1m500g310qogosi93ht	cmvf3me9p000d01n47nyq7jbz	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.562	2026-10-22 21:40:00.562
cmvk2e1mf00g810qo43fc8pmq	cmvk2e1mc00g610qokmrvsajm	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.567	2026-10-22 21:40:00.567
cmvk2e1mz00gb10qonp17b283	cmvk2e1mh00g910qof9zdk9s0	cmvf3yg7i001101n4g8wmjtf0	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.587	2026-10-22 21:40:00.587
cmvk2e1n600ge10qoflyy1ll6	cmvk2e1n100gc10qoy5htea82	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.594	2026-10-22 21:40:00.594
cmvk2e1nh00gh10qodmiw4ycp	cmvk2e1n800gf10qopkdmfra7	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.605	2026-10-22 21:40:00.605
cmvk2e1nn00gk10qoro3sxdmu	cmvk2e1nj00gi10qo6ptkzrjw	cmvf3k9w0000701n4r93hf29x	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:00.611	2026-10-22 21:40:00.611
cmvk2e1nw00gn10qoe5kavr3u	cmvk2e1nq00gl10qok2h5e8h8	cmvf3sz07000m01n4lwmfsd5y	2019-09-05 00:00:00	\N	active	2026-10-22 21:40:00.62	2026-10-22 21:40:00.62
cmvk2e1o400gq10qop08mu373	cmvk2e1nz00go10qosv3meac4	cmvf3k9w0000701n4r93hf29x	2020-01-01 00:00:00	\N	active	2026-10-22 21:40:00.628	2026-10-22 21:40:00.628
cmvk2e1oa00gt10qolo8m2j81	cmvk2e1o600gr10qourhjh39x	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.634	2026-10-22 21:40:00.634
cmvk2e1og00gw10qon4x2ds3b	cmvk2e1oc00gu10qoce37z8sn	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:40:00.64	2026-10-22 21:40:00.64
cmvk2e1ol00gz10qokn1mdyfz	cmvk2e1oh00gx10qobcvz39da	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.645	2026-10-22 21:40:00.645
cmvk2e1ox00h210qoicrxtynr	cmvk2e1on00h010qoznju2wm0	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.657	2026-10-22 21:40:00.657
cmvk2e1p600h510qonv00a636	cmvk2e1p000h310qoy77ot97c	cmvf3whkj000v01n4ykwe3g2y	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:00.666	2026-10-22 21:40:00.666
cmvk2e1pk00h810qokn6mm69l	cmvk2e1pb00h610qohomlnt99	cmvf3il9z000401n44094dbvs	2022-11-05 00:00:00	\N	active	2026-10-22 21:40:00.68	2026-10-22 21:40:00.68
cmvk2e1pr00hb10qoeo1ycg84	cmvk2e1pn00h910qo26r9kzvv	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.687	2026-10-22 21:40:00.687
cmvk2e1q300he10qolcib7kcr	cmvk2e1pv00hc10qo70s7eud4	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.699	2026-10-22 21:40:00.699
cmvk2e1qj00hh10qo8m230c7l	cmvk2e1qc00hf10qolumdg9rh	cmvf3s76a000j01n45dn103g9	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:00.715	2026-10-22 21:40:00.715
cmvk2e1qq00hk10qohsiak6ot	cmvk2e1ql00hi10qomvtqdm69	cmvf3vi1f000s01n4dpx60bmu	2026-10-10 00:00:00	\N	active	2026-10-22 21:40:00.722	2026-10-22 21:40:00.722
cmvk2e1qz00hn10qo4kczhk5i	cmvk2e1qu00hl10qol44lbi9l	cmvf3me9p000d01n47nyq7jbz	2024-11-02 00:00:00	\N	active	2026-10-22 21:40:00.731	2026-10-22 21:40:00.731
cmvk2e1re00hq10qogr1y039p	cmvk2e1r300ho10qoohbq1j9b	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.746	2026-10-22 21:40:00.746
cmvk2e1rx00ht10qoeu0rlhl7	cmvk2e1rl00hr10qoln6c107h	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.765	2026-10-22 21:40:00.765
cmvk2e1st00hw10qocqnkon3v	cmvk2e1s000hu10qovy3i6l19	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.797	2026-10-22 21:40:00.797
cmvk2e1tf00hz10qoelc47hjn	cmvk2e1t400hx10qody17xdw5	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.819	2026-10-22 21:40:00.819
cmvk2e1tu00i210qok761cbdh	cmvk2e1tk00i010qonijxikwe	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.834	2026-10-22 21:40:00.834
cmvk2e1u900i510qoonxhy8ia	cmvk2e1tz00i310qoo67eujha	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.849	2026-10-22 21:40:00.849
cmvk2e1uo00i810qoaa82o885	cmvk2e1ug00i610qo7n6jek1u	cmvf3whkj000v01n4ykwe3g2y	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:00.864	2026-10-22 21:40:00.864
cmvk2e1v300ib10qoiwfla2ue	cmvk2e1ut00i910qocffcgu3k	cmvf3k9w0000701n4r93hf29x	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.879	2026-10-22 21:40:00.879
cmvk2e1vk00ie10qo8o04utyg	cmvk2e1v700ic10qont684rtb	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.896	2026-10-22 21:40:00.896
cmvk2e1vt00ih10qoc1pfnfqi	cmvk2e1vn00if10qoa5gn8yl7	cmvf3lnsd000a01n4cf7vrggg	2023-10-14 00:00:00	\N	active	2026-10-22 21:40:00.905	2026-10-22 21:40:00.905
cmvk2e1w200ik10qoxez0yf8f	cmvk2e1vx00ii10qoh5v4lhfn	cmvf3yg7i001101n4g8wmjtf0	2025-10-01 00:00:00	\N	active	2026-10-22 21:40:00.914	2026-10-22 21:40:00.914
cmvk2e1wb00in10qo8pnqlmm9	cmvk2e1w500il10qoq9493xwt	cmvc9nx0r000601rytht9l9lj	2025-10-01 00:00:00	\N	active	2026-10-22 21:40:00.923	2026-10-22 21:40:00.923
cmvk2e1wi00iq10qoe9ua6er6	cmvk2e1wd00io10qool1z6725	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:00.93	2026-10-22 21:40:00.93
cmvk2e1wr00it10qo6dm6ixe6	cmvk2e1wl00ir10qozqju3tjf	cmvf3il9z000401n44094dbvs	2022-03-05 00:00:00	\N	active	2026-10-22 21:40:00.939	2026-10-22 21:40:00.939
cmvk2e1xn00iw10qo9pb27v9f	cmvk2e1wx00iu10qocetv78hy	cmvf3me9p000d01n47nyq7jbz	2021-04-03 00:00:00	\N	active	2026-10-22 21:40:00.971	2026-10-22 21:40:00.971
cmvk2e1y500iz10qox745nyej	cmvk2e1xx00ix10qo5qpio2jr	cmvf3lnsd000a01n4cf7vrggg	2021-04-03 00:00:00	\N	active	2026-10-22 21:40:00.99	2026-10-22 21:40:00.99
cmvk2e1yf00j210qoqyspekxt	cmvk2e1ya00j010qocpb43z1p	cmvf3sz07000m01n4lwmfsd5y	2022-03-05 00:00:00	\N	active	2026-10-22 21:40:00.999	2026-10-22 21:40:00.999
cmvk2e1ys00j510qo8tn84z7h	cmvk2e1yj00j310qo2h047zs8	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.012	2026-10-22 21:40:01.012
cmvk2e1z100j810qooge7h5k5	cmvk2e1yv00j610qo8qsw1g91	cmvf3me9p000d01n47nyq7jbz	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:01.021	2026-10-22 21:40:01.021
cmvk2e1zb00jb10qow4mwy9f5	cmvk2e1z300j910qoprojkzkj	cmvf3me9p000d01n47nyq7jbz	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:01.031	2026-10-22 21:40:01.031
cmvk2e1zo00je10qo4johuu4t	cmvk2e1zd00jc10qoekwj6a2m	cmvf3vi1f000s01n4dpx60bmu	2026-09-19 00:00:00	\N	active	2026-10-22 21:40:01.044	2026-10-22 21:40:01.044
cmvk2e1zy00jh10qohg42ggki	cmvk2e1zq00jf10qon2rqyrl1	cmvf3vi1f000s01n4dpx60bmu	2023-10-15 00:00:00	\N	active	2026-10-22 21:40:01.054	2026-10-22 21:40:01.054
cmvk2e20900jk10qo1s4boooh	cmvk2e20200ji10qoprpn0uqy	cmvf3sz07000m01n4lwmfsd5y	2023-10-15 00:00:00	\N	active	2026-10-22 21:40:01.065	2026-10-22 21:40:01.065
cmvk2e20l00jn10qon0uxeo8k	cmvk2e20e00jl10qow8e1yiow	cmvf3s76a000j01n45dn103g9	2023-10-21 00:00:00	\N	active	2026-10-22 21:40:01.077	2026-10-22 21:40:01.077
cmvk2e20v00jq10qo2hq9irs0	cmvk2e20p00jo10qoxqql70bo	cmvf3sz07000m01n4lwmfsd5y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.087	2026-10-22 21:40:01.087
cmvk2e21500jt10qoe78y3fgi	cmvk2e20y00jr10qoh8pjk1e2	cmvc9nx0r000601rytht9l9lj	2025-08-11 00:00:00	\N	active	2026-10-22 21:40:01.097	2026-10-22 21:40:01.097
cmvk2e21f00jw10qox1julpcp	cmvk2e21700ju10qo6yrh8nn9	cmvf3sz07000m01n4lwmfsd5y	2022-03-05 00:00:00	\N	active	2026-10-22 21:40:01.107	2026-10-22 21:40:01.107
cmvk2e21s00jz10qog9r278jc	cmvk2e21i00jx10qo09v4vqf9	cmvf3sz07000m01n4lwmfsd5y	2022-03-05 00:00:00	\N	active	2026-10-22 21:40:01.12	2026-10-22 21:40:01.12
cmvk2e22000k210qo5lm9ei67	cmvk2e21u00k010qooq70hbjl	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.128	2026-10-22 21:40:01.128
cmvk2e22a00k510qol52efqsw	cmvk2e22300k310qoaweja2qk	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.138	2026-10-22 21:40:01.138
cmvk2e22h00k810qo4qwevaka	cmvk2e22c00k610qoezyj455i	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.145	2026-10-22 21:40:01.145
cmvk2e22n00kb10qo32se9l98	cmvk2e22j00k910qobkyi27z6	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.151	2026-10-22 21:40:01.151
cmvk2e22w00ke10qorzeg51ge	cmvk2e22q00kc10qomrp1weci	cmvf3s76a000j01n45dn103g9	2023-03-04 00:00:00	\N	active	2026-10-22 21:40:01.16	2026-10-22 21:40:01.16
cmvk2e23b00kh10qovvadowd3	cmvk2e23200kf10qo6q0e2tic	cmvf3lnsd000a01n4cf7vrggg	2021-11-06 00:00:00	\N	active	2026-10-22 21:40:01.175	2026-10-22 21:40:01.175
cmvk2e23z00kk10qo66e4n75u	cmvk2e23m00ki10qoulyqnae4	cmvf3sz07000m01n4lwmfsd5y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.199	2026-10-22 21:40:01.199
cmvk2e24a00kn10qo4y0yik3v	cmvk2e24100kl10qorjekwidz	cmvf3sz07000m01n4lwmfsd5y	2025-05-24 00:00:00	\N	active	2026-10-22 21:40:01.21	2026-10-22 21:40:01.21
cmvk2e24n00kq10qoifue7xyh	cmvk2e24f00ko10qowjirabgu	cmvc9nx0r000601rytht9l9lj	2024-01-06 00:00:00	\N	active	2026-10-22 21:40:01.223	2026-10-22 21:40:01.223
cmvk2e24y00kt10qowdcdr2b0	cmvk2e24s00kr10qoea9lhkmq	cmvf3yg7i001101n4g8wmjtf0	2025-11-15 00:00:00	\N	active	2026-10-22 21:40:01.234	2026-10-22 21:40:01.234
cmvk2e25o00kw10qozy4rpgrs	cmvk2e25200ku10qofc0p978p	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.26	2026-10-22 21:40:01.26
cmvk2e25z00kz10qo0rc0xitd	cmvk2e25r00kx10qobmpq91u6	cmvf3s76a000j01n45dn103g9	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.271	2026-10-22 21:40:01.271
cmvk2e26800l210qoov41ni8q	cmvk2e26400l010qoq73zmzm7	cmvf3s76a000j01n45dn103g9	2021-11-06 00:00:00	\N	active	2026-10-22 21:40:01.28	2026-10-22 21:40:01.28
cmvk2e26n00l510qo66hupuiq	cmvk2e26d00l310qo5tfcm5iv	cmvf3k9w0000701n4r93hf29x	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.295	2026-10-22 21:40:01.295
cmvk2e26x00l810qopqme5uqd	cmvk2e26q00l610qonpxspp6x	cmvf3s76a000j01n45dn103g9	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.305	2026-10-22 21:40:01.305
cmvk2e27a00lb10qo60ur3s5x	cmvk2e27100l910qocx3ex4iz	cmvf3s76a000j01n45dn103g9	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.318	2026-10-22 21:40:01.318
cmvk2e27t00le10qov19ap7ax	cmvk2e27h00lc10qo7gh0hsiq	cmvf3il9z000401n44094dbvs	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.337	2026-10-22 21:40:01.337
cmvk2e28000lh10qo4nzlwuq0	cmvk2e27w00lf10qom9p26wiz	cmvf3lnsd000a01n4cf7vrggg	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.344	2026-10-22 21:40:01.344
cmvk2e28700lk10qo6h62nt2v	cmvk2e28200li10qovdat671z	cmvf3lnsd000a01n4cf7vrggg	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.351	2026-10-22 21:40:01.351
cmvk2e28o00ln10qoa0sija7d	cmvk2e28e00ll10qowlkawpgt	cmvf3me9p000d01n47nyq7jbz	2021-02-13 00:00:00	\N	active	2026-10-22 21:40:01.368	2026-10-22 21:40:01.368
cmvk2e29000lq10qoibqm2tp0	cmvk2e28s00lo10qo7e2bp1o3	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.38	2026-10-22 21:40:01.38
cmvk2e29800lt10qohgdcvpbk	cmvk2e29400lr10qocjdvc6b6	cmvk2e0vr009y10qo7yam17hh	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.388	2026-10-22 21:40:01.388
cmvk2e29j00lw10qod2edhkb2	cmvk2e29b00lu10qog7rpgkcr	cmvf3k9w0000701n4r93hf29x	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.399	2026-10-22 21:40:01.399
cmvk2e29z00lz10qoz74nkj0o	cmvk2e29m00lx10qo101embvd	cmvf3whkj000v01n4ykwe3g2y	2025-11-16 00:00:00	\N	active	2026-10-22 21:40:01.415	2026-10-22 21:40:01.415
cmvk2e2be00m210qo4197b8fh	cmvk2e2ac00m010qo5ptppc5o	cmvf3k9w0000701n4r93hf29x	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.466	2026-10-22 21:40:01.466
cmvk2e2bz00m510qoxbxc3qvb	cmvk2e2bg00m310qo6pqqxpjl	cmvf3il9z000401n44094dbvs	2024-04-06 00:00:00	\N	active	2026-10-22 21:40:01.487	2026-10-22 21:40:01.487
cmvk2e2cb00m810qooxu0hcvx	cmvk2e2c200m610qoor5xfdo6	cmvf3il9z000401n44094dbvs	2025-05-24 00:00:00	\N	active	2026-10-22 21:40:01.499	2026-10-22 21:40:01.499
cmvk2e2cj00mb10qou26v30ss	cmvk2e2cd00m910qon6uxqyar	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.507	2026-10-22 21:40:01.507
cmvk2e2d100me10qoqqt2b81z	cmvk2e2cr00mc10qobys4bvnw	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.525	2026-10-22 21:40:01.525
cmvk2e2dh00mh10qoasyic85k	cmvk2e2d700mf10qoox604aky	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.541	2026-10-22 21:40:01.541
cmvk2e2dy00mk10qow97exdmm	cmvk2e2dk00mi10qob19yp1hd	cmvf3whkj000v01n4ykwe3g2y	2025-11-22 00:00:00	\N	active	2026-10-22 21:40:01.558	2026-10-22 21:40:01.558
cmvk2e2ed00mn10qo3lnkvjsj	cmvk2e2e600ml10qoxvm5sc2r	cmvf3whkj000v01n4ykwe3g2y	2025-11-22 00:00:00	\N	active	2026-10-22 21:40:01.573	2026-10-22 21:40:01.573
cmvk2e2f300mq10qoxnrq5iii	cmvk2e2eg00mo10qokzbvud3z	cmvf3whkj000v01n4ykwe3g2y	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:01.599	2026-10-22 21:40:01.599
cmvk2e2fl00mt10qo6idcmye2	cmvk2e2fa00mr10qok97kyvqg	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.617	2026-10-22 21:40:01.617
cmvk2e2g100mw10qo5gw0xbrv	cmvk2e2fr00mu10qohapjlfv8	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.633	2026-10-22 21:40:01.633
cmvk2e2gn00mz10qowpgzwn2c	cmvk2e2ga00mx10qoxq9y911o	cmvf3sz07000m01n4lwmfsd5y	2022-11-05 00:00:00	\N	active	2026-10-22 21:40:01.655	2026-10-22 21:40:01.655
cmvk2e2gv00n210qokos8kpts	cmvk2e2gp00n010qop5winihn	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.663	2026-10-22 21:40:01.663
cmvk2e2ha00n510qoc2lg920w	cmvk2e2h100n310qoxejneoi1	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.678	2026-10-22 21:40:01.678
cmvk2e2hq00n810qowc4uv3dh	cmvk2e2he00n610qoqjycfgkw	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.694	2026-10-22 21:40:01.694
cmvk2e2ia00ne10qo1pby3glx	cmvk2e2i200nc10qoy0x32f8q	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.714	2026-10-22 21:40:01.714
cmvk2e2it00nh10qob1ulkpvl	cmvk2e2ie00nf10qoz6ai0dmm	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.733	2026-10-22 21:40:01.733
cmvk2e2j500nk10qo3jduoqkj	cmvk2e2iw00ni10qoywbqnai5	cmvf3me9p000d01n47nyq7jbz	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:01.745	2026-10-22 21:40:01.745
cmvk2e2ju00nn10qocaxpvqqy	cmvk2e2ja00nl10qoc5fvj7au	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.77	2026-10-22 21:40:01.77
cmvk2e2ln00nq10qo90za8kht	cmvk2e2kl00no10qo92hh1f3b	cmvf3whkj000v01n4ykwe3g2y	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:01.837	2026-10-22 21:40:01.837
cmvk2e2mq00nt10qohipch0yu	cmvk2e2m000nr10qo7irsk46h	cmvf3lnsd000a01n4cf7vrggg	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.874	2026-10-22 21:40:01.874
cmvk2e2nq00nw10qo4papp7km	cmvk2e2mz00nu10qoahpq6en1	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.91	2026-10-22 21:40:01.91
cmvk2e2o500nz10qo7gdyafjw	cmvk2e2nv00nx10qoicxjuufx	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.925	2026-10-22 21:40:01.925
cmvk2e2ov00o210qoixwuaa7l	cmvk2e2oa00o010qo3nqbcmwy	cmvf3yg7i001101n4g8wmjtf0	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:01.951	2026-10-22 21:40:01.951
cmvk2e2pa00o510qo18xc9v0w	cmvk2e2ox00o310qo1fp7jf9k	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.966	2026-10-22 21:40:01.966
cmvk2e2pl00o810qo93t3a41w	cmvk2e2pd00o610qodd2hmfys	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:01.977	2026-10-22 21:40:01.977
cmvk2e2py00ob10qoz1162jvu	cmvk2e2pq00o910qo2730l4yw	cmvf3il9z000401n44094dbvs	2022-11-05 00:00:00	\N	active	2026-10-22 21:40:01.99	2026-10-22 21:40:01.99
cmvk2e2qg00oe10qorv7uopuu	cmvk2e2q300oc10qot2xa2ayx	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.008	2026-10-22 21:40:02.008
cmvk2e2qs00oh10qoef1iikh2	cmvk2e2qi00of10qob9mtp95m	cmvc9nx0r000601rytht9l9lj	2025-01-18 00:00:00	\N	active	2026-10-22 21:40:02.02	2026-10-22 21:40:02.02
cmvk2e2r200ok10qol84u3x4r	cmvk2e2qv00oi10qotvkb5gwr	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.03	2026-10-22 21:40:02.03
cmvk2e2rb00on10qofs5o9cyt	cmvk2e2r400ol10qo3w3iir2x	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.039	2026-10-22 21:40:02.039
cmvk2e2ro00oq10qowec7551m	cmvk2e2rf00oo10qoel5fv9j7	cmvf3vi1f000s01n4dpx60bmu	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.052	2026-10-22 21:40:02.052
cmvk2e2s100ot10qosq5kbq0o	cmvk2e2rs00or10qogy8fva6b	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.065	2026-10-22 21:40:02.065
cmvk2e2si00ow10qolugoldsn	cmvk2e2s900ou10qolb7uyr4q	cmvf3vi1f000s01n4dpx60bmu	2026-10-17 00:00:00	\N	active	2026-10-22 21:40:02.083	2026-10-22 21:40:02.083
cmvk2e2sz00oz10qo613zm1gt	cmvk2e2so00ox10qorvrpc40u	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.099	2026-10-22 21:40:02.099
cmvk2e2t900p210qolj4zo5mp	cmvk2e2t200p010qo7ywriqdq	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.109	2026-10-22 21:40:02.109
cmvk2e2to00p510qov91kc4w2	cmvk2e2tc00p310qoefmn8evv	cmvf3yg7i001101n4g8wmjtf0	2024-01-13 00:00:00	\N	active	2026-10-22 21:40:02.124	2026-10-22 21:40:02.124
cmvk2e2ty00p810qovair6vnf	cmvk2e2ts00p610qosvzydygr	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.134	2026-10-22 21:40:02.134
cmvk2e2uf00pb10qof2yjr1oq	cmvk2e2u300p910qoppseznc5	cmvf3me9p000d01n47nyq7jbz	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.151	2026-10-22 21:40:02.151
cmvk2e2un00pe10qokuc4nm2h	cmvk2e2ui00pc10qopcqo26em	cmvf3il9z000401n44094dbvs	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.159	2026-10-22 21:40:02.159
cmvk2e2vt00ph10qolo7wyhmr	cmvk2e2vc00pf10qo3t9lj3li	cmvf3vi1f000s01n4dpx60bmu	2026-10-11 00:00:00	\N	active	2026-10-22 21:40:02.201	2026-10-22 21:40:02.201
cmvk2e2wo00pk10qo0q2ybnor	cmvk2e2w500pi10qovwf8e6aw	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.232	2026-10-22 21:40:02.232
cmvk2e2x200pn10qoj733cpgp	cmvk2e2wt00pl10qor4zldg40	cmvf3me9p000d01n47nyq7jbz	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:02.246	2026-10-22 21:40:02.246
cmvk2e2xe00pq10qoxhv5vc3n	cmvk2e2x500po10qomph1l3p6	cmvf3s76a000j01n45dn103g9	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.258	2026-10-22 21:40:02.258
cmvk2e2xs00pt10qopw5p0qm1	cmvk2e2xi00pr10qoyc5wzqn7	cmvf3yg7i001101n4g8wmjtf0	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.272	2026-10-22 21:40:02.272
cmvk2e2y700pw10qotvutvfmr	cmvk2e2xw00pu10qofmc21wia	cmvc9nx0r000601rytht9l9lj	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.287	2026-10-22 21:40:02.287
cmvk2e2yl00pz10qossqgew4m	cmvk2e2yc00px10qoh5przmtm	cmvf3whkj000v01n4ykwe3g2y	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:02.301	2026-10-22 21:40:02.301
cmvk2e2yx00q210qoq9v7c6du	cmvk2e2yn00q010qonug7nlo4	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.313	2026-10-22 21:40:02.313
cmvk2e2z900q510qoso6wuxmk	cmvk2e2z200q310qobwzccw2u	cmvf3whkj000v01n4ykwe3g2y	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:02.325	2026-10-22 21:40:02.325
cmvk2e2zn00q810qoyi6yi8ko	cmvk2e2zb00q610qopmdhaaas	cmvf3whkj000v01n4ykwe3g2y	2025-11-30 00:00:00	\N	active	2026-10-22 21:40:02.339	2026-10-22 21:40:02.339
cmvk2e30c00qb10qor2ehtuje	cmvk2e30100q910qo8yqwve66	cmvf3lnsd000a01n4cf7vrggg	2026-01-17 00:00:00	\N	active	2026-10-22 21:40:02.364	2026-10-22 21:40:02.364
cmvk2e30l00qe10qosv8te04o	cmvk2e30f00qc10qozdumo62o	cmvf3lnsd000a01n4cf7vrggg	2026-01-18 00:00:00	\N	active	2026-10-22 21:40:02.373	2026-10-22 21:40:02.373
cmvk2e30z00qh10qo29x1g3we	cmvk2e30p00qf10qo2i71tdoy	cmvf3whkj000v01n4ykwe3g2y	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.387	2026-10-22 21:40:02.387
cmvk2e31e00qk10qomzp38cwn	cmvk2e31200qi10qo9hc0wu8y	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	\N	active	2026-10-22 21:40:02.402	2026-10-22 21:40:02.402
cmvk2e11j00c210qofoemry11	cmvk2e11d00c010qoryncqogm	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	2026-10-23 09:03:20.016	withdrawn	2026-10-22 21:39:59.815	2026-10-23 09:03:20.024
cmvk2e2i100nb10qojg0wtcwm	cmvk2e2hs00n910qo4wyqhz7b	cmvk2e0vr009y10qo7yam17hh	2026-10-22 00:00:00	2026-10-23 09:04:07.814	withdrawn	2026-10-22 21:40:01.705	2026-10-23 09:04:07.815
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exams (id, "classId", "subjectId", "termId", "academicYearId", date, coefficient, "recordedById", "createdAt", "updatedAt", title) FROM stdin;
cmvcar16h000m01ryi2plkxg9	cmvc9nx0r000601rytht9l9lj	cmurf6c5l0000yd6dt9ur8ke0	cmuhjncbq00017g6d3glxc9oh	cmuhjm5hy00007g6di3jovxng	2026-10-17	1	4f100a5c-bdc1-4d37-a8d5-87102cdfd6ec	2026-10-17 11:11:54.041	2026-10-17 11:11:54.041	van 1 tot 5
cmvl4k8oc000j01qqars7smdf	cmvf3il9z000401n44094dbvs	cmuhhun0m0004b16dx0abachg	cmuhjncbq00017g6d3glxc9oh	cmuhjm5hy00007g6di3jovxng	2026-10-23	1	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:28:35.052	2026-10-23 15:28:35.052	H2
cmvl4lynn001701qq344v9pm1	cmvf3il9z000401n44094dbvs	cmvcbh80j000n01rytqmdn90z	cmuhjncbq00017g6d3glxc9oh	cmuhjm5hy00007g6di3jovxng	2026-10-23	2	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:55.379	2026-10-23 15:29:55.379	H1
cmvl4ndpa001w01qq8d5xq9oy	cmvf3il9z000401n44094dbvs	cmuzwptjp0000666da2gf1e10	cmuhjncbq00017g6d3glxc9oh	cmuhjm5hy00007g6di3jovxng	2026-10-23	3	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:01.534	2026-10-23 15:31:01.534	H3
cmvmdzdih002q01qq5g2gubxy	cmvc9nx0r000601rytht9l9lj	cmurf6c5l0000yd6dt9ur8ke0	cmuhjncbq00017g6d3glxc9oh	cmuhjm5hy00007g6di3jovxng	2026-10-24	1	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:03.882	2026-10-24 12:40:03.882	jhgdkfj
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grades (id, "studentId", score, remark, "recordedById", "createdAt", "updatedAt", "examId") FROM stdin;
cmvl4l14q000k01qq7ovkqwip	cmvk2e11s00c610qo5ocm5vo0	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.93	2026-10-23 15:29:11.93	cmvl4k8oc000j01qqars7smdf
cmvl4l15c000l01qqmar3z4ps	cmvk2e11m00c310qoopdaoqx8	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.952	2026-10-23 15:29:11.952	cmvl4k8oc000j01qqars7smdf
cmvl4l15g000m01qqtvsake7w	cmvk2e0z900b910qorgtkuon9	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.956	2026-10-23 15:29:11.956	cmvl4k8oc000j01qqars7smdf
cmvl4l15i000n01qqynj3mtdf	cmvk2e2ts00p610qosvzydygr	10	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.959	2026-10-23 15:29:11.959	cmvl4k8oc000j01qqars7smdf
cmvl4l15m000o01qqq1zf11u6	cmvk2e15o00di10qo657spol2	10	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.962	2026-10-23 15:29:11.962	cmvl4k8oc000j01qqars7smdf
cmvl4l15q000p01qql5n5dwc5	cmvk2e0hi006410qoeec2qw1j	10	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.966	2026-10-23 15:29:11.966	cmvl4k8oc000j01qqars7smdf
cmvl4l15x000q01qquuefkqx0	cmvk2e1pb00h610qohomlnt99	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.973	2026-10-23 15:29:11.973	cmvl4k8oc000j01qqars7smdf
cmvl4l160000r01qqqfope07k	cmvk2e1jb00f910qoxwwq9wec	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.976	2026-10-23 15:29:11.976	cmvl4k8oc000j01qqars7smdf
cmvl4l164000s01qqqxev4cmg	cmvk2e2pq00o910qo2730l4yw	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.98	2026-10-23 15:29:11.98	cmvl4k8oc000j01qqars7smdf
cmvl4l168000t01qqc5s7k34g	cmvk2e1j700f610qoqieb3sy7	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.984	2026-10-23 15:29:11.984	cmvl4k8oc000j01qqars7smdf
cmvl4l16a000u01qqnshbvpvw	cmvk2e1wl00ir10qozqju3tjf	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.986	2026-10-23 15:29:11.986	cmvl4k8oc000j01qqars7smdf
cmvl4l16c000v01qqam3qzdo9	cmvk2e2c200m610qoor5xfdo6	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.988	2026-10-23 15:29:11.988	cmvl4k8oc000j01qqars7smdf
cmvl4l16f000w01qqwrdaorlu	cmvk2e28s00lo10qo7e2bp1o3	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.991	2026-10-23 15:29:11.991	cmvl4k8oc000j01qqars7smdf
cmvl4l16i000x01qqwpax02yp	cmvk2e0ju006p10qo8s1059sq	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.994	2026-10-23 15:29:11.994	cmvl4k8oc000j01qqars7smdf
cmvl4l16l000y01qqbpylk0eb	cmvk2e0pi008710qo1720qe77	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.997	2026-10-23 15:29:11.997	cmvl4k8oc000j01qqars7smdf
cmvl4l16n000z01qqw542gxg0	cmvk2e10m00br10qo701zsodd	10	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:11.999	2026-10-23 15:29:11.999	cmvl4k8oc000j01qqars7smdf
cmvl4l16q001001qq8nikjh65	cmvk2e1js00fi10qoblhlylqf	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.002	2026-10-23 15:29:12.002	cmvl4k8oc000j01qqars7smdf
cmvl4l16t001101qqz0w7n9wn	cmvk2e14v00d910qojo53f9k3	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.005	2026-10-23 15:29:12.005	cmvl4k8oc000j01qqars7smdf
cmvl4l16z001201qqiezt4grx	cmvk2e0we00a610qocxbkzyuy	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.011	2026-10-23 15:29:12.011	cmvl4k8oc000j01qqars7smdf
cmvl4l172001301qqg1qp51gu	cmvk2e27h00lc10qo7gh0hsiq	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.014	2026-10-23 15:29:12.014	cmvl4k8oc000j01qqars7smdf
cmvl4l177001401qqetcxm8a0	cmvk2e1on00h010qoznju2wm0	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.019	2026-10-23 15:29:12.019	cmvl4k8oc000j01qqars7smdf
cmvl4l17b001501qqcz0n3u0j	cmvk2e2bg00m310qo6pqqxpjl	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.023	2026-10-23 15:29:12.023	cmvl4k8oc000j01qqars7smdf
cmvl4l17d001601qqzipycxyu	cmvk2e1ii00eu10qouggo8ohv	10	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:29:12.025	2026-10-23 15:29:12.025	cmvl4k8oc000j01qqars7smdf
cmvl4mpth001801qqq1fiwndq	cmvk2e11s00c610qo5ocm5vo0	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.581	2026-10-23 15:30:30.581	cmvl4lynn001701qq344v9pm1
cmvl4mpts001901qqgcpsly07	cmvk2e11m00c310qoopdaoqx8	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.592	2026-10-23 15:30:30.592	cmvl4lynn001701qq344v9pm1
cmvl4mptx001a01qqxfflykry	cmvk2e2ts00p610qosvzydygr	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.597	2026-10-23 15:30:30.597	cmvl4lynn001701qq344v9pm1
cmvl4mpu3001b01qqhpo804k1	cmvk2e15o00di10qo657spol2	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.603	2026-10-23 15:30:30.603	cmvl4lynn001701qq344v9pm1
cmvl4mpu7001c01qq4sxazq5d	cmvk2e0hi006410qoeec2qw1j	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.607	2026-10-23 15:30:30.607	cmvl4lynn001701qq344v9pm1
cmvl4mpud001d01qqjiy2i3zr	cmvk2e1pb00h610qohomlnt99	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.613	2026-10-23 15:30:30.613	cmvl4lynn001701qq344v9pm1
cmvl4mpuj001e01qqtryraj5h	cmvk2e1jb00f910qoxwwq9wec	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.619	2026-10-23 15:30:30.619	cmvl4lynn001701qq344v9pm1
cmvl4mpun001f01qqz6knh532	cmvk2e2pq00o910qo2730l4yw	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.623	2026-10-23 15:30:30.623	cmvl4lynn001701qq344v9pm1
cmvl4mput001g01qq5cm37tuj	cmvk2e1j700f610qoqieb3sy7	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.629	2026-10-23 15:30:30.629	cmvl4lynn001701qq344v9pm1
cmvl4mpuz001h01qqlwxb2h18	cmvk2e1wl00ir10qozqju3tjf	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.635	2026-10-23 15:30:30.635	cmvl4lynn001701qq344v9pm1
cmvl4mpv2001i01qqaallj9wm	cmvk2e2c200m610qoor5xfdo6	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.638	2026-10-23 15:30:30.638	cmvl4lynn001701qq344v9pm1
cmvl4mpv5001j01qqr5ywym1l	cmvk2e28s00lo10qo7e2bp1o3	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.641	2026-10-23 15:30:30.641	cmvl4lynn001701qq344v9pm1
cmvl4mpv8001k01qq0u5n0va5	cmvk2e0ju006p10qo8s1059sq	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.644	2026-10-23 15:30:30.644	cmvl4lynn001701qq344v9pm1
cmvl4mpvf001l01qqg7hn5555	cmvk2e0pi008710qo1720qe77	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.651	2026-10-23 15:30:30.651	cmvl4lynn001701qq344v9pm1
cmvl4mpvj001m01qq18nfgc4n	cmvk2e10m00br10qo701zsodd	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.655	2026-10-23 15:30:30.655	cmvl4lynn001701qq344v9pm1
cmvl4mpvm001n01qqj8kd1jg2	cmvk2e1js00fi10qoblhlylqf	4	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.658	2026-10-23 15:30:30.658	cmvl4lynn001701qq344v9pm1
cmvl4mpvp001o01qqdhrbrvqx	cmvk2e14v00d910qojo53f9k3	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.661	2026-10-23 15:30:30.661	cmvl4lynn001701qq344v9pm1
cmvl4mpvs001p01qqasxxlvf4	cmvk2e2ui00pc10qopcqo26em	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.664	2026-10-23 15:30:30.664	cmvl4lynn001701qq344v9pm1
cmvl4mpvw001q01qqwcw4aw99	cmvk2e0we00a610qocxbkzyuy	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.668	2026-10-23 15:30:30.668	cmvl4lynn001701qq344v9pm1
cmvl4mpw0001r01qq3kvo313y	cmvk2e27h00lc10qo7gh0hsiq	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.672	2026-10-23 15:30:30.672	cmvl4lynn001701qq344v9pm1
cmvl4mpw4001s01qqwl5040vn	cmvk2e1on00h010qoznju2wm0	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.676	2026-10-23 15:30:30.676	cmvl4lynn001701qq344v9pm1
cmvl4mpw6001t01qqorqumhaa	cmvk2e0re008m10qoh4nxmdu8	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.678	2026-10-23 15:30:30.678	cmvl4lynn001701qq344v9pm1
cmvl4mpwa001u01qqu36345ip	cmvk2e2bg00m310qo6pqqxpjl	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.682	2026-10-23 15:30:30.682	cmvl4lynn001701qq344v9pm1
cmvl4mpwe001v01qq0p9zgthh	cmvk2e1ii00eu10qouggo8ohv	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:30:30.686	2026-10-23 15:30:30.686	cmvl4lynn001701qq344v9pm1
cmvl4o0bx001x01qqgycb7zov	cmvk2e11s00c610qo5ocm5vo0	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:30.862	2026-10-23 15:31:30.862	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0es001y01qqbd3ek6qz	cmvk2e11m00c310qoopdaoqx8	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:30.964	2026-10-23 15:31:30.964	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0fi001z01qq8y4sxoxj	cmvk2e0z900b910qorgtkuon9	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:30.99	2026-10-23 15:31:30.99	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0fn002001qqpjtsi2i6	cmvk2e2ts00p610qosvzydygr	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:30.995	2026-10-23 15:31:30.995	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0fq002101qq4xu3hhy7	cmvk2e15o00di10qo657spol2	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:30.998	2026-10-23 15:31:30.998	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0fs002201qqto0u6xez	cmvk2e0hi006410qoeec2qw1j	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31	2026-10-23 15:31:31	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0fx002301qqsax7hsfr	cmvk2e1jb00f910qoxwwq9wec	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.006	2026-10-23 15:31:31.006	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0g0002401qq2truohoh	cmvk2e2pq00o910qo2730l4yw	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.008	2026-10-23 15:31:31.008	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0g3002501qq1ksenxbe	cmvk2e1j700f610qoqieb3sy7	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.011	2026-10-23 15:31:31.011	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0g6002601qq2m00lvlq	cmvk2e1wl00ir10qozqju3tjf	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.014	2026-10-23 15:31:31.014	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0ga002701qq2ldiull0	cmvk2e2c200m610qoor5xfdo6	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.018	2026-10-23 15:31:31.018	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gd002801qq84gblr00	cmvk2e28s00lo10qo7e2bp1o3	4	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.021	2026-10-23 15:31:31.021	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gg002901qq40s3piig	cmvk2e0ju006p10qo8s1059sq	3	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.024	2026-10-23 15:31:31.024	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gi002a01qqaxlhuj9f	cmvk2e0pi008710qo1720qe77	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.026	2026-10-23 15:31:31.026	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gj002b01qqdo499uc8	cmvk2e10m00br10qo701zsodd	5	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.027	2026-10-23 15:31:31.027	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gk002c01qqxhzl9qaq	cmvk2e1js00fi10qoblhlylqf	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.028	2026-10-23 15:31:31.028	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gl002d01qqtia98lkh	cmvk2e14v00d910qojo53f9k3	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.029	2026-10-23 15:31:31.029	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gm002e01qq63alukt7	cmvk2e2ui00pc10qopcqo26em	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.03	2026-10-23 15:31:31.03	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gn002f01qqykr2dy2d	cmvk2e0we00a610qocxbkzyuy	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.031	2026-10-23 15:31:31.031	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gp002g01qq1fa4t7qh	cmvk2e27h00lc10qo7gh0hsiq	9	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.033	2026-10-23 15:31:31.033	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gr002h01qqggxs9s66	cmvk2e1on00h010qoznju2wm0	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.035	2026-10-23 15:31:31.035	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gv002i01qqid0t6gv4	cmvk2e0re008m10qoh4nxmdu8	7	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.039	2026-10-23 15:31:31.039	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0gz002j01qqldtiba6s	cmvk2e2bg00m310qo6pqqxpjl	8	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.043	2026-10-23 15:31:31.043	cmvl4ndpa001w01qq8d5xq9oy
cmvl4o0h3002k01qqseb1iekg	cmvk2e1ii00eu10qouggo8ohv	6	\N	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 15:31:31.047	2026-10-23 15:31:31.047	cmvl4ndpa001w01qq8d5xq9oy
cmvme0fk6002r01qqah5f9u5i	cmvk2e2d700mf10qoox604aky	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.19	2026-10-24 12:40:53.19	cmvmdzdih002q01qq5g2gubxy
cmvme0fkj002s01qq59lqtb7o	cmvk2e18k00e010qokp92c4cf	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.203	2026-10-24 12:40:53.203	cmvmdzdih002q01qq5g2gubxy
cmvme0fkm002t01qqvyn8iqx2	cmvk2e20y00jr10qoh8pjk1e2	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.206	2026-10-24 12:40:53.206	cmvmdzdih002q01qq5g2gubxy
cmvme0fko002u01qq8vhtosrh	cmvk2e1l900fr10qo6euq3n2l	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.208	2026-10-24 12:40:53.208	cmvmdzdih002q01qq5g2gubxy
cmvme0fkr002v01qqdhk9e1br	cmvk2e24f00ko10qowjirabgu	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.211	2026-10-24 12:40:53.211	cmvmdzdih002q01qq5g2gubxy
cmvme0fkv002w01qqttmo7h79	cmvk2e1rl00hr10qoln6c107h	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.215	2026-10-24 12:40:53.215	cmvmdzdih002q01qq5g2gubxy
cmvme0fky002x01qqo4zx2blt	cmvk2e0r6008j10qow2kjqodr	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.218	2026-10-24 12:40:53.218	cmvmdzdih002q01qq5g2gubxy
cmvme0fl2002y01qqg49wtfr6	cmvk2e2so00ox10qorvrpc40u	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.222	2026-10-24 12:40:53.222	cmvmdzdih002q01qq5g2gubxy
cmvme0fl5002z01qq9eme7532	cmvk2e2t200p010qo7ywriqdq	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.225	2026-10-24 12:40:53.225	cmvmdzdih002q01qq5g2gubxy
cmvme0fl8003001qqhy1g1k2d	cmvk2e2rs00or10qogy8fva6b	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.228	2026-10-24 12:40:53.228	cmvmdzdih002q01qq5g2gubxy
cmvme0fla003101qqhnkcqwf1	cmvk2e2qv00oi10qotvkb5gwr	9	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.231	2026-10-24 12:40:53.231	cmvmdzdih002q01qq5g2gubxy
cmvme0fld003201qq9upartjz	cmvk2e1pv00hc10qo70s7eud4	9	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.234	2026-10-24 12:40:53.234	cmvmdzdih002q01qq5g2gubxy
cmvme0flg003301qqn9sl6fyq	cmvk2e2q300oc10qot2xa2ayx	10	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.236	2026-10-24 12:40:53.236	cmvmdzdih002q01qq5g2gubxy
cmvme0fli003401qqwj1e3a85	cmvk2e0xb00ai10qokuc5bs2q	10	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.238	2026-10-24 12:40:53.238	cmvmdzdih002q01qq5g2gubxy
cmvme0flk003501qq676zafyu	cmvk2e16h00dr10qotnvucg70	9	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.24	2026-10-24 12:40:53.24	cmvmdzdih002q01qq5g2gubxy
cmvme0fll003601qqhmpynmno	cmvk2e2xw00pu10qofmc21wia	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.241	2026-10-24 12:40:53.241	cmvmdzdih002q01qq5g2gubxy
cmvme0fln003701qqssx3m5p3	cmvk2e2r400ol10qo3w3iir2x	8	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.243	2026-10-24 12:40:53.243	cmvmdzdih002q01qq5g2gubxy
cmvme0flp003801qq1w3gtqke	cmvk2e2qi00of10qob9mtp95m	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.245	2026-10-24 12:40:53.245	cmvmdzdih002q01qq5g2gubxy
cmvme0flr003901qqydxkwivx	cmvk2e1n100gc10qoy5htea82	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.247	2026-10-24 12:40:53.247	cmvmdzdih002q01qq5g2gubxy
cmvme0flt003a01qq6wlb9gee	cmvk2e1w500il10qoq9493xwt	6	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.249	2026-10-24 12:40:53.249	cmvmdzdih002q01qq5g2gubxy
cmvme0flw003b01qqufzc0rpm	cmvk2e1i300eo10qoactgc813	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.252	2026-10-24 12:40:53.252	cmvmdzdih002q01qq5g2gubxy
cmvme0fly003c01qq7jw4bmvc	cmvk2e0zl00bf10qouw396q6q	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.254	2026-10-24 12:40:53.254	cmvmdzdih002q01qq5g2gubxy
cmvme0fm1003d01qqbztkrfhs	cmvk2e0zr00bi10qofdc5fch4	7	\N	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:40:53.257	2026-10-24 12:40:53.257	cmvmdzdih002q01qq5g2gubxy
\.


--
-- Data for Name: guardian_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardian_comments (id, "guardianId", "authorId", body, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: guardian_registration_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardian_registration_tokens (id, "guardianId", token, "expiresAt", "usedAt", "createdById", "createdAt") FROM stdin;
cmvks4dbu000701qqijgu0mdn	cmvks47uk000601qqqi2zmoz7	7mbktYCrRpi5vlxVoAFvyfrJ7uDAAfIdlakgHSFtcE0	2026-11-22 09:40:19.181	2026-10-23 09:44:00.139	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 09:40:19.194
cmvmdnk0p002n01qqp5qrtmrb	cmvmdnak7002m01qqprpivn3u	kbk7UTIdSge7Rlnot43vNcRvdaS31LBKv2WBax_DZLs	2026-11-23 12:30:52.435	2026-10-24 12:34:36.128	de9554a3-14cd-46fa-8f73-ffe9ae4d5643	2026-10-24 12:30:52.441
\.


--
-- Data for Name: guardians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardians (id, "firstName", "lastName", email, phone, address, "createdAt", "updatedAt", "donationNumber", "educationNumber", status, "enrolledAt", "archivedAt") FROM stdin;
cmvks47uk000601qqqi2zmoz7	Ali	voorbeeld	m-qadri@hotmail.com	064566439875	Rooseveltlaan 70	2026-10-23 09:40:12.093	2026-10-23 09:50:52.87	262	111	ARCHIVED	2026-10-23	2026-10-23
cmvmdnak7002m01qqprpivn3u	Khalid	Achahbar	k.achah@hitmail.com	0614492133	Harlan 100	2026-10-24 12:30:40.183	2026-10-24 12:34:36.147	664	113	ACTIVE	2026-10-24	\N
cmvk2dzse000210qoeo0r31ty	Hamid	Maraghich	\N	0687586009	Livingstonelaan 211, 3526 HE Utrecht	2026-10-22 21:39:58.19	2026-10-22 21:39:58.19	130	1	ACTIVE	2026-10-22	\N
cmvk2dzsl000310qolsw2wchn	Mohamed	Sialioua	\N	0640004467	Afrikalaan 141, 3526 VM Utrecht	2026-10-22 21:39:58.197	2026-10-22 21:39:58.197	725	2	ACTIVE	2026-10-22	\N
cmvk2dzsq000410qokmdshdul	Hakim	Bourdif	\N	0610171625	A H goedhartlaan 70, 3527CL Utrecht	2026-10-22 21:39:58.202	2026-10-22 21:39:58.202	600	3	ACTIVE	2026-10-22	\N
cmvk2dzsv000510qob3n5s53v	Abdelhamid	Sahraoui	hamidsahraoui455@gmail.com	0683787018	Rosveltlaan 205, 3527 AA Utrecht	2026-10-22 21:39:58.207	2026-10-22 21:39:58.207	5001	4	ACTIVE	2026-10-22	\N
cmvk2dzt2000610qoyaeafvme	Mohamed	Ben gharda	ben-2222@live.nl	0646875063	Geelwortelweg 14, 3541SR Utrecht	2026-10-22 21:39:58.214	2026-10-22 21:39:58.214	947	5	ACTIVE	2025-09-14	\N
cmvk2dzt5000710qoin2ezimf	Noureddine	Belhadi	\N	0644341789	Stanleylaan 18, 3526 TL Utrecht	2026-10-22 21:39:58.217	2026-10-22 21:39:58.217	536	6	ACTIVE	2026-10-22	\N
cmvk2dzt8000810qomgfmwlq2	Najim	El Mahdadi	\N	0648687838	Van Spanjelaan 3, 3526 XL Utrecht	2026-10-22 21:39:58.22	2026-10-22 21:39:58.22	849	7	ACTIVE	2026-10-22	\N
cmvk2dzta000910qo9l7zyikg	Abdeslam	Bourarach	onderwijs@outlook.com	0684279256	Nasenlaan 126, 3527 EL Utrecht	2026-10-22 21:39:58.222	2026-10-22 21:39:58.222	9001	8	ACTIVE	2025-07-12	\N
cmvk2dztc000a10qoudbz35ki	Abdelouahid	Bouhaoulian	w.elarbaji@hotmail.com	0684548169	Marshalllaan 24, 3527TL Utrecht	2026-10-22 21:39:58.224	2026-10-22 21:39:58.224	487	9	ACTIVE	2026-10-22	\N
cmvk2dzte000b10qo3h958bgw	Abdeslam	Elbaouti	\N	0617972582	Rooseveltlaan 198, 3527 AJ Utrecht	2026-10-22 21:39:58.226	2026-10-22 21:39:58.226	782	10	ACTIVE	2026-10-22	\N
cmvk2dztg000c10qodngcphl0	jamil	el Meryaoui	meryaoui@hotmail.com	0687906491	stanleylaan 290, 3526tv Utrecht	2026-10-22 21:39:58.228	2026-10-22 21:39:58.228	276	11	ACTIVE	2026-03-28	\N
cmvk2dzti000d10qohcc9ghvt	Mohamed	Hitou	mhitou@live.nl	0622077332	Rooseveltlaan 1034, 3526 bs Utrecht	2026-10-22 21:39:58.23	2026-10-22 21:39:58.23	537	12	ACTIVE	2026-10-22	\N
cmvk2dztl000e10qos19xdq22	Houssin	Moussi	\N	0685864627	Stanleylaan 205, 3526 TE Utrecht	2026-10-22 21:39:58.233	2026-10-22 21:39:58.233	98	13	ACTIVE	2026-10-22	\N
cmvk2dztp000f10qokb859eyq	Rachid	El Abbassi	\N	0616441678	Derkinderstraat 27, 3443CX Woerden	2026-10-22 21:39:58.237	2026-10-22 21:39:58.237	806	14	ACTIVE	2026-10-22	\N
cmvk2dzts000g10qoqt52yrxa	Salaheddine	Badr	badrsalah1025@gmail.com	0687514326	Livingstonelaan 549, 3526 HK Utrecht	2026-10-22 21:39:58.24	2026-10-22 21:39:58.24	82	15	ACTIVE	2026-10-22	\N
cmvk2dztv000h10qo5z945znq	Rachid	Lamchachti	rachid_lamchachti@hotmail.com	0681838458	Amerikalaan 181, 3526 VD Utercht	2026-10-22 21:39:58.243	2026-10-22 21:39:58.243	1123	16	ACTIVE	2026-10-22	\N
cmvk2dzty000i10qo9inta0h5	Banduim	Doumboya	\N	0618916431	Marchalaan 131, 3527TC Utrecht	2026-10-22 21:39:58.246	2026-10-22 21:39:58.246	9012	17	ACTIVE	2026-10-22	\N
cmvk2dzu0000j10qofpei2enb	Abderrahim	El Bachiri	Appiebach@hotmail.com	0648364880	Trumanlaan 391, 3527 BL Utrecht	2026-10-22 21:39:58.249	2026-10-22 21:39:58.249	1060	18	ACTIVE	2026-10-22	\N
cmvk2dzu3000k10qo6uyf5mx8	Farid	Karoum	\N	0636390176	Utrecht	2026-10-22 21:39:58.251	2026-10-22 21:39:58.251	359	19	ACTIVE	2026-10-22	\N
cmvk2dzu7000l10qo659rsm0i	Hamid	Essaken	hamid.saken@hotmail.com	0651328913	Magelhaenlaan 239, 3526CG Utrecht	2026-10-22 21:39:58.255	2026-10-22 21:39:58.255	206	20	ACTIVE	2026-10-22	\N
cmvk2dzua000m10qoj7izfm97	Ali	Adda	\N	0628061369	Magelhaenlaan 20, Utrecht	2026-10-22 21:39:58.258	2026-10-22 21:39:58.258	952	21	ACTIVE	2026-10-22	\N
cmvk2dzuc000n10qoyabyh97f	Abderrahim	Akchich/Bourakba	\N	0684180612	Stanleylaan 103, Utrecht	2026-10-22 21:39:58.26	2026-10-22 21:39:58.26	30	22	ACTIVE	2026-10-22	\N
cmvk2dzuf000o10qoss2znahr	Youness	Boutahir	\N	0614742026	Televisiebaan 117, 3402 vc IJsselstein	2026-10-22 21:39:58.263	2026-10-22 21:39:58.263	816	23	ACTIVE	2026-10-22	\N
cmvk2dzui000p10qog7wt4iuf	Ismail	Talhaoui	\N	0611249067	Citadeldrift 93, 3436 CM Nieuwegein	2026-10-22 21:39:58.266	2026-10-22 21:39:58.266	694	24	ACTIVE	2026-10-22	\N
cmvk2dzuk000q10qoc540bx1n	Sadik	El kaydi	\N	0640443444	Utrecht	2026-10-22 21:39:58.268	2026-10-22 21:39:58.268	510	25	ACTIVE	2026-10-22	\N
cmvk2dzun000r10qoom4y7eob	Mohammed	Alamraoui	\N	0684216193	Arnoldusguldenhof 13, 3545GJ Utrecht	2026-10-22 21:39:58.271	2026-10-22 21:39:58.271	937	26	ACTIVE	2026-10-22	\N
cmvk2dzuq000s10qoojajupnp	Brahim	El Hadraoui	\N	0687299457	Afrikalaan 118, 2536 VH Utrecht	2026-10-22 21:39:58.274	2026-10-22 21:39:58.274	535	27	ACTIVE	2026-10-22	\N
cmvk2dzut000t10qo3ihr1dyf	Sanaa	Azzamouri	Azzamour2005@outlook.com	0641638069	Rooseveltlaan 908, 3526BN Utrecht	2026-10-22 21:39:58.277	2026-10-22 21:39:58.277	932	28	ACTIVE	2026-10-22	\N
cmvk2dzuv000u10qox9mcd4px	Mustapha	Esadik	mustapha.esadik1@gmail.com	0683023762	Veldbloemlaan 8, 3452CL Utrecht	2026-10-22 21:39:58.279	2026-10-22 21:39:58.279	817	29	ACTIVE	2026-10-22	\N
cmvk2dzux000v10qo3uah8fbb	Ahmed	Ould Hamou	\N	0641210518	Egginklaan 22, 3527 XR Utrecht	2026-10-22 21:39:58.281	2026-10-22 21:39:58.281	156	30	ACTIVE	2026-10-22	\N
cmvk2dzv0000w10qoejy823mp	Abdelilah	Boukhachkhach	\N	0643187400	Pearsonlaan 40, 3527CC Utrecht	2026-10-22 21:39:58.284	2026-10-22 21:39:58.284	567	31	ACTIVE	2026-10-22	\N
cmvk2dzv3000x10qowcjqlz1n	Mokhtar	Lakbiach	Mokhtar241@live.nl	0619724685	Nansenlaan 5, 3527 EE Utrecht	2026-10-22 21:39:58.287	2026-10-22 21:39:58.287	332	32	ACTIVE	2026-10-03	\N
cmvk2dzv5000y10qo04j9tune	Omar	Aouad	\N	0646664631	Gasperilaan 46, 3527 GE Utrecht	2026-10-22 21:39:58.289	2026-10-22 21:39:58.289	983	33	ACTIVE	2026-10-22	\N
cmvk2dzv7000z10qohk9skbvs	Abdeslam	Ochen	abdeslam_ochen@hotmail.com	0616478420	Magelhaenlaan 220, 3526 CM Utrecht	2026-10-22 21:39:58.291	2026-10-22 21:39:58.291	7	34	ACTIVE	2026-07-03	\N
cmvk2dzv9001010qojo2zsy6i	Samir	Zoundri	\N	0614671900	Iepstraat 60, 3443GG	2026-10-22 21:39:58.293	2026-10-22 21:39:58.293	390	35	ACTIVE	2026-10-22	\N
cmvk2dzvc001110qoxm0yzj0n	Rachid	Belhadi	\N	0628713529	Stanleylaan 229, 3526 TE Utrecht	2026-10-22 21:39:58.296	2026-10-22 21:39:58.296	892	36	ACTIVE	2026-10-22	\N
cmvk2dzve001210qosrqrgvka	Abdelhakim	Lakbiach	a.lakbiach@live.nl	0641950255	Rooseveltlaan 410, 3527AP Utrecht	2026-10-22 21:39:58.298	2026-10-22 21:39:58.298	951	37	ACTIVE	2026-10-22	\N
cmvk2dzvg001310qovvug1rof	Aziz	Bouhjira	\N	0642808820	Sassafraslaan, 3545 Cm Utrecht	2026-10-22 21:39:58.3	2026-10-22 21:39:58.3	48	38	ACTIVE	2026-10-22	\N
cmvk2dzvk001410qo120b15yu	Jamil	Loukili	\N	0653765992	Pearsonlaan 17, 3527 CA Utrecht	2026-10-22 21:39:58.304	2026-10-22 21:39:58.304	286	39	ACTIVE	2026-10-22	\N
cmvk2dzvp001510qogqc27o0r	Abdelaziz	El abadi	Azizelabadi@hotmail.com	0614806577	Turkse hazelaarstraat 21, 3545cd Utrecht	2026-10-22 21:39:58.309	2026-10-22 21:39:58.309	989	40	ACTIVE	2025-09-27	\N
cmvk2dzvs001610qopnzrvmpu	Khadija	Mehdaoui	Mohamedmehdaoui259@gmail.com	0687779922	Rooseveltlaan 259, 3527AC Utrecht	2026-10-22 21:39:58.312	2026-10-22 21:39:58.312	9014	41	ACTIVE	2026-09-05	\N
cmvk2dzvv001710qo79z1meiv	Hamza	Hamidi	Hamza.hamidi@live.nl	0624363623	Sassafraslaan 65, 3545cm Utrecht	2026-10-22 21:39:58.315	2026-10-22 21:39:58.315	606	42	ACTIVE	2026-10-22	\N
cmvk2dzvy001810qo2nzpyqyv	Abdoulhamid	Azerkaan	\N	0645767787	\N	2026-10-22 21:39:58.318	2026-10-22 21:39:58.318	1081	43	ACTIVE	2026-10-22	\N
cmvk2dzw0001910qob1ei1fx9	Mimoun	Chari	halima.ishaak@outlook.com	0645652866	Rooseveltlaan 904, 3526BN Utrecht	2026-10-22 21:39:58.32	2026-10-22 21:39:58.32	829	44	ACTIVE	2026-12-09	\N
cmvk2dzw3001a10qowigj85mp	Mustapha	Assarraj	\N	0685317570	De Brauwlaan 11, 3526 XR Utrecht	2026-10-22 21:39:58.323	2026-10-22 21:39:58.323	1178	45	ACTIVE	2026-10-22	\N
cmvk2dzw6001b10qocyriouz6	Abdelouhab	Sajie	\N	0684304185	Trumanlaan 225, 3527 BH Utrecht	2026-10-22 21:39:58.326	2026-10-22 21:39:58.326	1028	46	ACTIVE	2026-10-22	\N
cmvk2dzw9001c10qo5ysgiqnt	Boujamaa	El maryaoui	Boesma2@hotmail.com	0620882144	Battutalaan 507, 3526 vs Utrecht	2026-10-22 21:39:58.329	2026-10-22 21:39:58.329	57	47	ACTIVE	2026-01-24	\N
cmvk2dzwb001d10qolylk42fm	Mohammed	Akalai	\N	0641119770	Columbuslaan 261, 3526EG Utrecht	2026-10-22 21:39:58.331	2026-10-22 21:39:58.331	1094	48	ACTIVE	2026-10-22	\N
cmvk2dzwd001e10qogiaxqkir	Aminata	Bari	\N	0687441104	Minstraat 24, 3582 CC Utrecht	2026-10-22 21:39:58.333	2026-10-22 21:39:58.333	9016	49	ACTIVE	2026-10-22	\N
cmvk2dzwg001f10qotb5nujr8	Mariam	Özgör	ademozgur31@gmail.com	0618868786	Woudsenderraklaan 92, 3544PZ Utrecht	2026-10-22 21:39:58.336	2026-10-22 21:39:58.336	9002	50	ACTIVE	2026-10-22	\N
cmvk2dzwj001g10qo3w9ujhu3	Sabrine	Wachrine	Sabrineaouraghe@hotmail.com	0648391645	Pearsonhof 68, 3527ct Utrecht	2026-10-22 21:39:58.339	2026-10-22 21:39:58.339	9017	51	ACTIVE	2026-06-17	\N
cmvk2dzwl001h10qocswi8271	Mohamed	Hemmit	\N	0684126402	\N	2026-10-22 21:39:58.341	2026-10-22 21:39:58.341	143	52	ACTIVE	2026-10-22	\N
cmvk2dzwn001i10qoydgblakh	Driss	Abbou	\N	0646875570	Sassafraslaan 15, 3545 CM Utrecht	2026-10-22 21:39:58.343	2026-10-22 21:39:58.343	556	53	ACTIVE	2026-10-22	\N
cmvk2dzwq001j10qofdphn643	Abdi	Abdi	\N	0687175400	Spaaklaan 231, 3527SJ Utrecht	2026-10-22 21:39:58.346	2026-10-22 21:39:58.346	9003	54	ACTIVE	2026-10-22	\N
cmvk2dzws001k10qoq7z4kfpa	Jamaal	Assou	\N	0641896763	Livingstonelaan 91, 3526HB Utrecht	2026-10-22 21:39:58.348	2026-10-22 21:39:58.348	716	55	ACTIVE	2026-10-22	\N
cmvk2dzwv001l10qo8pb898u6	Abdeoulrazzak	Ouadou	\N	0626041411	Guldenplantsoen 10, 3541GS Utrecht	2026-10-22 21:39:58.351	2026-10-22 21:39:58.351	1066	56	ACTIVE	2026-10-22	\N
cmvk2dzwx001m10qo4oqkuxjr	Ali	Elmousaoui	\N	0643545232	Schipovalaan 28, 3545DC Utrecht	2026-10-22 21:39:58.353	2026-10-22 21:39:58.353	118	57	ACTIVE	2026-10-22	\N
cmvk2dzwz001n10qov3gpso48	Aziz	El Maadouri	mad-030@live.nl	0684086748	Stanleylaan 149, 3526TD Utrecht	2026-10-22 21:39:58.355	2026-10-22 21:39:58.355	898	58	ACTIVE	2026-09-13	\N
cmvk2dzx1001o10qo4p30kxbh	Toufik	Sabti	\N	0616234517	Atlleeplantsoen 35, 3528 BA Utrecht	2026-10-22 21:39:58.357	2026-10-22 21:39:58.357	612	59	ACTIVE	2026-10-22	\N
cmvk2dzx3001p10qop5lezwp5	Brahim	Bockachkhach	\N	0643582561	Alexander de Grotelaan 222, 3526 RP Utrecht	2026-10-22 21:39:58.359	2026-10-22 21:39:58.359	814	60	ACTIVE	2026-10-22	\N
cmvk2dzx5001q10qotybjg1o3	Elgazie	Zankoua	N.zankoua@hotmail.com	0614335053	Stanleylaan 29, 3526ta Utrecht	2026-10-22 21:39:58.361	2026-10-22 21:39:58.361	804	61	ACTIVE	2026-08-31	\N
cmvk2dzx8001r10qog9d66j8i	el amrani	Najim	\N	0628187564	Geelwortelweg 22, 3541 SR Utrecht	2026-10-22 21:39:58.364	2026-10-22 21:39:58.364	123	62	ACTIVE	2026-10-22	\N
cmvk2dzxa001s10qozpodcwpv	Soufiane	El Bounayi	\N	0641604400	Columbuslaan 295, 3526 EH Utrecht	2026-10-22 21:39:58.366	2026-10-22 21:39:58.366	653	63	ACTIVE	2026-10-22	\N
cmvk2dzxd001t10qopewcvdp0	Abdellah	Moussi	\N	0624686582	Stanleylaan 174, 3526TR Utrecht	2026-10-22 21:39:58.369	2026-10-22 21:39:58.369	793	64	ACTIVE	2026-10-22	\N
cmvk2dzxg001u10qo272xz2kk	Mimoun	Asfad	\N	0641125289	Alexander de Grotelaan 114, 3526 RL Utrecht	2026-10-22 21:39:58.372	2026-10-22 21:39:58.372	777	66	ACTIVE	2026-10-22	\N
cmvk2dzxi001v10qour53x00t	Elkhadir	KhaddamAllah	Sirena.elsebty@gmail.com	0644639877	Rooseveltaan 200, 3527AJ Utrecht	2026-10-22 21:39:58.374	2026-10-22 21:39:58.374	231	67	ACTIVE	2026-10-22	\N
cmvk2dzxl001w10qoobn99zra	Hafid	Elmonjed	jamilaelmonjed@hotmail.com	0624440142	Prof.Aalbersestraat 8, 3438AV Nieuwegein	2026-10-22 21:39:58.377	2026-10-22 21:39:58.377	929	68	ACTIVE	2026-10-22	\N
cmvk2dzxo001x10qo8unsq1z8	Khalid	El mansouri	\N	0618088417	Van echoualaan 71, 3526 KB Utrecht	2026-10-22 21:39:58.38	2026-10-22 21:39:58.38	575	69	ACTIVE	2026-10-22	\N
cmvk2dzxr001y10qoeb29pm3u	Abdelkadir	Zoundri	\N	0684360144	Afrikalaan 85, 3526 VL Utrecht	2026-10-22 21:39:58.383	2026-10-22 21:39:58.383	531	71	ACTIVE	2026-10-22	\N
cmvk2dzxu001z10qo5h8sito1	Khalid	Azaroual	khalid.azaroual@live.nl	0641165819	Magelheanlaan 112, 3526CK Utrecht	2026-10-22 21:39:58.386	2026-10-22 21:39:58.386	595	73	ACTIVE	2026-10-22	\N
cmvk2dzxw002010qo7w4lyzfg	Ali	Bendriss	\N	0624815202	Postmalaan 33, 3527XX Utrecht	2026-10-22 21:39:58.388	2026-10-22 21:39:58.388	978	74	ACTIVE	2026-10-22	\N
cmvk2dzxz002110qov9gtndoa	Fouad	Azeroual	Abdelabderrahman@gmail.com	0685542743	Konning Willminalaan 12, 3527 LD Utrecht	2026-10-22 21:39:58.391	2026-10-22 21:39:58.391	146	75	ACTIVE	2026-10-22	\N
cmvk2dzy1002210qo4hyr3nht	Nordin	Ahamiane	\N	0642215507	Trumanlaan 253, 3527 BH Utrecht	2026-10-22 21:39:58.393	2026-10-22 21:39:58.393	871	76	ACTIVE	2026-10-22	\N
cmvk2dzy5002310qorjnykm8h	Bennassar	Zaim	\N	0627057803	Kamilleweg 16A, 3541RN Utrecht	2026-10-22 21:39:58.397	2026-10-22 21:39:58.397	1210	77	ACTIVE	2026-10-22	\N
cmvk2dzy9002410qogrc2xyq3	Ali	el Abbassi	Ali.el.abbassi@hotmail.com	0641667768	De Gasperilaan 71, 3527 GD Utrecht	2026-10-22 21:39:58.401	2026-10-22 21:39:58.401	425	78	ACTIVE	2026-10-22	\N
cmvk2dzyb002510qofy5dr6tt	Mohamed	Zaoumi	\N	0648451122	Rooseveltlaan 878, 3526 BN Utrecht	2026-10-22 21:39:58.403	2026-10-22 21:39:58.403	1074	79	ACTIVE	2026-10-22	\N
cmvk2dzye002610qo0eq0lsz9	Mohamed	Bakkich	\N	0623014236	Lanslaan 13, 3526 XG Utrecht	2026-10-22 21:39:58.406	2026-10-22 21:39:58.406	713	80	ACTIVE	2026-10-22	\N
cmvk2dzyg002710qo9mbv8mj1	Mohamed	Soulayman	\N	0630051568	Van Bijnkershoekslaan 369, 3527 XJ Utrecht	2026-10-22 21:39:58.408	2026-10-22 21:39:58.408	9004	81	ACTIVE	2026-10-22	\N
cmvk2dzyi002810qoi6bcy6d2	Adil	El abassi	Amina.hammoudi@hotmail.com	0611781429	Maasstraat 32, 5322tj Utrecht	2026-10-22 21:39:58.41	2026-10-22 21:39:58.41	479	83	ACTIVE	2026-10-22	\N
cmvk2dzyl002910qoys4w9gze	Mustapha	El Harouachi	\N	0681432745	Pearsonlaan 43, 3527 CA Utrecht	2026-10-22 21:39:58.413	2026-10-22 21:39:58.413	84	84	ACTIVE	2026-10-22	\N
cmvk2dzyq002a10qoebimwdak	Mostapha	Bouabid	\N	0645160406	Battutalaan 483, 3527 GX Utrecht	2026-10-22 21:39:58.418	2026-10-22 21:39:58.418	416	86	ACTIVE	2026-10-22	\N
cmvk2dzyu002b10qofmjm4adf	Almir	Alhou	\N	0642120704	\N	2026-10-22 21:39:58.422	2026-10-22 21:39:58.422	354	87	ACTIVE	2026-10-22	\N
cmvk2dzyx002c10qop2jjy43w	Mohamadi	Alboazati	\N	0623732815	Van Boerlestraat 1 Bis, 3521 VP Utrecht	2026-10-22 21:39:58.425	2026-10-22 21:39:58.425	1213	90	ACTIVE	2026-10-22	\N
cmvk2dzz0002d10qofn32e4e1	Rachid	Ibrahimi	\N	0681903835	Egginklaan 22, 3527 XR Utrecht	2026-10-22 21:39:58.428	2026-10-22 21:39:58.428	878	91	ACTIVE	2026-10-22	\N
cmvk2dzz2002e10qo12ibofwy	Mohamed	Safi	\N	0648982276	Spaaklaan 191, 3527 CG Utrecht	2026-10-22 21:39:58.43	2026-10-22 21:39:58.43	574	93	ACTIVE	2026-10-22	\N
cmvk2dzz4002f10qor0exmr6l	Louiza/Safiati	El Fahmi	\N	0643559168	Columbuslaan 189, Utrecht	2026-10-22 21:39:58.432	2026-10-22 21:39:58.432	95	95	ACTIVE	2026-10-22	\N
cmvk2dzz8002g10qo0jkvuybi	AbdelKarim	Akbiach	\N	0685347428	Pearsonlaan 73, 3527CB Utrecht	2026-10-22 21:39:58.436	2026-10-22 21:39:58.436	1076	97	ACTIVE	2026-10-22	\N
cmvk2dzzb002h10qo43chr4gi	Abdelmaki	Barrani	Aboeadam@live.nl	0643085419	Pecanlaan 16, 3545 AE Utrecht	2026-10-22 21:39:58.439	2026-10-22 21:39:58.439	115	98	ACTIVE	2026-10-22	\N
cmvk2dzze002i10qolwfopoid	Youssef	Bouhjira	\N	0620638805	Afrikalaan 183, 3526BM Utrecht	2026-10-22 21:39:58.442	2026-10-22 21:39:58.442	767	99	ACTIVE	2026-10-22	\N
cmvk2dzzk002j10qo1a17wuz7	Azouzi	Kamar/Azouzi	\N	\N	Rooseveltlaan 348, Utrecht	2026-10-22 21:39:58.448	2026-10-22 21:39:58.448	66	100	ACTIVE	2026-10-22	\N
cmvk2dzzp002k10qodrblt1ll	Abdelwaheb	Zaim	\N	0684360117	Pearsonlaan 92, 3527 CD Utrecht	2026-10-22 21:39:58.453	2026-10-22 21:39:58.453	23	101	ACTIVE	2026-10-22	\N
cmvk2dzzs002l10qooafcu6iv	Said	Darkaoui	\N	0614371450	Globebloemlaan 21, 3452CG Utrecht	2026-10-22 21:39:58.456	2026-10-22 21:39:58.456	427	102	ACTIVE	2026-10-22	\N
cmvk2dzzv002m10qoe7vbq5nv	Mohamed	Tajjioui	\N	0624962741	Marschalllaan 6, 3527 TL Utrecht	2026-10-22 21:39:58.459	2026-10-22 21:39:58.459	659	104	ACTIVE	2026-10-22	\N
cmvk2e00c002n10qos8jn3zkz	Karim	El Bouayadi	\N	0638734173	Afrikalaan 40, Utrecht	2026-10-22 21:39:58.476	2026-10-22 21:39:58.476	917	105	ACTIVE	2026-10-22	\N
cmvk2e00h002o10qo3p6xf4st	Ahmed	Jadoun	\N	0655869510	Adenauerlaan 197, 3527 RF Utrecht	2026-10-22 21:39:58.481	2026-10-22 21:39:58.481	160	106	ACTIVE	2026-10-22	\N
cmvk2e00j002p10qop1t141a0	Abdelkhalek	Erazzi	\N	0619136235	Van Eysingalaan 146, 3527 VP Utrecht	2026-10-22 21:39:58.483	2026-10-22 21:39:58.483	457	107	ACTIVE	2026-10-22	\N
cmvk2e00m002q10qo4uxhui6w	Mostapha	Sakour	\N	0653933981	Hooivlinder 16, 3544 VZ Utrecht	2026-10-22 21:39:58.486	2026-10-22 21:39:58.486	401	108	ACTIVE	2026-10-22	\N
cmvk2e00q002r10qolupqdwoq	Aziz	Ben taleb	\N	0636334045	Magelhaenlaan 40, 3526CH Utrcht	2026-10-22 21:39:58.49	2026-10-22 21:39:58.49	753	110	ACTIVE	2026-10-22	\N
cmvk2e00u002s10qo0zuphl6q	Mohamed	BOULALMA	\N	0626878600	Livingstonelaan 297, 3526 HG Utrecht	2026-10-22 21:39:58.494	2026-10-22 21:39:58.494	507	112	ACTIVE	2026-10-22	\N
cmvk2e00y002t10qok8edizk0	Mahmoud	Karakali	\N	0653938136	Adenauerlaan 35, 3526 XJ Utrecht	2026-10-22 21:39:58.498	2026-10-22 21:39:58.498	9007	114	ACTIVE	2026-10-22	\N
cmvk2e011002u10qoqqrcb9x1	Mohamed	Ettahri	m.ettahri@hotmail.com	0681122604	Iepstraat 72, 3434AV Nieuwegein	2026-10-22 21:39:58.501	2026-10-22 21:39:58.501	922	115	ACTIVE	2026-10-22	\N
cmvk2e017002v10qongzz981k	Tarik	Alkhouli	\N	0646876303	Stanleylaan 212, 3526TS Utrecht	2026-10-22 21:39:58.507	2026-10-22 21:39:58.507	736	116	ACTIVE	2026-10-22	\N
cmvk2e01a002w10qo0odhm3du	Jamal	Kassmi	\N	0686157185	Europalaan 19, Utrecht	2026-10-22 21:39:58.51	2026-10-22 21:39:58.51	936	117	ACTIVE	2026-10-22	\N
cmvk2e01f002x10qoz119295f	Bilal	Chentouf	\N	0630461087	Fletcher Hendersonstraat 40, 3543GL Utrecht	2026-10-22 21:39:58.515	2026-10-22 21:39:58.515	122	120	ACTIVE	2026-10-22	\N
cmvk2e01j002y10qosb3vvraw	Abdoulhafid	Bouhjira	\N	0648321547	Utrecht	2026-10-22 21:39:58.519	2026-10-22 21:39:58.519	337	122	ACTIVE	2026-10-22	\N
cmvk2e01l002z10qo4ze66ahu	Mohamadi	Aissaoui	\N	0610654252	Spaaklaan 80, 3527 SL Utrecht	2026-10-22 21:39:58.521	2026-10-22 21:39:58.521	200	124	ACTIVE	2026-10-22	\N
cmvk2e01p003010qoxiion3je	Mustafa	El Kouskous	\N	0644993023	Livingstonelaan 63, 3526 HB Utrecht	2026-10-22 21:39:58.525	2026-10-22 21:39:58.525	326	125	ACTIVE	2026-10-22	\N
cmvk2e01s003110qoi5te7qir	Brahim	Elfaraousi	\N	0614109902	Spaaklaan 163, Utrecht	2026-10-22 21:39:58.528	2026-10-22 21:39:58.528	125	126	ACTIVE	2026-10-22	\N
cmvk2e01v003210qorg0zq5nr	Abdelaziz	El Hajari	\N	0643231648	\N	2026-10-22 21:39:58.531	2026-10-22 21:39:58.531	1050	127	ACTIVE	2026-10-22	\N
cmvk2e01y003310qo6ozjb1b2	Ali (opa)	Bouhdifi/Kala	\N	0624588566	Rooseveltlaan 342, 3527 AM Utrecht	2026-10-22 21:39:58.534	2026-10-22 21:39:58.534	147	128	ACTIVE	2026-10-22	\N
cmvk2e023003410qo09vac6hc	Khalid	Zankoua	Souadsouad_89@hotnail.com	0642384115	Columbuslaan 177, 3526ED Utrecht	2026-10-22 21:39:58.539	2026-10-22 21:39:58.539	514	129	ACTIVE	2026-10-22	\N
cmvk2e026003510qopqyq13g8	Mimoun	El Jaghaoui	\N	0638430769	Alexander de grootlaan 35, 3526 RB Utrecht	2026-10-22 21:39:58.542	2026-10-22 21:39:58.542	733	131	ACTIVE	2026-10-22	\N
cmvk2e029003610qob30mupr4	Mohamed	Kadioui	\N	0684371674	Adenauerlaan 170, 3527 RL Utrecht	2026-10-22 21:39:58.545	2026-10-22 21:39:58.545	414	132	ACTIVE	2026-10-22	\N
cmvk2e02b003710qoov178x4q	Mostapha	Belhadi	\N	0647907786	Livingstonelaan 279, 3526 HG Utrecht	2026-10-22 21:39:58.547	2026-10-22 21:39:58.547	918	133	ACTIVE	2026-10-22	\N
cmvk2e02d003810qoz7jhpqg7	Otman	Masouti	\N	0644652141	Culumbuslaan 183, 3526ED Utrecht	2026-10-22 21:39:58.549	2026-10-22 21:39:58.549	794	135	ACTIVE	2026-10-22	\N
cmvk2e02f003910qorbq9cwho	Mhammed	Aarbi	\N	0628685637	Sassefralaan 67, 3545 CM Utrecht	2026-10-22 21:39:58.551	2026-10-22 21:39:58.551	1062	137	ACTIVE	2026-10-22	\N
cmvk2e02h003a10qoxlkq0rdl	Mohamed	Maryaoui	Maryaoui@outlook.com	0634445667	Marco Pololaan 220, 3526 GN Utrecht	2026-10-22 21:39:58.553	2026-10-22 21:39:58.553	362	139	ACTIVE	2026-10-22	\N
cmvk2e02j003b10qoice44sc6	Jamal	Alali	\N	0686123656	Rooseveltlaan 215, Utrecht	2026-10-22 21:39:58.555	2026-10-22 21:39:58.555	9008	141	ACTIVE	2026-10-22	\N
cmvk2e02m003c10qofdxmo5sx	Jamila	Boudount	\N	0641951478	Battoutalaan, 3526 VS Utrecht	2026-10-22 21:39:58.558	2026-10-22 21:39:58.558	824	143	ACTIVE	2026-10-22	\N
cmvk2e02t003d10qo1tl8atzk	Abdelmajid	Kourachi	\N	0638110713	Utrecht	2026-10-22 21:39:58.565	2026-10-22 21:39:58.565	312	144	ACTIVE	2026-10-22	\N
cmvk2e02y003e10qo1h8vl2xc	Amarouch	Azrioual	a azrioual@live.nl	0685090907	Rooseveltlaan 986, 3526br Utrecht	2026-10-22 21:39:58.57	2026-10-22 21:39:58.57	356	145	ACTIVE	2025-02-11	\N
cmvk2e031003f10qothp9g2ve	Hamza	El hadri	ikram.elhadri@hotmail.com	0616086001	rechthuisdrift 3, 3436cs Nieuwegein	2026-10-22 21:39:58.573	2026-10-22 21:39:58.573	778	147	ACTIVE	2026-10-22	\N
cmvk2e037003g10qol44iwetw	Brahim	Jaghaoui	\N	0685042608	Stanleylaan 263, 3526 TG Utrecht	2026-10-22 21:39:58.579	2026-10-22 21:39:58.579	431	148	ACTIVE	2026-10-22	\N
cmvk2e03a003h10qou2l0ku7h	Ahmed	Zaadoudi	\N	0685333202	Rooseveltlaan 194, 3527 AJ Utrecht	2026-10-22 21:39:58.582	2026-10-22 21:39:58.582	629	149	ACTIVE	2026-10-22	\N
cmvk2e03d003i10qoslsc0xnu	Brahim	Boussadkat	\N	0639049138	Saxofoonlaan 19, 3438 GV Nieuwegein	2026-10-22 21:39:58.585	2026-10-22 21:39:58.585	621	151	ACTIVE	2026-10-22	\N
cmvk2e03h003j10qoxycmqktn	Mourad	Ben Taleb	\N	0638588869	Maghelhaenlaan 40, Utrecht	2026-10-22 21:39:58.589	2026-10-22 21:39:58.589	323	152	ACTIVE	2026-10-22	\N
cmvk2e03l003k10qo4tgsojwr	Hassan	Kaab	Hassanknl@outlook.com	0684247104	Marshalllaan 85, 3527TB Utrecht	2026-10-22 21:39:58.593	2026-10-22 21:39:58.593	422	153	ACTIVE	2026-10-22	\N
cmvk2e03p003l10qow2920sjs	Najim	El Monjed	\N	0684784170	Herderlaan 13, 3533 BH Utrecht	2026-10-22 21:39:58.597	2026-10-22 21:39:58.597	1176	154	ACTIVE	2026-10-22	\N
cmvk2e03s003m10qoyu9jpore	Abderrahim	Bitich	\N	0642926698	Pearsonlaan 86, 3527 CD Utrecht	2026-10-22 21:39:58.6	2026-10-22 21:39:58.6	622	155	ACTIVE	2026-10-22	\N
cmvk2e03v003n10qow1m9tin6	Ismail	Lafkiri	\N	0641837019	Rooseveltlaan 245, 3527AB Utrecht	2026-10-22 21:39:58.603	2026-10-22 21:39:58.603	603	156	ACTIVE	2026-10-22	\N
cmvk2e03y003o10qoyaoz7zyn	Mustafa	Tizra	\N	0648317717	Magelhaenlaan 60, 3526CJ Utrecht	2026-10-22 21:39:58.606	2026-10-22 21:39:58.606	658	157	ACTIVE	2026-10-22	\N
cmvk2e041003p10qo6dm51d93	Mohammed	Mallahi	\N	0638761266	Grebbstraat 38, 3822 Utrecht	2026-10-22 21:39:58.609	2026-10-22 21:39:58.609	564	158	ACTIVE	2026-10-22	\N
cmvk2e043003q10qopbnscu18	oum	Mourad	\N	0649817787	Rooseveltlaan 120, 3527 AG Utrecht	2026-10-22 21:39:58.611	2026-10-22 21:39:58.611	9018	159	ACTIVE	2026-10-22	\N
cmvk2e048003r10qonwehff0f	Aderghal	Bouaarfa	\N	0641896763	Johan Brouwerlaan 45, 3526 XJ Utrecht	2026-10-22 21:39:58.616	2026-10-22 21:39:58.616	680	162	ACTIVE	2026-10-22	\N
cmvk2e04f003s10qoet1m9otw	Zakaria	Talhi	\N	0627205903	Kervelhof 15, 3544 BM Utrecht	2026-10-22 21:39:58.623	2026-10-22 21:39:58.623	90	163	ACTIVE	2026-10-22	\N
cmvk2e04j003t10qou5vdmlxu	Ali	Naanai	\N	0644474445	Wanninkhoflaan 16, 3526 XP Utrecht	2026-10-22 21:39:58.627	2026-10-22 21:39:58.627	533	164	ACTIVE	2026-10-22	\N
cmvk2e04n003u10qokjfb33lm	Abdelnasser	Saloum Maha Haj Ahmed	\N	0684550586	Rooseveltlaan 212, Utrecht	2026-10-22 21:39:58.631	2026-10-22 21:39:58.631	9009	165	ACTIVE	2026-10-22	\N
cmvk2e04r003v10qosjf8a3xh	El mokhtar	El mimouni	Ainzoura.1971@hotmail.nl	0686186129	Alexander de grotelaan 111, 3526 RD Utrecht	2026-10-22 21:39:58.636	2026-10-22 21:39:58.636	228	167	ACTIVE	2026-10-22	\N
cmvk2e04v003w10qow4ztib5v	Malika	Aachboun (moeder)	\N	0685289574	Stanleylaan 32, 3526 TL Utrecht	2026-10-22 21:39:58.64	2026-10-22 21:39:58.64	645	168	ACTIVE	2026-10-22	\N
cmvk2e04y003x10qoh3s7idcv	AbdelAli	ElMakaoui	\N	0633885997	Van Eechoudlaan 89, 3526 KB Utrecht	2026-10-22 21:39:58.642	2026-10-22 21:39:58.642	158	169	ACTIVE	2026-10-22	\N
cmvk2e052003y10qo5fbjl02o	Chaib	Darrazi	\N	0626473808	Nansenlaan 80, 3527 EK Utrecht	2026-10-22 21:39:58.646	2026-10-22 21:39:58.646	678	170	ACTIVE	2026-10-22	\N
cmvk2e055003z10qor4z8bz65	Said	Ouazil	\N	0686464116	Bonenkuidstraat 34, 3544 CL Utrecht	2026-10-22 21:39:58.649	2026-10-22 21:39:58.649	462	171	ACTIVE	2026-10-22	\N
cmvk2e059004010qozitt32od	Rachid	Ousrout	\N	0643022200	Marcopololaan 264, 3526GP Utrecht	2026-10-22 21:39:58.653	2026-10-22 21:39:58.653	218	173	ACTIVE	2025-07-10	\N
cmvk2e05c004110qoamkrpmni	Mohamed	Tamaoui	\N	0611214554	Spaaklaan 154, 3527 NS Utrecht	2026-10-22 21:39:58.656	2026-10-22 21:39:58.656	884	174	ACTIVE	2026-10-22	\N
cmvk2e05k004210qoan7wg9y7	Adoua	El Madaghri/El adoui	\N	0641825433	Marshalllaan 62, 3527 TM Utrecht	2026-10-22 21:39:58.664	2026-10-22 21:39:58.664	491	175	ACTIVE	2026-10-22	\N
cmvk2e05s004310qohlncdoil	Mustapha	Mustapha	\N	0685531109	\N	2026-10-22 21:39:58.672	2026-10-22 21:39:58.672	9010	178	ACTIVE	2026-10-22	\N
cmvk2e05v004410qoz0tscxpi	Ahmed	Douiri	\N	0634247276	Rooseveltlaan 322, 3527 AM Utrecht	2026-10-22 21:39:58.675	2026-10-22 21:39:58.675	1146	179	ACTIVE	2026-10-22	\N
cmvk2e064004510qobb90iyql	Kamal	Aissaoui / Kasmi	gewoon_youssra@live.nl	0617854765	Fultonbaan 7237, 3439NE Nieuwegein	2026-10-22 21:39:58.684	2026-10-22 21:39:58.684	984	180	ACTIVE	2026-10-22	\N
cmvk2e06i004610qo9zjye869	Mohamed	Abdelli	\N	0638023811	Marshalllaan 91, 3527TC Utrecht	2026-10-22 21:39:58.698	2026-10-22 21:39:58.698	411	181	ACTIVE	2025-09-21	\N
cmvk2e06u004710qob7xfcl6l	Karim	Tahiry	\N	0624216845	Livingstonelaan493, 3526 HJ Utrecht	2026-10-22 21:39:58.71	2026-10-22 21:39:58.71	1091	182	ACTIVE	2026-10-22	\N
cmvk2e074004810qog6lax1h0	Ahmed	Bouabid	\N	0687838368	alexander de grootlaan 224, 3526 RP Utrecht	2026-10-22 21:39:58.72	2026-10-22 21:39:58.72	585	186	ACTIVE	2026-10-22	\N
cmvk2e078004910qo30rtyuao	Rachid	Masnaoui	\N	0619157376	Van Echoudlaan 16, 3526 KD Utrecht	2026-10-22 21:39:58.724	2026-10-22 21:39:58.724	1042	187	ACTIVE	2026-10-22	\N
cmvk2e07d004a10qorwrmaho2	Issa	Karoumi (meester)	\N	\N	\N	2026-10-22 21:39:58.729	2026-10-22 21:39:58.729	7001	188	ACTIVE	2026-10-22	\N
cmvk2e07g004b10qoqzabhi1w	Ahmed	El Ouarradi	\N	0640649755	Alexander de grooelaan 263, 3526 RH Utrecht	2026-10-22 21:39:58.732	2026-10-22 21:39:58.732	1008	191	ACTIVE	2026-10-22	\N
cmvk2e07m004c10qojv6rfb08	Ahmed	Ajaoud	\N	0687836892	Marchalaan 75, 3527TD Utrecht	2026-10-22 21:39:58.738	2026-10-22 21:39:58.738	571	192	ACTIVE	2026-10-22	\N
cmvk2e07s004d10qot31pdbfk	Aissaoui	Aissaoui	\N	0610477782	Van Heuven Goedhartlaan 72, 3527 CL Utrecht	2026-10-22 21:39:58.744	2026-10-22 21:39:58.744	296	194	ACTIVE	2026-10-22	\N
cmvk2e07v004e10qofyk5hqbk	Ahmed	Hitou	\N	0631756247	Rooseveltlaan 1086, 3526 RT Utrecht	2026-10-22 21:39:58.747	2026-10-22 21:39:58.747	1137	195	ACTIVE	2026-10-22	\N
cmvk2e07y004f10qom17203k8	Said	Ramdani	\N	0640756885	\N	2026-10-22 21:39:58.75	2026-10-22 21:39:58.75	701	196	ACTIVE	2026-10-22	\N
cmvk2e082004g10qoeupz1l26	Mohamed	Balilou	\N	0654748582	Adnourlaan 181, 3527RE Utrecht	2026-10-22 21:39:58.754	2026-10-22 21:39:58.754	727	197	ACTIVE	2026-10-22	\N
cmvk2e08d004h10qoc9lqzuhz	Mohamed	Kissami	\N	0687533470	Marshalllaan 22, 3527 TL Utrecht	2026-10-22 21:39:58.765	2026-10-22 21:39:58.765	888	198	ACTIVE	2026-10-22	\N
cmvk2e08r004i10qoerxl1vj2	Mohamed	Belhadi	\N	0614537168	Livingstonelaan 145, 3526 HC Utrecht	2026-10-22 21:39:58.779	2026-10-22 21:39:58.779	467	200	ACTIVE	2026-10-22	\N
cmvk2e08w004j10qo8u4g42hs	Farid	Zaydi	\N	0687544704	Arikalaan 119, 3526 Utrecht	2026-10-22 21:39:58.784	2026-10-22 21:39:58.784	723	201	ACTIVE	2026-10-22	\N
cmvk2e090004k10qo1uq97pr1	Mohamed	Bachiri	\N	0642385676	Koningin Wilhelminalaan 58, 3527 LE Utrecht	2026-10-22 21:39:58.788	2026-10-22 21:39:58.788	732	203	ACTIVE	2026-10-22	\N
cmvk2e093004l10qonqeu45pf	Hassan	Doudalla	\N	0686492622	Pearsonlaan 102, 3527 CD Utrecht	2026-10-22 21:39:58.791	2026-10-22 21:39:58.791	1016	204	ACTIVE	2026-10-22	\N
cmvk2e097004m10qo3gkab08j	Rachid	Hamdi	\N	0638365585	Adenaouerlaan 198, 3527RL Utrecht	2026-10-22 21:39:58.795	2026-10-22 21:39:58.795	1082	205	ACTIVE	2026-10-22	\N
cmvk2e09a004n10qoue735gut	Nouredine	Sakkour	\N	0651433894	Safranelaan 54, Utrecht	2026-10-22 21:39:58.798	2026-10-22 21:39:58.798	887	207	ACTIVE	2024-01-14	\N
cmvk2e09c004o10qo7qo04wio	Mohamed	El Kachouti	melkachouti1@gmail.com	0648658587	Rooseveltlaan 1074, 3526bt Utrecht	2026-10-22 21:39:58.8	2026-10-22 21:39:58.8	967	209	ACTIVE	2026-10-22	\N
cmvk2e09j004p10qo8rsa9une	Omar	Rahhou	omarrahhou@hotmail.com	0611472299	Trumanlaan 13, 3527bb Utrecht	2026-10-22 21:39:58.807	2026-10-22 21:39:58.807	502	210	ACTIVE	2026-10-22	\N
cmvk2e09n004q10qozuwhhtbr	Ahmed	Azerkane	\N	0684151464	Pearsonlaan 20, 3527 Utrecht	2026-10-22 21:39:58.811	2026-10-22 21:39:58.811	818	211	ACTIVE	2026-10-22	\N
cmvk2e0a0004r10qo3c3ychu1	Tijani	Dya	\N	0615378066	Adenauerlaan 175, 3527RD Utrecht	2026-10-22 21:39:58.824	2026-10-22 21:39:58.824	\N	213	ACTIVE	2026-10-22	\N
cmvk2e0a4004s10qop51oqauy	Zouhir	Boutayeb	\N	0652646684	tweede muntmeesterslaan 36, 3541 GV Utrecht	2026-10-22 21:39:58.828	2026-10-22 21:39:58.828	963	214	ACTIVE	2026-10-22	\N
cmvk2e0a7004t10qokx0paehf	Anas	El Abbassi	\N	0628798048	Pearsonlaan 59, 3531EJ Utrecht	2026-10-22 21:39:58.831	2026-10-22 21:39:58.831	865	215	ACTIVE	2026-10-22	\N
cmvk2e0aa004u10qokqlvgzz9	Alhoussin	Alyakoubi	\N	0640726781	stanleylaan 61, 3526TB Utrecht	2026-10-22 21:39:58.834	2026-10-22 21:39:58.834	7004	216	ACTIVE	2026-10-22	\N
cmvk2e0ae004v10qoymkzndum	Mohamed	Lahrach	\N	0648557892	Eerste muntmeesterlaan 27, 3541 GB Utrecht	2026-10-22 21:39:58.838	2026-10-22 21:39:58.838	7002	218	ACTIVE	2026-10-22	\N
cmvk2e0ag004w10qoo41lwhgq	Mohamed	Moumni	\N	0618028111	De Akker 25, 3411 zg lopik	2026-10-22 21:39:58.84	2026-10-22 21:39:58.84	959	220	ACTIVE	2026-10-22	\N
cmvk2e0an004x10qo3bykcxwe	mohamad	siraj	researchersprime@gmail.com	0681150301	marketensterlaan 13, 3454wn utrecht	2026-10-22 21:39:58.847	2026-10-22 21:39:58.847	9013	222	ACTIVE	2026-10-22	\N
cmvk2e0aq004y10qo2hcxl457	Said	Ouari	Said.je@hotmail.com	0623435073	Stanleylaan 270, 3526 TV Utrecht	2026-10-22 21:39:58.85	2026-10-22 21:39:58.85	768	224	ACTIVE	2026-10-22	\N
cmvk2e0at004z10qopprxrufs	Abdelhafid	Attalbi	\N	0619307565	Koningin Wilhelminalaan 28, 3517 LD Utrecht	2026-10-22 21:39:58.853	2026-10-22 21:39:58.853	986	225	ACTIVE	2026-10-22	\N
cmvk2e0aw005010qog7b61jr6	Hamza	Mahdad	\N	0614523635	Kamilleweg 14A, 3541 RN Utrecht	2026-10-22 21:39:58.857	2026-10-22 21:39:58.857	831	228	ACTIVE	2026-10-22	\N
cmvk2e0b0005110qo63mtklw1	Oussama	Sbaa	\N	0683422105	Duke Ellintonstraat 10, 3543 GK Utrecht	2026-10-22 21:39:58.86	2026-10-22 21:39:58.86	927	230	ACTIVE	2026-10-22	\N
cmvk2e0b5005210qorgq8rv45	Taha	AL Khalaf	\N	0684051235	Abestederdijk 148, 3582 BV Utrecht	2026-10-22 21:39:58.865	2026-10-22 21:39:58.865	9015	231	ACTIVE	2026-10-22	\N
cmvk2e0bb005310qopcqsq173	Omar	Aoulad l kadi	\N	0685541723	Johan Brouwerlaan 3, 3526 XJ Utrecht	2026-10-22 21:39:58.871	2026-10-22 21:39:58.871	740	232	ACTIVE	2026-10-22	\N
cmvk2e0bi005410qou4v27t6t	Alami	Fallous	\N	0631130084	Livingstoenlaan 217, 3526HE Utrecht	2026-10-22 21:39:58.878	2026-10-22 21:39:58.878	859	235	ACTIVE	2026-10-22	\N
cmvk2e0bm005510qoyn47kyzb	Hassan	Ikken	\N	0628704671	\N	2026-10-22 21:39:58.882	2026-10-22 21:39:58.882	691	243	ACTIVE	2026-10-22	\N
cmvk2e0bs005610qocf4x2m4x	Abdelhak	Essadik	a.esadik@triatmin.nl	0641048916	Shipovalaan 40, 3545 DC Utrecht	2026-10-22 21:39:58.888	2026-10-22 21:39:58.888	667	251	ACTIVE	2026-10-22	\N
cmvk2e0by005710qowarm4ppg	Onbekend	Onbekend (8888)	\N	\N	\N	2026-10-22 21:39:58.894	2026-10-22 21:39:58.894	8888	65	ACTIVE	2026-10-22	\N
cmvk2e0c4005810qoacv4wgeb	Onbekend	Onbekend (9999)	\N	\N	\N	2026-10-22 21:39:58.9	2026-10-22 21:39:58.9	9999	70	ACTIVE	2026-10-22	\N
cmvk2e0c8005910qo6snas5k7	Onbekend	Onbekend (157)	\N	\N	\N	2026-10-22 21:39:58.904	2026-10-22 21:39:58.904	157	72	ACTIVE	2026-10-22	\N
cmvk2e0cd005a10qodtv0o5s2	Onbekend	Onbekend (12)	\N	\N	\N	2026-10-22 21:39:58.909	2026-10-22 21:39:58.909	12	82	ACTIVE	2026-10-22	\N
cmvk2e0cg005b10qo0zjfp6ds	Onbekend	Onbekend (242)	\N	\N	\N	2026-10-22 21:39:58.912	2026-10-22 21:39:58.912	242	85	ACTIVE	2026-10-22	\N
cmvk2e0ci005c10qoth8k5c6m	Onbekend	Onbekend (9006)	\N	\N	\N	2026-10-22 21:39:58.914	2026-10-22 21:39:58.914	9006	88	ACTIVE	2026-10-22	\N
cmvk2e0ck005d10qouxdg7bwm	Onbekend	Onbekend (481)	\N	\N	\N	2026-10-22 21:39:58.916	2026-10-22 21:39:58.916	481	89	ACTIVE	2026-10-22	\N
cmvk2e0co005e10qohukjpss4	Onbekend	Onbekend (461)	\N	\N	\N	2026-10-22 21:39:58.92	2026-10-22 21:39:58.92	461	92	ACTIVE	2026-10-22	\N
cmvk2e0cq005f10qo32f2jore	Onbekend	Onbekend (7777)	\N	\N	\N	2026-10-22 21:39:58.922	2026-10-22 21:39:58.922	7777	94	ACTIVE	2026-10-22	\N
cmvk2e0cu005g10qomvwgfkkh	Onbekend	Onbekend (300)	\N	\N	\N	2026-10-22 21:39:58.926	2026-10-22 21:39:58.926	300	96	ACTIVE	2026-10-22	\N
cmvk2e0cx005h10qoqbyvem6q	Onbekend	Onbekend (349)	\N	\N	\N	2026-10-22 21:39:58.929	2026-10-22 21:39:58.929	349	103	ACTIVE	2026-10-22	\N
cmvk2e0cz005i10qo5lb871sy	Onbekend	Onbekend (9011)	\N	\N	\N	2026-10-22 21:39:58.931	2026-10-22 21:39:58.931	9011	109	ACTIVE	2026-10-22	\N
\.


--
-- Data for Name: levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.levels (id, name, "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmuhhs8tp0001b16dttc1x8ci	Niveau 2	2	2026-09-25 21:47:56.461	2026-09-25 21:48:00.383
cmuhhshwq0002b16dmj4ohr4u	Niveau 3	3	2026-09-25 21:48:08.234	2026-09-25 21:48:08.234
cmvdd6wdh000601n4v1jiqxle	Niveau 4	4	2026-10-18 05:07:59.717	2026-10-18 05:09:25.809
cmuhhs3tw0000b16dt3vyjoxl	Niveau 1	1	2026-09-25 21:47:49.988	2026-10-19 10:30:11.841
cmvdd7108000701n4jz3ooq5j	Niveau 5	5	2026-10-18 05:08:05.72	2026-10-20 14:16:38.246
cmvdd7cl8000801n4shqb3ahd	Niveau 6	6	2026-10-18 05:08:20.732	2026-10-23 15:23:44.209
\.


--
-- Data for Name: period_report_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.period_report_observations (id, "studentId", "termId", "academicYearId", body, "recordedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: registration_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registration_settings (id, "linkValidityDays", "createdAt", "updatedAt", "archiveRetentionMonths") FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rooms (id, name, capacity, "createdAt", "updatedAt", description) FROM stdin;
cmvdcxzvz000301n4c4so4dhf	E3	27	2026-10-18 05:01:04.368	2026-10-18 05:01:04.368	Eerste verdieping lokaal nr 3
cmuhhvtow0005b16dvond9z61	BG-1	26	2026-09-25 21:50:43.472	2026-10-18 05:02:02.589	Bgang grond lokaal nr 1
cmuhhvzri0006b16dujdfvuxx	BG-2	26	2026-09-25 21:50:51.342	2026-10-18 05:02:14.991	Bgang grond lokaal nr 2
cmvdczzmi000401n46qbaitqr	E4	28	2026-10-18 05:02:37.338	2026-10-18 05:02:49.976	Eerste verdieping lokaal nr 4
cmvdd0s19000501n4hcu9habd	E5	28	2026-10-18 05:03:14.157	2026-10-18 05:03:14.157	Eerste verdieping lokaal nr 5
\.


--
-- Data for Name: student_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_comments (id, "studentId", "authorId", body, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: student_donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_donations (id, "studentId", "academicYearId", "expectedAmount", category, note, "recordedById", "createdAt", "updatedAt") FROM stdin;
cmvk2e31y00ql10qoppzhz1q3	cmvk2e0f8005j10qop7xz3aez	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.425	2026-10-22 21:40:02.425
cmvk2e35c00qn10qo0jm4nml6	cmvk2e0fr005m10qoxk85a4gx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.544	2026-10-22 21:40:02.544
cmvk2e35n00qp10qo5hy7lv4v	cmvk2e0g3005p10qomvyxe6dj	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.555	2026-10-22 21:40:02.555
cmvk2e36400qr10qolrik61w8	cmvk2e0ge005s10qo7a1ppbs9	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.572	2026-10-22 21:40:02.572
cmvk2e36d00qs10qoz62mrlqt	cmvk2e0gp005v10qom1efo6sv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.581	2026-10-22 21:40:02.581
cmvk2e38400qu10qoqx9xzbii	cmvk2e0gz005y10qotwaklrmg	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.644	2026-10-22 21:40:02.644
cmvk2e38800qv10qojtjj1nr9	cmvk2e0h9006110qoy3bg7l30	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.648	2026-10-22 21:40:02.648
cmvk2e38a00qw10qo8x42cj6n	cmvk2e0hi006410qoeec2qw1j	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.65	2026-10-22 21:40:02.65
cmvk2e38l00qy10qo66uy31eh	cmvk2e0hu006710qokk2xy663	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.661	2026-10-22 21:40:02.661
cmvk2e38v00r010qos3t1j3ek	cmvk2e0id006a10qo4fp7ykud	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.671	2026-10-22 21:40:02.671
cmvk2e39000r210qoy7ynp11e	cmvk2e0io006d10qo3rpuu4jx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.676	2026-10-22 21:40:02.676
cmvk2e39600r410qoms4hcm1s	cmvk2e0iy006g10qop9g8g78n	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.682	2026-10-22 21:40:02.682
cmvk2e39c00r610qotaaxr23l	cmvk2e0j9006j10qooapareag	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.688	2026-10-22 21:40:02.688
cmvk2e39j00r810qosrnr0rj6	cmvk2e0jk006m10qo671j2ft1	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.695	2026-10-22 21:40:02.695
cmvk2e39l00r910qohwkn44to	cmvk2e0ju006p10qo8s1059sq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.697	2026-10-22 21:40:02.697
cmvk2e39o00ra10qoesu9pabn	cmvk2e0kd006s10qowzu5tucn	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.701	2026-10-22 21:40:02.701
cmvk2e39w00rc10qoye8lijwo	cmvk2e0ko006v10qocpipelf3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.708	2026-10-22 21:40:02.708
cmvk2e3a500re10qoa1i94iuz	cmvk2e0l2006y10qok6uxeupm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.717	2026-10-22 21:40:02.717
cmvk2e3ad00rg10qo637ijumr	cmvk2e0lf007110qox7244gt0	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.725	2026-10-22 21:40:02.725
cmvk2e3ao00ri10qoxnnqvu9l	cmvk2e0lo007410qophya3uil	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.736	2026-10-22 21:40:02.736
cmvk2e3bj00rk10qow275uv7g	cmvk2e0lw007710qotmosrlq5	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.767	2026-10-22 21:40:02.767
cmvk2e3by00rm10qo13f6l1d8	cmvk2e0m4007a10qotbwxc7eb	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.782	2026-10-22 21:40:02.782
cmvk2e3c800ro10qo1856fzm2	cmvk2e0md007d10qo9zsykd0a	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.792	2026-10-22 21:40:02.792
cmvk2e3ch00rq10qoiyi3f7ws	cmvk2e0mn007g10qogjizo77d	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.801	2026-10-22 21:40:02.801
cmvk2e3d500rs10qou7nw1n3x	cmvk2e0mx007j10qow4xt9f1o	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: DeelbetalinDeelbetalin	\N	2026-10-22 21:40:02.825	2026-10-22 21:40:02.825
cmvk2e3dm00ru10qooep6koez	cmvk2e0n7007m10qo74e8y9jm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.842	2026-10-22 21:40:02.842
cmvk2e3e800rw10qov70ubar7	cmvk2e0nk007p10qoaxw6gch4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.864	2026-10-22 21:40:02.864
cmvk2e3f900ry10qo9kuuh4k0	cmvk2e0nu007s10qo0xmaj30h	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.901	2026-10-22 21:40:02.901
cmvk2e3fm00s010qonto1xlqs	cmvk2e0o6007v10qoxdixzsrp	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.914	2026-10-22 21:40:02.914
cmvk2e3fz00s210qo1us4rhhh	cmvk2e0oi007y10qo7g8zg9md	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.927	2026-10-22 21:40:02.927
cmvk2e3g100s310qo790ut1kz	cmvk2e0oz008110qox0ws44dw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.93	2026-10-22 21:40:02.93
cmvk2e3g500s410qo2eqqxmxo	cmvk2e0pa008410qo4r0eavjw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.933	2026-10-22 21:40:02.933
cmvk2e3g800s510qoba5oh9mt	cmvk2e0pi008710qo1720qe77	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.936	2026-10-22 21:40:02.936
cmvk2e3ga00s610qo40oztg1b	cmvk2e0pt008a10qo5f82vua2	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.938	2026-10-22 21:40:02.938
cmvk2e3gd00s710qoo49q940m	cmvk2e0qh008d10qoanwe1tei	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.941	2026-10-22 21:40:02.941
cmvk2e3gj00s910qorkrnlggb	cmvk2e0qs008g10qo49tbyhpf	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.947	2026-10-22 21:40:02.947
cmvk2e3gq00sb10qo9vd9j5ww	cmvk2e0r6008j10qow2kjqodr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.954	2026-10-22 21:40:02.954
cmvk2e3gv00sd10qo3jplwpjm	cmvk2e0re008m10qoh4nxmdu8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:02.959	2026-10-22 21:40:02.959
cmvk2e3gy00se10qop4fphuuo	cmvk2e0rp008p10qohkq8qlhx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.962	2026-10-22 21:40:02.962
cmvk2e3h600sg10qo9p0iylgl	cmvk2e0rz008s10qojfdjm4m8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.97	2026-10-22 21:40:02.97
cmvk2e3hf00si10qo32vh1nky	cmvk2e0s5008v10qopeicutss	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.979	2026-10-22 21:40:02.979
cmvk2e3ho00sk10qokq8am7ha	cmvk2e0sg008y10qo3jv48tmq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.988	2026-10-22 21:40:02.988
cmvk2e3hx00sm10qodpoq1h3d	cmvk2e0sq009110qorf0zejq7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:02.997	2026-10-22 21:40:02.997
cmvk2e3i200so10qon7bmbvw3	cmvk2e0sy009410qo6gdrb9th	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.002	2026-10-22 21:40:03.002
cmvk2e3i600sq10qo6f55is9s	cmvk2e0t4009710qo6y5w6a8d	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.006	2026-10-22 21:40:03.006
cmvk2e3ij00ss10qozkattjna	cmvk2e0tc009a10qopmfmhk8v	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.019	2026-10-22 21:40:03.019
cmvk2e3iv00su10qoxbos3qqk	cmvk2e0tp009d10qotj9m8qof	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.031	2026-10-22 21:40:03.031
cmvk2e3ja00sw10qo4zes5vi4	cmvk2e0u4009g10qojvw6fzq2	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.046	2026-10-22 21:40:03.046
cmvk2e3jq00sy10qotso6icqr	cmvk2e0uf009j10qonmsrbolk	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.062	2026-10-22 21:40:03.062
cmvk2e3k300t010qoaarxibli	cmvk2e0ux009m10qompgb7v0d	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.075	2026-10-22 21:40:03.075
cmvk2e3k700t110qonkxc0sm6	cmvk2e0v8009p10qoxvtkgw0e	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.079	2026-10-22 21:40:03.079
cmvk2e3kj00t310qop460h2mh	cmvk2e0ve009s10qocx5lazvz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.091	2026-10-22 21:40:03.091
cmvk2e3ly00t510qo0f27rdom	cmvk2e0vk009v10qocx5xules	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.142	2026-10-22 21:40:03.142
cmvk2e3mg00t710qoet33t5vt	cmvk2e0vz00a010qoqk2qppbc	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.16	2026-10-22 21:40:03.16
cmvk2e3mu00t910qoszzitd3k	cmvk2e0w600a310qomk482mit	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.174	2026-10-22 21:40:03.174
cmvk2e3nr00ta10qoqto5b1lh	cmvk2e0we00a610qocxbkzyuy	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.207	2026-10-22 21:40:03.207
cmvk2e3ny00tc10qob296kzdy	cmvk2e0wm00a910qoj3lq7cib	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.214	2026-10-22 21:40:03.214
cmvk2e3oi00te10qoigz7e09b	cmvk2e0wt00ac10qo7vfmjd0a	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.234	2026-10-22 21:40:03.234
cmvk2e3ov00tg10qoic81zocv	cmvk2e0x200af10qogjjlyhze	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.247	2026-10-22 21:40:03.247
cmvk2e3qt00ti10qo81n6awta	cmvk2e0xb00ai10qokuc5bs2q	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.317	2026-10-22 21:40:03.317
cmvk2e3so00tk10qoc9fdvvxg	cmvk2e0xj00al10qovd7t53vj	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.384	2026-10-22 21:40:03.384
cmvk2e3t000tl10qonhmfl2l2	cmvk2e0xp00ao10qol3ssoyki	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.396	2026-10-22 21:40:03.396
cmvk2e3t300tm10qowr6qyqjd	cmvk2e0xw00ar10qo73ok5r4k	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.399	2026-10-22 21:40:03.399
cmvk2e3t600tn10qobhlcjud2	cmvk2e0y200au10qouns1kkb0	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.402	2026-10-22 21:40:03.402
cmvk2e3tc00tp10qoatj5jb24	cmvk2e0yb00ax10qopadd4f4c	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:03.408	2026-10-22 21:40:03.408
cmvk2e3ti00tq10qoca4ohdj0	cmvk2e0yj00b010qowwfl1nln	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.414	2026-10-22 21:40:03.414
cmvk2e3to00ts10qo0c9rm3jk	cmvk2e0ys00b310qomfp2y9kx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.42	2026-10-22 21:40:03.42
cmvk2e3tw00tu10qowk52yz2r	cmvk2e0z200b610qoz3wbt9k3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.428	2026-10-22 21:40:03.428
cmvk2e3u400tw10qotb5pypu8	cmvk2e0z900b910qorgtkuon9	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.436	2026-10-22 21:40:03.436
cmvk2e3u900ty10qo78sjwm7i	cmvk2e0ze00bc10qogbcciv39	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.441	2026-10-22 21:40:03.441
cmvk2e3ug00u010qo89bbzwuu	cmvk2e0zl00bf10qouw396q6q	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.448	2026-10-22 21:40:03.448
cmvk2e3uo00u210qou112srdg	cmvk2e0zr00bi10qofdc5fch4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.456	2026-10-22 21:40:03.456
cmvk2e3uu00u410qoe9ocfvl1	cmvk2e10200bl10qoxc22xsjq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.462	2026-10-22 21:40:03.462
cmvk2e3v000u610qou1x2cby7	cmvk2e10c00bo10qoclc4ctlx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.468	2026-10-22 21:40:03.468
cmvk2e3v500u810qovgo3hzqc	cmvk2e10m00br10qo701zsodd	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.473	2026-10-22 21:40:03.473
cmvk2e3vb00ua10qowusndlkk	cmvk2e10v00bu10qocjrna6gx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.479	2026-10-22 21:40:03.479
cmvk2e3vh00uc10qo8td7tjpv	cmvk2e11500bx10qoey8wmotp	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: onbekend	\N	2026-10-22 21:40:03.486	2026-10-22 21:40:03.486
cmvk2e3vp00ue10qol33vtobq	cmvk2e11d00c010qoryncqogm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.493	2026-10-22 21:40:03.493
cmvk2e3vx00ug10qoy5wccghp	cmvk2e11m00c310qoopdaoqx8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.501	2026-10-22 21:40:03.501
cmvk2e3w500ui10qowdd9xlbu	cmvk2e11s00c610qo5ocm5vo0	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.509	2026-10-22 21:40:03.509
cmvk2e3wm00uk10qomtuk7qfd	cmvk2e11y00c910qoplfuiyvr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.526	2026-10-22 21:40:03.526
cmvk2e3xb00um10qogf27ihmd	cmvk2e12800cc10qouya3fezi	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Deelbetaling	\N	2026-10-22 21:40:03.551	2026-10-22 21:40:03.551
cmvk2e3yh00uo10qo83s8kfvr	cmvk2e12e00cf10qosb0eh1aq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.593	2026-10-22 21:40:03.593
cmvk2e3yt00up10qo9vx0gba9	cmvk2e12q00ci10qoual19fsm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.605	2026-10-22 21:40:03.605
cmvk2e3z500ur10qoy7xpmche	cmvk2e12y00cl10qok0tp3x9k	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.617	2026-10-22 21:40:03.617
cmvk2e3zu00ut10qoeltmunp5	cmvk2e13600co10qofwnaqw2z	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.642	2026-10-22 21:40:03.642
cmvk2e40300uv10qolsm2uk51	cmvk2e13e00cr10qox5qbg0cz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.651	2026-10-22 21:40:03.651
cmvk2e40800uw10qo59w0ddo9	cmvk2e13l00cu10qoti1pe8e6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.656	2026-10-22 21:40:03.656
cmvk2e40c00ux10qo2urp4z7w	cmvk2e13w00cx10qo8dkntsp3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.66	2026-10-22 21:40:03.66
cmvk2e40n00uz10qoczqhw47y	cmvk2e14400d010qoperb2tqj	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.671	2026-10-22 21:40:03.671
cmvk2e40x00v110qo7qvoj3c5	cmvk2e14c00d310qoag2wsgyp	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.681	2026-10-22 21:40:03.681
cmvk2e41100v210qoilykw7aw	cmvk2e14k00d610qob0botcsz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.685	2026-10-22 21:40:03.685
cmvk2e41500v310qonppuuprv	cmvk2e14v00d910qojo53f9k3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.689	2026-10-22 21:40:03.689
cmvk2e41f00v510qoqc4ba11c	cmvk2e15700dc10qoiwgsj8f9	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.699	2026-10-22 21:40:03.699
cmvk2e41r00v710qo4u4hi74g	cmvk2e15e00df10qoad1n2rjx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.711	2026-10-22 21:40:03.711
cmvk2e41v00v810qo0971qbyk	cmvk2e15o00di10qo657spol2	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.715	2026-10-22 21:40:03.715
cmvk2e41z00v910qo335cl01y	cmvk2e16200dl10qobzwefbsi	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.719	2026-10-22 21:40:03.719
cmvk2e42200va10qoahh5t2tp	cmvk2e16700do10qoked9sudv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.722	2026-10-22 21:40:03.722
cmvk2e42800vc10qoovqk8epp	cmvk2e16h00dr10qotnvucg70	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.728	2026-10-22 21:40:03.728
cmvk2e42d00ve10qoj64jxfrg	cmvk2e16w00du10qoskeyh0lb	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.733	2026-10-22 21:40:03.733
cmvk2e42p00vg10qoedw8mdu9	cmvk2e17u00dx10qonhsbuina	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.745	2026-10-22 21:40:03.745
cmvk2e42t00vh10qoceg3yprh	cmvk2e18k00e010qokp92c4cf	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.749	2026-10-22 21:40:03.749
cmvk2e43500vj10qotl4s90cs	cmvk2e19600e310qoc9g43cye	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.761	2026-10-22 21:40:03.761
cmvk2e43i00vl10qo5r95n1wq	cmvk2e19m00e610qovhbftiyr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.774	2026-10-22 21:40:03.774
cmvk2e44100vn10qov6noihge	cmvk2e1af00e910qoj9m97yrh	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.793	2026-10-22 21:40:03.793
cmvk2e44b00vp10qov2gr0u9d	cmvk2e1c800ec10qofadi7fwm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.804	2026-10-22 21:40:03.804
cmvk2e44p00vr10qope6c3aje	cmvk2e1d700ef10qoj7lafdi6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.817	2026-10-22 21:40:03.817
cmvk2e44u00vs10qoz9ed7fzp	cmvk2e1dq00ei10qo1e12120n	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.822	2026-10-22 21:40:03.822
cmvk2e45400vt10qowg13hezh	cmvk2e1hr00el10qorft4v8hb	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.832	2026-10-22 21:40:03.832
cmvk2e45a00vv10qon7kxpq24	cmvk2e1i300eo10qoactgc813	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.838	2026-10-22 21:40:03.838
cmvk2e45g00vx10qohjy0l7r1	cmvk2e1ib00er10qo0dxjt8q4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.844	2026-10-22 21:40:03.844
cmvk2e45k00vz10qo21qodn95	cmvk2e1ii00eu10qouggo8ohv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.848	2026-10-22 21:40:03.848
cmvk2e45p00w110qot8jr7svj	cmvk2e1iq00ex10qolv7h3znf	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.853	2026-10-22 21:40:03.853
cmvk2e45y00w310qoekvwd3ui	cmvk2e1iw00f010qouldd0whw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.862	2026-10-22 21:40:03.862
cmvk2e46900w510qo4m3eibuv	cmvk2e1j300f310qokwlctw42	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.873	2026-10-22 21:40:03.873
cmvk2e46l00w710qo9vj2v48u	cmvk2e1j700f610qoqieb3sy7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.885	2026-10-22 21:40:03.885
cmvk2e46y00w810qove7xxz0o	cmvk2e1jb00f910qoxwwq9wec	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.898	2026-10-22 21:40:03.898
cmvk2e47l00wa10qo8uu7gz6z	cmvk2e1jf00fc10qodoqzhons	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.921	2026-10-22 21:40:03.921
cmvk2e47w00wc10qosbo2xpme	cmvk2e1jn00ff10qo6b20bk1d	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.932	2026-10-22 21:40:03.932
cmvk2e48500we10qonukgbcf3	cmvk2e1js00fi10qoblhlylqf	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.941	2026-10-22 21:40:03.941
cmvk2e48g00wg10qo0aoentjx	cmvk2e1k100fl10qohvdgqlc8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.952	2026-10-22 21:40:03.952
cmvk2e48u00wi10qo54pzsptw	cmvk2e1ku00fo10qodpfpq0ib	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.966	2026-10-22 21:40:03.966
cmvk2e49100wj10qoxtyix08z	cmvk2e1l900fr10qo6euq3n2l	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:03.973	2026-10-22 21:40:03.973
cmvk2e49700wk10qox4k4ka38	cmvk2e1lh00fu10qodi34nlo8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.979	2026-10-22 21:40:03.979
cmvk2e49n00wm10qoyae06khx	cmvk2e1ln00fx10qob4gtsuxb	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:03.995	2026-10-22 21:40:03.995
cmvk2e4a700wo10qog67fz00c	cmvk2e1lz00g010qor4spgnh3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.015	2026-10-22 21:40:04.015
cmvk2e4ar00wq10qowo6o5i1q	cmvk2e1m500g310qogosi93ht	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.035	2026-10-22 21:40:04.035
cmvk2e4b200ws10qovvcks98g	cmvk2e1mc00g610qokmrvsajm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.046	2026-10-22 21:40:04.046
cmvk2e4bg00wu10qo2fng3tac	cmvk2e1mh00g910qof9zdk9s0	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.06	2026-10-22 21:40:04.06
cmvk2e4c600ww10qotuiu1o74	cmvk2e1n100gc10qoy5htea82	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.086	2026-10-22 21:40:04.086
cmvk2e4ch00wy10qo8hucmoh9	cmvk2e1n800gf10qopkdmfra7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.097	2026-10-22 21:40:04.097
cmvk2e4cr00x010qozwjtsrau	cmvk2e1nj00gi10qo6ptkzrjw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.107	2026-10-22 21:40:04.107
cmvk2e4cv00x110qotdsuu6zq	cmvk2e1nq00gl10qok2h5e8h8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.111	2026-10-22 21:40:04.111
cmvk2e4cz00x210qomtot6mtu	cmvk2e1nz00go10qosv3meac4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.115	2026-10-22 21:40:04.115
cmvk2e4d500x310qo396v4rwt	cmvk2e1o600gr10qourhjh39x	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.121	2026-10-22 21:40:04.121
cmvk2e4dg00x510qoxnauxhzr	cmvk2e1oc00gu10qoce37z8sn	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.132	2026-10-22 21:40:04.132
cmvk2e4dr00x710qob2xi3je5	cmvk2e1oh00gx10qobcvz39da	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.143	2026-10-22 21:40:04.143
cmvk2e4dz00x910qok29ttnyt	cmvk2e1on00h010qoznju2wm0	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.151	2026-10-22 21:40:04.151
cmvk2e4eb00xb10qok3iagufh	cmvk2e1p000h310qoy77ot97c	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.163	2026-10-22 21:40:04.163
cmvk2e4em00xd10qoupvifk0j	cmvk2e1pb00h610qohomlnt99	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.174	2026-10-22 21:40:04.174
cmvk2e4ew00xf10qoqujqhcmm	cmvk2e1pn00h910qo26r9kzvv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.184	2026-10-22 21:40:04.184
cmvk2e4f400xh10qob997lsfq	cmvk2e1pv00hc10qo70s7eud4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.192	2026-10-22 21:40:04.192
cmvk2e4fj00xj10qob84qlnt4	cmvk2e1qc00hf10qolumdg9rh	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.207	2026-10-22 21:40:04.207
cmvk2e4ft00xl10qouktosb2u	cmvk2e1ql00hi10qomvtqdm69	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.217	2026-10-22 21:40:04.217
cmvk2e4g400xn10qo5xrhylok	cmvk2e1qu00hl10qol44lbi9l	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.228	2026-10-22 21:40:04.228
cmvk2e4gb00xp10qoopw56o3l	cmvk2e1r300ho10qoohbq1j9b	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.235	2026-10-22 21:40:04.235
cmvk2e4gz00xr10qooyiv9my1	cmvk2e1rl00hr10qoln6c107h	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.259	2026-10-22 21:40:04.259
cmvk2e4hb00xt10qot5u5r818	cmvk2e1s000hu10qovy3i6l19	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.271	2026-10-22 21:40:04.271
cmvk2e4hi00xv10qomhxrew40	cmvk2e1t400hx10qody17xdw5	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.278	2026-10-22 21:40:04.278
cmvk2e4hp00xx10qo036b2g10	cmvk2e1tk00i010qonijxikwe	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.285	2026-10-22 21:40:04.285
cmvk2e4iu00xz10qojvn0k3ca	cmvk2e1tz00i310qoo67eujha	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.326	2026-10-22 21:40:04.326
cmvk2e4j400y110qo1kgxcdfi	cmvk2e1ug00i610qo7n6jek1u	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.336	2026-10-22 21:40:04.336
cmvk2e4jh00y310qowwm1oczf	cmvk2e1ut00i910qocffcgu3k	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.349	2026-10-22 21:40:04.349
cmvk2e4jt00y510qolfsr48yi	cmvk2e1v700ic10qont684rtb	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.362	2026-10-22 21:40:04.362
cmvk2e4k300y710qoowg46as2	cmvk2e1vn00if10qoa5gn8yl7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.371	2026-10-22 21:40:04.371
cmvk2e4kf00y910qokocsyt42	cmvk2e1vx00ii10qoh5v4lhfn	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.383	2026-10-22 21:40:04.383
cmvk2e4kk00ya10qo5ba2uxrj	cmvk2e1w500il10qoq9493xwt	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.388	2026-10-22 21:40:04.388
cmvk2e4kn00yb10qoumcs711v	cmvk2e1wd00io10qool1z6725	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.391	2026-10-22 21:40:04.391
cmvk2e4kr00yc10qoz58o37b1	cmvk2e1wl00ir10qozqju3tjf	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.395	2026-10-22 21:40:04.395
cmvk2e4l000ye10qop4bfaelp	cmvk2e1wx00iu10qocetv78hy	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.404	2026-10-22 21:40:04.404
cmvk2e4l800yg10qoqnjzyzdo	cmvk2e1xx00ix10qo5qpio2jr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.412	2026-10-22 21:40:04.412
cmvk2e4lf00yi10qo3j8uriix	cmvk2e1ya00j010qocpb43z1p	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.419	2026-10-22 21:40:04.419
cmvk2e4lk00yk10qougpsiw5d	cmvk2e1yj00j310qo2h047zs8	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.424	2026-10-22 21:40:04.424
cmvk2e4ln00yl10qo6rwivv32	cmvk2e1yv00j610qo8qsw1g91	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.427	2026-10-22 21:40:04.427
cmvk2e4lt00yn10qo4hgfwvfw	cmvk2e1z300j910qoprojkzkj	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.433	2026-10-22 21:40:04.433
cmvk2e4m100yp10qozf478h3f	cmvk2e1zd00jc10qoekwj6a2m	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.442	2026-10-22 21:40:04.442
cmvk2e4m600yr10qo9xxv24m6	cmvk2e1zq00jf10qon2rqyrl1	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.446	2026-10-22 21:40:04.446
cmvk2e4ma00yt10qo3w00zng9	cmvk2e20200ji10qoprpn0uqy	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.45	2026-10-22 21:40:04.45
cmvk2e4mb00yu10qooeumwcxc	cmvk2e20e00jl10qow8e1yiow	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.451	2026-10-22 21:40:04.451
cmvk2e4md00yv10qoxms3jep1	cmvk2e20p00jo10qoxqql70bo	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.453	2026-10-22 21:40:04.453
cmvk2e4mi00yx10qo469jkqfg	cmvk2e20y00jr10qoh8pjk1e2	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.458	2026-10-22 21:40:04.458
cmvk2e4mm00yy10qozfqztqes	cmvk2e21700ju10qo6yrh8nn9	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.462	2026-10-22 21:40:04.462
cmvk2e4mp00yz10qormcmnuei	cmvk2e21i00jx10qo09v4vqf9	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.465	2026-10-22 21:40:04.465
cmvk2e4mt00z010qoib7o2y7x	cmvk2e21u00k010qooq70hbjl	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.469	2026-10-22 21:40:04.469
cmvk2e4mw00z110qokq2l817o	cmvk2e22300k310qoaweja2qk	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.472	2026-10-22 21:40:04.472
cmvk2e4my00z210qo7pbxyquq	cmvk2e22c00k610qoezyj455i	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.474	2026-10-22 21:40:04.474
cmvk2e4n100z310qoud0ywqst	cmvk2e22j00k910qobkyi27z6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.477	2026-10-22 21:40:04.477
cmvk2e4n200z410qoecc54iqe	cmvk2e22q00kc10qomrp1weci	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.478	2026-10-22 21:40:04.478
cmvk2e4n600z610qoz37bnsgz	cmvk2e23200kf10qo6q0e2tic	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.482	2026-10-22 21:40:04.482
cmvk2e4na00z810qonaa03gpz	cmvk2e23m00ki10qoulyqnae4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.486	2026-10-22 21:40:04.486
cmvk2e4nd00za10qog9kbz1lh	cmvk2e24100kl10qorjekwidz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.489	2026-10-22 21:40:04.489
cmvk2e4nk00zc10qoo4m5eh3c	cmvk2e24f00ko10qowjirabgu	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.496	2026-10-22 21:40:04.496
cmvk2e4np00ze10qoexkhng6t	cmvk2e24s00kr10qoea9lhkmq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.501	2026-10-22 21:40:04.501
cmvk2e4nr00zf10qom1pa52q8	cmvk2e25200ku10qofc0p978p	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.503	2026-10-22 21:40:04.503
cmvk2e4nx00zh10qom3sy5ude	cmvk2e25r00kx10qobmpq91u6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.509	2026-10-22 21:40:04.509
cmvk2e4o000zi10qolsxr8cwi	cmvk2e26400l010qoq73zmzm7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.512	2026-10-22 21:40:04.512
cmvk2e4o200zj10qowtxi8tcw	cmvk2e26d00l310qo5tfcm5iv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.514	2026-10-22 21:40:04.514
cmvk2e4o700zl10qo8kkz038p	cmvk2e26q00l610qonpxspp6x	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.519	2026-10-22 21:40:04.519
cmvk2e4o900zm10qo2ixqpnhe	cmvk2e27100l910qocx3ex4iz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.521	2026-10-22 21:40:04.521
cmvk2e4oc00zn10qoa24yjiuk	cmvk2e27h00lc10qo7gh0hsiq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.524	2026-10-22 21:40:04.524
cmvk2e4of00zo10qodp34j2z6	cmvk2e27w00lf10qom9p26wiz	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.527	2026-10-22 21:40:04.527
cmvk2e4on00zq10qobaxzwxbq	cmvk2e28200li10qovdat671z	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.535	2026-10-22 21:40:04.535
cmvk2e4ot00zs10qolzub9oge	cmvk2e28e00ll10qowlkawpgt	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.541	2026-10-22 21:40:04.541
cmvk2e4p100zu10qo9czx9dv3	cmvk2e28s00lo10qo7e2bp1o3	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.549	2026-10-22 21:40:04.549
cmvk2e4p400zv10qojrbt0cgq	cmvk2e29400lr10qocjdvc6b6	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.552	2026-10-22 21:40:04.552
cmvk2e4p700zw10qot3i3bslv	cmvk2e29b00lu10qog7rpgkcr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.555	2026-10-22 21:40:04.555
cmvk2e4pe00zy10qoqpascjcu	cmvk2e29m00lx10qo101embvd	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.562	2026-10-22 21:40:04.562
cmvk2e4pl010010qohp8rlml2	cmvk2e2ac00m010qo5ptppc5o	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.569	2026-10-22 21:40:04.569
cmvk2e4pu010210qoe8mwqvle	cmvk2e2bg00m310qo6pqqxpjl	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.578	2026-10-22 21:40:04.578
cmvk2e4qi010410qo5lwovwl0	cmvk2e2c200m610qoor5xfdo6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.602	2026-10-22 21:40:04.602
cmvk2e4qw010610qoe5mmtm0k	cmvk2e2cd00m910qon6uxqyar	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.616	2026-10-22 21:40:04.616
cmvk2e4qy010710qog2sdg0sa	cmvk2e2cr00mc10qobys4bvnw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.618	2026-10-22 21:40:04.618
cmvk2e4rd010910qoasehjw15	cmvk2e2d700mf10qoox604aky	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.633	2026-10-22 21:40:04.633
cmvk2e4rm010b10qost1xvbkw	cmvk2e2dk00mi10qob19yp1hd	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.642	2026-10-22 21:40:04.642
cmvk2e4rs010d10qoi0p9f9ro	cmvk2e2e600ml10qoxvm5sc2r	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.648	2026-10-22 21:40:04.648
cmvk2e4rv010f10qoxhnlhct5	cmvk2e2eg00mo10qokzbvud3z	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.651	2026-10-22 21:40:04.651
cmvk2e4s1010h10qoy5kg6h1z	cmvk2e2fa00mr10qok97kyvqg	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.657	2026-10-22 21:40:04.657
cmvk2e4sb010j10qox3ozko5e	cmvk2e2fr00mu10qohapjlfv8	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.667	2026-10-22 21:40:04.667
cmvk2e4sl010l10qooiafbwxn	cmvk2e2ga00mx10qoxq9y911o	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.677	2026-10-22 21:40:04.677
cmvk2e4t1010m10qoikh74pql	cmvk2e2gp00n010qop5winihn	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.693	2026-10-22 21:40:04.693
cmvk2e4t4010n10qoiru2lsqz	cmvk2e2h100n310qoxejneoi1	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.696	2026-10-22 21:40:04.696
cmvk2e4td010p10qox4kcx5kw	cmvk2e2he00n610qoqjycfgkw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.705	2026-10-22 21:40:04.705
cmvk2e4tj010q10qovz8pnqoj	cmvk2e2hs00n910qo4wyqhz7b	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.711	2026-10-22 21:40:04.711
cmvk2e4to010r10qovlvvmoa5	cmvk2e2i200nc10qoy0x32f8q	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.716	2026-10-22 21:40:04.716
cmvk2e4u1010t10qoh3tnhqhi	cmvk2e2ie00nf10qoz6ai0dmm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.729	2026-10-22 21:40:04.729
cmvk2e4u4010u10qodo1kyzmu	cmvk2e2iw00ni10qoywbqnai5	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.732	2026-10-22 21:40:04.732
cmvk2e4u7010v10qov2usoysp	cmvk2e2ja00nl10qoc5fvj7au	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.735	2026-10-22 21:40:04.735
cmvk2e4ue010x10qofxkqq1b4	cmvk2e2kl00no10qo92hh1f3b	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.742	2026-10-22 21:40:04.742
cmvk2e4uo010z10qo28n72yyk	cmvk2e2m000nr10qo7irsk46h	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.753	2026-10-22 21:40:04.753
cmvk2e4us011010qo65n6lszc	cmvk2e2mz00nu10qoahpq6en1	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.756	2026-10-22 21:40:04.756
cmvk2e4uw011110qolvcdzjpr	cmvk2e2nv00nx10qoicxjuufx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.76	2026-10-22 21:40:04.76
cmvk2e4uz011210qopkt60agw	cmvk2e2oa00o010qo3nqbcmwy	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.763	2026-10-22 21:40:04.763
cmvk2e4v4011410qo9cfu3zss	cmvk2e2ox00o310qo1fp7jf9k	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.768	2026-10-22 21:40:04.768
cmvk2e4v7011610qols95bqof	cmvk2e2pd00o610qodd2hmfys	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.771	2026-10-22 21:40:04.771
cmvk2e4v9011710qoyxbfdpg4	cmvk2e2pq00o910qo2730l4yw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.773	2026-10-22 21:40:04.773
cmvk2e4vd011810qoxj54259x	cmvk2e2q300oc10qot2xa2ayx	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.777	2026-10-22 21:40:04.777
cmvk2e4vh011a10qo395mlokp	cmvk2e2qi00of10qob9mtp95m	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.781	2026-10-22 21:40:04.781
cmvk2e4vk011b10qob8vo8jrd	cmvk2e2qv00oi10qotvkb5gwr	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.784	2026-10-22 21:40:04.784
cmvk2e4vm011c10qoq1ageqoi	cmvk2e2r400ol10qo3w3iir2x	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.786	2026-10-22 21:40:04.786
cmvk2e4vu011e10qob0qsk2kz	cmvk2e2rf00oo10qoel5fv9j7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Deelbetaling	\N	2026-10-22 21:40:04.794	2026-10-22 21:40:04.794
cmvk2e4w0011g10qoscqjm3n8	cmvk2e2rs00or10qogy8fva6b	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.8	2026-10-22 21:40:04.8
cmvk2e4w5011h10qoecna7479	cmvk2e2s900ou10qolb7uyr4q	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.805	2026-10-22 21:40:04.805
cmvk2e4w8011i10qozgknohl7	cmvk2e2so00ox10qorvrpc40u	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.808	2026-10-22 21:40:04.808
cmvk2e4wc011j10qody8xe1uu	cmvk2e2t200p010qo7ywriqdq	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.812	2026-10-22 21:40:04.812
cmvk2e4we011k10qo8q3w8qli	cmvk2e2tc00p310qoefmn8evv	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.814	2026-10-22 21:40:04.814
cmvk2e4wn011m10qom5ap3rv8	cmvk2e2ts00p610qosvzydygr	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.824	2026-10-22 21:40:04.824
cmvk2e4ws011n10qowjz53o15	cmvk2e2u300p910qoppseznc5	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.828	2026-10-22 21:40:04.828
cmvk2e4ww011o10qojzijp6kc	cmvk2e2ui00pc10qopcqo26em	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.832	2026-10-22 21:40:04.832
cmvk2e4wy011p10qo90cun8fl	cmvk2e2vc00pf10qo3t9lj3li	cmuhjm5hy00007g6di3jovxng	0.00	EXEMPT	Oud systeem — status: Regeling	\N	2026-10-22 21:40:04.834	2026-10-22 21:40:04.834
cmvk2e4x1011q10qoxnd2eqv4	cmvk2e2w500pi10qovwf8e6aw	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.837	2026-10-22 21:40:04.837
cmvk2e4x7011s10qo3vv00y7f	cmvk2e2wt00pl10qor4zldg40	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.843	2026-10-22 21:40:04.843
cmvk2e4xm011u10qouks1inch	cmvk2e2x500po10qomph1l3p6	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.858	2026-10-22 21:40:04.858
cmvk2e4xs011w10qoiq233edv	cmvk2e2xi00pr10qoyc5wzqn7	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.864	2026-10-22 21:40:04.864
cmvk2e4y0011y10qo17lpu6wx	cmvk2e2xw00pu10qofmc21wia	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.872	2026-10-22 21:40:04.872
cmvk2e4y6011z10qocpy8rdd0	cmvk2e2yc00px10qoh5przmtm	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.878	2026-10-22 21:40:04.878
cmvk2e4ye012110qorbm16x40	cmvk2e2yn00q010qonug7nlo4	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.886	2026-10-22 21:40:04.886
cmvk2e4yn012310qowsvkj5w3	cmvk2e2z200q310qobwzccw2u	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.895	2026-10-22 21:40:04.895
cmvk2e4yx012510qo8ahmz61e	cmvk2e2zb00q610qopmdhaaas	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.905	2026-10-22 21:40:04.905
cmvk2e4z2012710qon8ua1xkk	cmvk2e30100q910qo8yqwve66	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.91	2026-10-22 21:40:04.91
cmvk2e4z5012810qorhaxw62q	cmvk2e30f00qc10qozdumo62o	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.913	2026-10-22 21:40:04.913
cmvk2e4z8012910qob6u0p5v1	cmvk2e30p00qf10qo2i71tdoy	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: Voldaan	\N	2026-10-22 21:40:04.916	2026-10-22 21:40:04.916
cmvk2e4zb012b10qogy46y05b	cmvk2e31200qi10qo9hc0wu8y	cmuhjm5hy00007g6di3jovxng	115.00	FULL	Oud systeem — status: NB	\N	2026-10-22 21:40:04.919	2026-10-22 21:40:04.919
cmvk2e4zd012c10qogxenf5o1	cmvk2e0f8005j10qop7xz3aez	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.921	2026-10-22 21:40:04.921
cmvk2e4zg012d10qogcqkdwgf	cmvk2e0fr005m10qoxk85a4gx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.924	2026-10-22 21:40:04.924
cmvk2e4zi012e10qoyj8w7nh2	cmvk2e0g3005p10qomvyxe6dj	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.926	2026-10-22 21:40:04.926
cmvk2e4zm012f10qopo0z1pnx	cmvk2e0ge005s10qo7a1ppbs9	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.93	2026-10-22 21:40:04.93
cmvk2e4zq012g10qo5v7uaf6s	cmvk2e0gp005v10qom1efo6sv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.934	2026-10-22 21:40:04.934
cmvk2e4zs012h10qohiwxc3j8	cmvk2e0gz005y10qotwaklrmg	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.936	2026-10-22 21:40:04.936
cmvk2e4zv012i10qol3ey7zej	cmvk2e0h9006110qoy3bg7l30	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.939	2026-10-22 21:40:04.939
cmvk2e4zx012j10qougugddbb	cmvk2e0hi006410qoeec2qw1j	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.941	2026-10-22 21:40:04.941
cmvk2e4zz012k10qo2t08d4u4	cmvk2e0hu006710qokk2xy663	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.943	2026-10-22 21:40:04.943
cmvk2e501012l10qoz9nxcwsg	cmvk2e0id006a10qo4fp7ykud	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.945	2026-10-22 21:40:04.945
cmvk2e503012m10qonunr5sxv	cmvk2e0io006d10qo3rpuu4jx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.947	2026-10-22 21:40:04.947
cmvk2e506012n10qoifshmz4x	cmvk2e0iy006g10qop9g8g78n	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.95	2026-10-22 21:40:04.95
cmvk2e509012o10qofs1p92an	cmvk2e0j9006j10qooapareag	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.953	2026-10-22 21:40:04.953
cmvk2e50b012p10qooou1nmtd	cmvk2e0jk006m10qo671j2ft1	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.955	2026-10-22 21:40:04.955
cmvk2e50e012q10qokauka6k9	cmvk2e0ju006p10qo8s1059sq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.958	2026-10-22 21:40:04.958
cmvk2e50i012r10qowp388hgi	cmvk2e0kd006s10qowzu5tucn	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.962	2026-10-22 21:40:04.962
cmvk2e50l012s10qozu6l5hf9	cmvk2e0ko006v10qocpipelf3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.965	2026-10-22 21:40:04.965
cmvk2e50o012t10qopy500ocz	cmvk2e0l2006y10qok6uxeupm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.968	2026-10-22 21:40:04.968
cmvk2e50q012u10qoveit0udn	cmvk2e0lf007110qox7244gt0	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.97	2026-10-22 21:40:04.97
cmvk2e50t012v10qosx9tx3uk	cmvk2e0lo007410qophya3uil	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.973	2026-10-22 21:40:04.973
cmvk2e50v012w10qotbf5l3z4	cmvk2e0lw007710qotmosrlq5	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.975	2026-10-22 21:40:04.975
cmvk2e50y012x10qopjjjg2ch	cmvk2e0m4007a10qotbwxc7eb	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.979	2026-10-22 21:40:04.979
cmvk2e512012y10qov2t8swmc	cmvk2e0md007d10qo9zsykd0a	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.982	2026-10-22 21:40:04.982
cmvk2e515012z10qoa8qfrp97	cmvk2e0mn007g10qogjizo77d	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.985	2026-10-22 21:40:04.985
cmvk2e519013010qo37o8s6h1	cmvk2e0mx007j10qow4xt9f1o	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.989	2026-10-22 21:40:04.989
cmvk2e51c013110qo9asab1wt	cmvk2e0n7007m10qo74e8y9jm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.992	2026-10-22 21:40:04.992
cmvk2e51f013210qo2a0kfiyl	cmvk2e0nk007p10qoaxw6gch4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.995	2026-10-22 21:40:04.995
cmvk2e51i013310qoxbo5b8av	cmvk2e0nu007s10qo0xmaj30h	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:04.998	2026-10-22 21:40:04.998
cmvk2e51l013410qobdqiq3lw	cmvk2e0o6007v10qoxdixzsrp	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.001	2026-10-22 21:40:05.001
cmvk2e51n013510qobu8t9khk	cmvk2e0oi007y10qo7g8zg9md	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.003	2026-10-22 21:40:05.003
cmvk2e51p013610qo3ome9u0p	cmvk2e0oz008110qox0ws44dw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.005	2026-10-22 21:40:05.005
cmvk2e51q013710qo9ccygmm2	cmvk2e0pa008410qo4r0eavjw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.006	2026-10-22 21:40:05.006
cmvk2e51s013810qosfmki78e	cmvk2e0pi008710qo1720qe77	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.008	2026-10-22 21:40:05.008
cmvk2e51t013910qo7qm4bvgl	cmvk2e0pt008a10qo5f82vua2	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.009	2026-10-22 21:40:05.009
cmvk2e51v013a10qoy4q3yih4	cmvk2e0qh008d10qoanwe1tei	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.011	2026-10-22 21:40:05.011
cmvk2e51x013b10qo2vil66a7	cmvk2e0qs008g10qo49tbyhpf	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.013	2026-10-22 21:40:05.013
cmvk2e51z013c10qo24ln88pf	cmvk2e0r6008j10qow2kjqodr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.015	2026-10-22 21:40:05.015
cmvk2e521013d10qoel2w5mrh	cmvk2e0re008m10qoh4nxmdu8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.017	2026-10-22 21:40:05.017
cmvk2e523013e10qo846h6g8n	cmvk2e0rp008p10qohkq8qlhx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.019	2026-10-22 21:40:05.019
cmvk2e525013f10qofpq8thyp	cmvk2e0rz008s10qojfdjm4m8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.021	2026-10-22 21:40:05.021
cmvk2e527013g10qoyu8cqvsl	cmvk2e0s5008v10qopeicutss	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.023	2026-10-22 21:40:05.023
cmvk2e52a013h10qoshykpmc7	cmvk2e0sg008y10qo3jv48tmq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.026	2026-10-22 21:40:05.026
cmvk2e52e013i10qoe3m5lbue	cmvk2e0sq009110qorf0zejq7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.03	2026-10-22 21:40:05.03
cmvk2e52h013j10qo5lx8wbig	cmvk2e0sy009410qo6gdrb9th	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.033	2026-10-22 21:40:05.033
cmvk2e52k013k10qosy3smk4p	cmvk2e0t4009710qo6y5w6a8d	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.036	2026-10-22 21:40:05.036
cmvk2e52l013l10qoluh7acxc	cmvk2e0tc009a10qopmfmhk8v	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.037	2026-10-22 21:40:05.037
cmvk2e52n013m10qo1aqn5mow	cmvk2e0tp009d10qotj9m8qof	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.039	2026-10-22 21:40:05.039
cmvk2e52q013n10qo6ktr1oxe	cmvk2e0u4009g10qojvw6fzq2	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.042	2026-10-22 21:40:05.042
cmvk2e52s013o10qocnua3fd1	cmvk2e0uf009j10qonmsrbolk	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.044	2026-10-22 21:40:05.044
cmvk2e52v013p10qoclw01llu	cmvk2e0ux009m10qompgb7v0d	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.047	2026-10-22 21:40:05.047
cmvk2e533013q10qoz9q60gu4	cmvk2e0v8009p10qoxvtkgw0e	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.055	2026-10-22 21:40:05.055
cmvk2e535013r10qo3afoy09m	cmvk2e0ve009s10qocx5lazvz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.057	2026-10-22 21:40:05.057
cmvk2e538013s10qotc7a0rl8	cmvk2e0vk009v10qocx5xules	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.06	2026-10-22 21:40:05.06
cmvk2e53d013t10qojr29tjg2	cmvk2e0vz00a010qoqk2qppbc	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.065	2026-10-22 21:40:05.065
cmvk2e53g013u10qowncpqj8b	cmvk2e0w600a310qomk482mit	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.068	2026-10-22 21:40:05.068
cmvk2e53i013v10qogc9imrmq	cmvk2e0we00a610qocxbkzyuy	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.07	2026-10-22 21:40:05.07
cmvk2e53k013w10qolruabnjm	cmvk2e0wm00a910qoj3lq7cib	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.072	2026-10-22 21:40:05.072
cmvk2e53m013x10qoce4lt20m	cmvk2e0wt00ac10qo7vfmjd0a	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.074	2026-10-22 21:40:05.074
cmvk2e53o013y10qoo37vj7fu	cmvk2e0x200af10qogjjlyhze	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.076	2026-10-22 21:40:05.076
cmvk2e53q013z10qocb4g3qvz	cmvk2e0xb00ai10qokuc5bs2q	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.078	2026-10-22 21:40:05.078
cmvk2e53t014010qoqty8swty	cmvk2e0xj00al10qovd7t53vj	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.081	2026-10-22 21:40:05.081
cmvk2e53v014110qokn0yuhme	cmvk2e0xp00ao10qol3ssoyki	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.083	2026-10-22 21:40:05.083
cmvk2e53x014210qob5tulp9m	cmvk2e0xw00ar10qo73ok5r4k	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.085	2026-10-22 21:40:05.085
cmvk2e540014310qot6ebtavo	cmvk2e0y200au10qouns1kkb0	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.088	2026-10-22 21:40:05.088
cmvk2e545014410qol1pcf2yx	cmvk2e0yb00ax10qopadd4f4c	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.093	2026-10-22 21:40:05.093
cmvk2e549014510qo5cjblwsx	cmvk2e0yj00b010qowwfl1nln	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.097	2026-10-22 21:40:05.097
cmvk2e54b014610qotvbafx53	cmvk2e0ys00b310qomfp2y9kx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.099	2026-10-22 21:40:05.099
cmvk2e54c014710qopjq3s490	cmvk2e0z200b610qoz3wbt9k3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.1	2026-10-22 21:40:05.1
cmvk2e54e014810qowvwbh5cp	cmvk2e0z900b910qorgtkuon9	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.102	2026-10-22 21:40:05.102
cmvk2e54g014910qoeldfvfxs	cmvk2e0ze00bc10qogbcciv39	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.104	2026-10-22 21:40:05.104
cmvk2e54j014a10qoukav4aju	cmvk2e0zl00bf10qouw396q6q	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.107	2026-10-22 21:40:05.107
cmvk2e54l014b10qos9rm6su4	cmvk2e0zr00bi10qofdc5fch4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.109	2026-10-22 21:40:05.109
cmvk2e54m014c10qolx75rcfl	cmvk2e10200bl10qoxc22xsjq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.11	2026-10-22 21:40:05.11
cmvk2e54o014d10qofhd2gnfo	cmvk2e10c00bo10qoclc4ctlx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.112	2026-10-22 21:40:05.112
cmvk2e54p014e10qopssmzzq9	cmvk2e10m00br10qo701zsodd	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.113	2026-10-22 21:40:05.113
cmvk2e54q014f10qols50ghpi	cmvk2e10v00bu10qocjrna6gx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.114	2026-10-22 21:40:05.114
cmvk2e54s014g10qokkkw6ayu	cmvk2e11500bx10qoey8wmotp	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.116	2026-10-22 21:40:05.116
cmvk2e54t014h10qohv4mzg1x	cmvk2e11d00c010qoryncqogm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.117	2026-10-22 21:40:05.117
cmvk2e54v014i10qogdv4h9cv	cmvk2e11m00c310qoopdaoqx8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.119	2026-10-22 21:40:05.119
cmvk2e54w014j10qodt8dceka	cmvk2e11s00c610qo5ocm5vo0	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.12	2026-10-22 21:40:05.12
cmvk2e54y014k10qo4362dqs7	cmvk2e11y00c910qoplfuiyvr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.122	2026-10-22 21:40:05.122
cmvk2e54z014l10qo8chrow7t	cmvk2e12800cc10qouya3fezi	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.123	2026-10-22 21:40:05.123
cmvk2e550014m10qoolv0ldmo	cmvk2e12e00cf10qosb0eh1aq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.125	2026-10-22 21:40:05.125
cmvk2e553014n10qov9pcpjss	cmvk2e12q00ci10qoual19fsm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.127	2026-10-22 21:40:05.127
cmvk2e556014o10qoo4r709vq	cmvk2e12y00cl10qok0tp3x9k	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.13	2026-10-22 21:40:05.13
cmvk2e558014p10qo4rd1jyyq	cmvk2e13600co10qofwnaqw2z	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.132	2026-10-22 21:40:05.132
cmvk2e55b014q10qoonkrv6qh	cmvk2e13e00cr10qox5qbg0cz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.135	2026-10-22 21:40:05.135
cmvk2e55d014r10qogdnildn5	cmvk2e13l00cu10qoti1pe8e6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.137	2026-10-22 21:40:05.137
cmvk2e55f014s10qoe1kvg1lo	cmvk2e13w00cx10qo8dkntsp3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.139	2026-10-22 21:40:05.139
cmvk2e55i014t10qo4fyy496u	cmvk2e14400d010qoperb2tqj	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.142	2026-10-22 21:40:05.142
cmvk2e55k014u10qojqcwg69z	cmvk2e14c00d310qoag2wsgyp	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.144	2026-10-22 21:40:05.144
cmvk2e55n014v10qova1ayiks	cmvk2e14k00d610qob0botcsz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.147	2026-10-22 21:40:05.147
cmvk2e55p014w10qofy4q6vhb	cmvk2e14v00d910qojo53f9k3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.149	2026-10-22 21:40:05.149
cmvk2e55r014x10qouyjit5m3	cmvk2e15700dc10qoiwgsj8f9	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.151	2026-10-22 21:40:05.151
cmvk2e55t014y10qo9atafiiw	cmvk2e15e00df10qoad1n2rjx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.153	2026-10-22 21:40:05.153
cmvk2e55y014z10qoep69114o	cmvk2e15o00di10qo657spol2	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.158	2026-10-22 21:40:05.158
cmvk2e561015010qo19tsf5nr	cmvk2e16200dl10qobzwefbsi	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.161	2026-10-22 21:40:05.161
cmvk2e566015110qoncq1sjsv	cmvk2e16700do10qoked9sudv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.166	2026-10-22 21:40:05.166
cmvk2e568015210qofx072rc1	cmvk2e16h00dr10qotnvucg70	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.168	2026-10-22 21:40:05.168
cmvk2e56b015310qo1vw6qg8v	cmvk2e16w00du10qoskeyh0lb	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.171	2026-10-22 21:40:05.171
cmvk2e56d015410qorbbbpbrg	cmvk2e17u00dx10qonhsbuina	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.173	2026-10-22 21:40:05.173
cmvk2e56g015510qokuxxofc1	cmvk2e18k00e010qokp92c4cf	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.176	2026-10-22 21:40:05.176
cmvk2e56j015610qohjsftsg7	cmvk2e19600e310qoc9g43cye	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.179	2026-10-22 21:40:05.179
cmvk2e56l015710qoxmgs8r9r	cmvk2e19m00e610qovhbftiyr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.181	2026-10-22 21:40:05.181
cmvk2e56m015810qo0ptx3exl	cmvk2e1af00e910qoj9m97yrh	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.182	2026-10-22 21:40:05.182
cmvk2e56o015910qok6huzizx	cmvk2e1c800ec10qofadi7fwm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.184	2026-10-22 21:40:05.184
cmvk2e56q015a10qo57tszjo9	cmvk2e1d700ef10qoj7lafdi6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.186	2026-10-22 21:40:05.186
cmvk2e56r015b10qo882j4mfy	cmvk2e1dq00ei10qo1e12120n	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.188	2026-10-22 21:40:05.188
cmvk2e56t015c10qopzmwr8bu	cmvk2e1hr00el10qorft4v8hb	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.189	2026-10-22 21:40:05.189
cmvk2e56u015d10qoc8m0wwtn	cmvk2e1i300eo10qoactgc813	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.19	2026-10-22 21:40:05.19
cmvk2e56w015e10qoaak7e0e4	cmvk2e1ib00er10qo0dxjt8q4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.192	2026-10-22 21:40:05.192
cmvk2e56y015f10qowazrg7aa	cmvk2e1ii00eu10qouggo8ohv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.194	2026-10-22 21:40:05.194
cmvk2e570015g10qo1cbdf5mw	cmvk2e1iq00ex10qolv7h3znf	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.196	2026-10-22 21:40:05.196
cmvk2e574015h10qo9urndf7j	cmvk2e1iw00f010qouldd0whw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.2	2026-10-22 21:40:05.2
cmvk2e576015i10qo1inrjyey	cmvk2e1j300f310qokwlctw42	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.202	2026-10-22 21:40:05.202
cmvk2e578015j10qofxd7243y	cmvk2e1j700f610qoqieb3sy7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.205	2026-10-22 21:40:05.205
cmvk2e57b015k10qo2trh52x3	cmvk2e1jb00f910qoxwwq9wec	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.208	2026-10-22 21:40:05.208
cmvk2e57f015l10qob12h561g	cmvk2e1jf00fc10qodoqzhons	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.211	2026-10-22 21:40:05.211
cmvk2e57i015m10qoar4cssej	cmvk2e1jn00ff10qo6b20bk1d	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.214	2026-10-22 21:40:05.214
cmvk2e57n015n10qor9e9sv1r	cmvk2e1js00fi10qoblhlylqf	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.219	2026-10-22 21:40:05.219
cmvk2e57p015o10qo3ire6f0f	cmvk2e1k100fl10qohvdgqlc8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.221	2026-10-22 21:40:05.221
cmvk2e57r015p10qo5d12ogw2	cmvk2e1ku00fo10qodpfpq0ib	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.223	2026-10-22 21:40:05.223
cmvk2e57u015q10qowkq0ndlk	cmvk2e1l900fr10qo6euq3n2l	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.226	2026-10-22 21:40:05.226
cmvk2e57x015r10qokch4upjf	cmvk2e1lh00fu10qodi34nlo8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.229	2026-10-22 21:40:05.229
cmvk2e580015s10qottx2qhi1	cmvk2e1ln00fx10qob4gtsuxb	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.232	2026-10-22 21:40:05.232
cmvk2e584015t10qokswdrjju	cmvk2e1lz00g010qor4spgnh3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.237	2026-10-22 21:40:05.237
cmvk2e588015u10qonlbb6duc	cmvk2e1m500g310qogosi93ht	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.24	2026-10-22 21:40:05.24
cmvk2e58c015v10qo51pzajgq	cmvk2e1mc00g610qokmrvsajm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.244	2026-10-22 21:40:05.244
cmvk2e58e015w10qom07ltkvi	cmvk2e1mh00g910qof9zdk9s0	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.246	2026-10-22 21:40:05.246
cmvk2e58i015x10qoofa426kv	cmvk2e1n100gc10qoy5htea82	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.25	2026-10-22 21:40:05.25
cmvk2e58l015y10qodrb8dzdk	cmvk2e1n800gf10qopkdmfra7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.253	2026-10-22 21:40:05.253
cmvk2e58o015z10qov0r1peac	cmvk2e1nj00gi10qo6ptkzrjw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.257	2026-10-22 21:40:05.257
cmvk2e58r016010qoyt1zwjem	cmvk2e1nq00gl10qok2h5e8h8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.259	2026-10-22 21:40:05.259
cmvk2e58u016110qoucv7147t	cmvk2e1nz00go10qosv3meac4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.262	2026-10-22 21:40:05.262
cmvk2e58x016210qo2zcuhsxa	cmvk2e1o600gr10qourhjh39x	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.265	2026-10-22 21:40:05.265
cmvk2e592016310qotcnswk20	cmvk2e1oc00gu10qoce37z8sn	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.27	2026-10-22 21:40:05.27
cmvk2e595016410qovyswj0iw	cmvk2e1oh00gx10qobcvz39da	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.273	2026-10-22 21:40:05.273
cmvk2e598016510qon51cjwjn	cmvk2e1on00h010qoznju2wm0	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.276	2026-10-22 21:40:05.276
cmvk2e59b016610qom6z8qa1b	cmvk2e1p000h310qoy77ot97c	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.279	2026-10-22 21:40:05.279
cmvk2e59e016710qohw138cuv	cmvk2e1pb00h610qohomlnt99	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.282	2026-10-22 21:40:05.282
cmvk2e59g016810qohttrrhx3	cmvk2e1pn00h910qo26r9kzvv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.284	2026-10-22 21:40:05.284
cmvk2e59j016910qo3mpwx4vs	cmvk2e1pv00hc10qo70s7eud4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.287	2026-10-22 21:40:05.287
cmvk2e59p016a10qof9awyvqp	cmvk2e1qc00hf10qolumdg9rh	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.293	2026-10-22 21:40:05.293
cmvk2e59v016b10qoui3nr0zp	cmvk2e1ql00hi10qomvtqdm69	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.299	2026-10-22 21:40:05.299
cmvk2e59y016c10qo0bpf7c4y	cmvk2e1qu00hl10qol44lbi9l	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.302	2026-10-22 21:40:05.302
cmvk2e5a0016d10qoy11qyh16	cmvk2e1r300ho10qoohbq1j9b	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.304	2026-10-22 21:40:05.304
cmvk2e5a3016e10qoynhn8qgf	cmvk2e1rl00hr10qoln6c107h	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.307	2026-10-22 21:40:05.307
cmvk2e5a6016f10qoy5acoly0	cmvk2e1s000hu10qovy3i6l19	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.31	2026-10-22 21:40:05.31
cmvk2e5a8016g10qo4w57ftvo	cmvk2e1t400hx10qody17xdw5	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.312	2026-10-22 21:40:05.312
cmvk2e5ab016h10qohy58tyq3	cmvk2e1tk00i010qonijxikwe	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.315	2026-10-22 21:40:05.315
cmvk2e5al016i10qozfd3zykr	cmvk2e1tz00i310qoo67eujha	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.325	2026-10-22 21:40:05.325
cmvk2e5b2016j10qo9kt285cw	cmvk2e1ug00i610qo7n6jek1u	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.342	2026-10-22 21:40:05.342
cmvk2e5b7016k10qochepe68v	cmvk2e1ut00i910qocffcgu3k	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.347	2026-10-22 21:40:05.347
cmvk2e5bc016l10qouwegd7pa	cmvk2e1v700ic10qont684rtb	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.352	2026-10-22 21:40:05.352
cmvk2e5bf016m10qo126kltey	cmvk2e1vn00if10qoa5gn8yl7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.355	2026-10-22 21:40:05.355
cmvk2e5bj016n10qoejgww1b9	cmvk2e1vx00ii10qoh5v4lhfn	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.359	2026-10-22 21:40:05.359
cmvk2e5bn016o10qo4q188ej9	cmvk2e1w500il10qoq9493xwt	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.363	2026-10-22 21:40:05.363
cmvk2e5bs016p10qoyqsnd1pt	cmvk2e1wd00io10qool1z6725	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.368	2026-10-22 21:40:05.368
cmvk2e5bw016q10qoa7mg6mrn	cmvk2e1wl00ir10qozqju3tjf	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.372	2026-10-22 21:40:05.372
cmvk2e5c1016r10qokpsc83in	cmvk2e1wx00iu10qocetv78hy	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.377	2026-10-22 21:40:05.377
cmvk2e5c4016s10qoocga7m2h	cmvk2e1xx00ix10qo5qpio2jr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.381	2026-10-22 21:40:05.381
cmvk2e5c8016t10qonzwij1rf	cmvk2e1ya00j010qocpb43z1p	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.384	2026-10-22 21:40:05.384
cmvk2e5cb016u10qorsurqu6n	cmvk2e1yj00j310qo2h047zs8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.387	2026-10-22 21:40:05.387
cmvk2e5ce016v10qoct3bn5m9	cmvk2e1yv00j610qo8qsw1g91	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.39	2026-10-22 21:40:05.39
cmvk2e5ci016w10qolctkk35x	cmvk2e1z300j910qoprojkzkj	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.394	2026-10-22 21:40:05.394
cmvk2e5ck016x10qokp2p3frx	cmvk2e1zd00jc10qoekwj6a2m	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.396	2026-10-22 21:40:05.396
cmvk2e5co016y10qog0bih1d0	cmvk2e1zq00jf10qon2rqyrl1	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.4	2026-10-22 21:40:05.4
cmvk2e5cr016z10qo4ylfmwlh	cmvk2e20200ji10qoprpn0uqy	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.403	2026-10-22 21:40:05.403
cmvk2e5cv017010qotfc7lu05	cmvk2e20e00jl10qow8e1yiow	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.407	2026-10-22 21:40:05.407
cmvk2e5d3017110qowp6dhbhz	cmvk2e20p00jo10qoxqql70bo	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.415	2026-10-22 21:40:05.415
cmvk2e5d6017210qo3ujhp8ak	cmvk2e20y00jr10qoh8pjk1e2	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.418	2026-10-22 21:40:05.418
cmvk2e5d9017310qoi0b37qnq	cmvk2e21700ju10qo6yrh8nn9	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.421	2026-10-22 21:40:05.421
cmvk2e5dc017410qo4kh3ren7	cmvk2e21i00jx10qo09v4vqf9	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.424	2026-10-22 21:40:05.424
cmvk2e5de017510qogrp3f5pf	cmvk2e21u00k010qooq70hbjl	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.426	2026-10-22 21:40:05.426
cmvk2e5df017610qos6d18ta5	cmvk2e22300k310qoaweja2qk	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.427	2026-10-22 21:40:05.427
cmvk2e5dg017710qomzn20ud5	cmvk2e22c00k610qoezyj455i	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.428	2026-10-22 21:40:05.428
cmvk2e5dh017810qo7jil086x	cmvk2e22j00k910qobkyi27z6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.429	2026-10-22 21:40:05.429
cmvk2e5di017910qoheummw2l	cmvk2e22q00kc10qomrp1weci	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.43	2026-10-22 21:40:05.43
cmvk2e5dl017a10qow6s95dro	cmvk2e23200kf10qo6q0e2tic	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.433	2026-10-22 21:40:05.433
cmvk2e5do017b10qoc7yozb3u	cmvk2e23m00ki10qoulyqnae4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.436	2026-10-22 21:40:05.436
cmvk2e5dq017c10qoai7xirz0	cmvk2e24100kl10qorjekwidz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.438	2026-10-22 21:40:05.438
cmvk2e5ds017d10qoiehs1ans	cmvk2e24f00ko10qowjirabgu	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.44	2026-10-22 21:40:05.44
cmvk2e5dt017e10qohb4qkqbn	cmvk2e24s00kr10qoea9lhkmq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.441	2026-10-22 21:40:05.441
cmvk2e5dv017f10qooy9qfu7f	cmvk2e25200ku10qofc0p978p	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.443	2026-10-22 21:40:05.443
cmvk2e5dx017g10qopotionc1	cmvk2e25r00kx10qobmpq91u6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.445	2026-10-22 21:40:05.445
cmvk2e5dz017h10qo8p2ty3tl	cmvk2e26400l010qoq73zmzm7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.447	2026-10-22 21:40:05.447
cmvk2e5e3017i10qotrigka0l	cmvk2e26d00l310qo5tfcm5iv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.451	2026-10-22 21:40:05.451
cmvk2e5e6017j10qosqvriwxn	cmvk2e26q00l610qonpxspp6x	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.454	2026-10-22 21:40:05.454
cmvk2e5e9017k10qo0kktpat2	cmvk2e27100l910qocx3ex4iz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.457	2026-10-22 21:40:05.457
cmvk2e5eb017l10qoqjg7sbvu	cmvk2e27h00lc10qo7gh0hsiq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.459	2026-10-22 21:40:05.459
cmvk2e5ed017m10qo8vpkueaq	cmvk2e27w00lf10qom9p26wiz	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.461	2026-10-22 21:40:05.461
cmvk2e5ee017n10qobtiq4e0w	cmvk2e28200li10qovdat671z	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.462	2026-10-22 21:40:05.462
cmvk2e5ef017o10qorib16rcf	cmvk2e28e00ll10qowlkawpgt	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.463	2026-10-22 21:40:05.463
cmvk2e5ei017p10qoij8jo7m1	cmvk2e28s00lo10qo7e2bp1o3	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.466	2026-10-22 21:40:05.466
cmvk2e5el017q10qo9ab7566v	cmvk2e29400lr10qocjdvc6b6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.469	2026-10-22 21:40:05.469
cmvk2e5eo017r10qov37vhwow	cmvk2e29b00lu10qog7rpgkcr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.472	2026-10-22 21:40:05.472
cmvk2e5es017s10qos88twe3j	cmvk2e29m00lx10qo101embvd	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.476	2026-10-22 21:40:05.476
cmvk2e5ev017t10qoa5f69xbr	cmvk2e2ac00m010qo5ptppc5o	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.479	2026-10-22 21:40:05.479
cmvk2e5ey017u10qoo48f3a3f	cmvk2e2bg00m310qo6pqqxpjl	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.482	2026-10-22 21:40:05.482
cmvk2e5f1017v10qoxw8gfcqw	cmvk2e2c200m610qoor5xfdo6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.485	2026-10-22 21:40:05.485
cmvk2e5f4017w10qoeh91kakf	cmvk2e2cd00m910qon6uxqyar	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.488	2026-10-22 21:40:05.488
cmvk2e5f7017x10qoqtzan236	cmvk2e2cr00mc10qobys4bvnw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.491	2026-10-22 21:40:05.491
cmvk2e5fa017y10qobxeddm9d	cmvk2e2d700mf10qoox604aky	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.494	2026-10-22 21:40:05.494
cmvk2e5fc017z10qoh0iyxr4q	cmvk2e2dk00mi10qob19yp1hd	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.497	2026-10-22 21:40:05.497
cmvk2e5ff018010qomnn881n4	cmvk2e2e600ml10qoxvm5sc2r	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.499	2026-10-22 21:40:05.499
cmvk2e5fh018110qoxjw2ioz8	cmvk2e2eg00mo10qokzbvud3z	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.501	2026-10-22 21:40:05.501
cmvk2e5fj018210qoj7p1864t	cmvk2e2fa00mr10qok97kyvqg	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.503	2026-10-22 21:40:05.503
cmvk2e5fm018310qotgs4se3f	cmvk2e2fr00mu10qohapjlfv8	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.506	2026-10-22 21:40:05.506
cmvk2e5fo018410qobnqqucyu	cmvk2e2ga00mx10qoxq9y911o	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.508	2026-10-22 21:40:05.508
cmvk2e5fq018510qohq3tyzz6	cmvk2e2gp00n010qop5winihn	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.51	2026-10-22 21:40:05.51
cmvk2e5fs018610qoab0clamj	cmvk2e2h100n310qoxejneoi1	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.512	2026-10-22 21:40:05.512
cmvk2e5fu018710qoxlyay55y	cmvk2e2he00n610qoqjycfgkw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.514	2026-10-22 21:40:05.514
cmvk2e5fw018810qozkigxeem	cmvk2e2hs00n910qo4wyqhz7b	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.516	2026-10-22 21:40:05.516
cmvk2e5g1018910qo72awwynz	cmvk2e2i200nc10qoy0x32f8q	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.521	2026-10-22 21:40:05.521
cmvk2e5g3018a10qo0pi3vaj7	cmvk2e2ie00nf10qoz6ai0dmm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.523	2026-10-22 21:40:05.523
cmvk2e5g5018b10qomv5vdzcq	cmvk2e2iw00ni10qoywbqnai5	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.525	2026-10-22 21:40:05.525
cmvk2e5g9018c10qo40f5zkik	cmvk2e2ja00nl10qoc5fvj7au	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.529	2026-10-22 21:40:05.529
cmvk2e5gc018d10qon1rvb6nq	cmvk2e2kl00no10qo92hh1f3b	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.532	2026-10-22 21:40:05.532
cmvk2e5gf018e10qoxdi4m2nc	cmvk2e2m000nr10qo7irsk46h	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.535	2026-10-22 21:40:05.535
cmvk2e5gi018f10qoges6glb0	cmvk2e2mz00nu10qoahpq6en1	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.538	2026-10-22 21:40:05.538
cmvk2e5gl018g10qoerfp15fr	cmvk2e2nv00nx10qoicxjuufx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.541	2026-10-22 21:40:05.541
cmvk2e5gn018h10qor6mvrij1	cmvk2e2oa00o010qo3nqbcmwy	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.543	2026-10-22 21:40:05.543
cmvk2e5gp018i10qodm3m0ub8	cmvk2e2ox00o310qo1fp7jf9k	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.545	2026-10-22 21:40:05.545
cmvk2e5gr018j10qokmsuh4ve	cmvk2e2pd00o610qodd2hmfys	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.547	2026-10-22 21:40:05.547
cmvk2e5gs018k10qol7zg3ogp	cmvk2e2pq00o910qo2730l4yw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.548	2026-10-22 21:40:05.548
cmvk2e5gt018l10qoa14p998z	cmvk2e2q300oc10qot2xa2ayx	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.549	2026-10-22 21:40:05.549
cmvk2e5gw018m10qouxab4354	cmvk2e2qi00of10qob9mtp95m	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.552	2026-10-22 21:40:05.552
cmvk2e5gz018n10qom0b7nu36	cmvk2e2qv00oi10qotvkb5gwr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.555	2026-10-22 21:40:05.555
cmvk2e5h1018o10qoluxfsab2	cmvk2e2r400ol10qo3w3iir2x	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.557	2026-10-22 21:40:05.557
cmvk2e5h4018p10qo4x5lkui4	cmvk2e2rf00oo10qoel5fv9j7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.56	2026-10-22 21:40:05.56
cmvk2e5h7018q10qom2qyxxfq	cmvk2e2rs00or10qogy8fva6b	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.563	2026-10-22 21:40:05.563
cmvk2e5h9018r10qoezpak83j	cmvk2e2s900ou10qolb7uyr4q	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.565	2026-10-22 21:40:05.565
cmvk2e5hb018s10qoodgcy2l8	cmvk2e2so00ox10qorvrpc40u	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.567	2026-10-22 21:40:05.567
cmvk2e5hd018t10qofzkzt5t7	cmvk2e2t200p010qo7ywriqdq	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.569	2026-10-22 21:40:05.569
cmvk2e5hg018u10qo1my1w0pc	cmvk2e2tc00p310qoefmn8evv	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.572	2026-10-22 21:40:05.572
cmvk2e5hk018v10qocdwxwmb8	cmvk2e2ts00p610qosvzydygr	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.576	2026-10-22 21:40:05.576
cmvk2e5hm018w10qoa7xv78y9	cmvk2e2u300p910qoppseznc5	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.578	2026-10-22 21:40:05.578
cmvk2e5ho018x10qomgd7mbg8	cmvk2e2ui00pc10qopcqo26em	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.58	2026-10-22 21:40:05.58
cmvk2e5hp018y10qozii7ksop	cmvk2e2vc00pf10qo3t9lj3li	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.581	2026-10-22 21:40:05.581
cmvk2e5hr018z10qonplrrqv1	cmvk2e2w500pi10qovwf8e6aw	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.583	2026-10-22 21:40:05.583
cmvk2e5hs019010qopf2m61xy	cmvk2e2wt00pl10qor4zldg40	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.584	2026-10-22 21:40:05.584
cmvk2e5hu019110qo5kaalts2	cmvk2e2x500po10qomph1l3p6	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.586	2026-10-22 21:40:05.586
cmvk2e5hw019210qop4ef82rt	cmvk2e2xi00pr10qoyc5wzqn7	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.588	2026-10-22 21:40:05.588
cmvk2e5i4019310qogftkdob1	cmvk2e2xw00pu10qofmc21wia	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.596	2026-10-22 21:40:05.596
cmvk2e5i7019410qop0y10se8	cmvk2e2yc00px10qoh5przmtm	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.599	2026-10-22 21:40:05.599
cmvk2e5ia019510qo381b7wqw	cmvk2e2yn00q010qonug7nlo4	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.602	2026-10-22 21:40:05.602
cmvk2e5if019610qovw2g6yci	cmvk2e2z200q310qobwzccw2u	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.607	2026-10-22 21:40:05.607
cmvk2e5ip019710qogvdt3219	cmvk2e2zb00q610qopmdhaaas	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.617	2026-10-22 21:40:05.617
cmvk2e5iy019810qo847yt4z2	cmvk2e30100q910qo8yqwve66	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.626	2026-10-22 21:40:05.626
cmvk2e5j0019910qo3wjwjyne	cmvk2e30f00qc10qozdumo62o	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.628	2026-10-22 21:40:05.628
cmvk2e5j6019a10qoygqoq95a	cmvk2e30p00qf10qo2i71tdoy	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.634	2026-10-22 21:40:05.634
cmvk2e5j8019b10qo6fh8kk1s	cmvk2e31200qi10qo9hc0wu8y	cmuzz99nt000oe26divmsytcg	0.00	EXEMPT	Geen bijdrage in het oude systeem	\N	2026-10-22 21:40:05.636	2026-10-22 21:40:05.636
\.


--
-- Data for Name: student_guardians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_guardians (id, "studentId", "guardianId", relation, "createdAt", "updatedAt") FROM stdin;
cmvks0n1u000501qqfhbky8zu	cmvks0n1g000401qq3smpb93i	cmvk2dzty000i10qo9inta0h5	Vader	2026-10-23 09:37:25.156	2026-10-23 09:37:25.156
cmvks93uq000901qq8tcqimdh	cmvks93uf000801qq4m9mtqfd	cmvks47uk000601qqqi2zmoz7	Vader	2026-10-23 09:44:00.184	2026-10-23 09:44:00.184
cmvmdscnd002p01qq6yijunag	cmvmdscn6002o01qqgj8ki8g4	cmvmdnak7002m01qqprpivn3u	Vader	2026-10-24 12:34:36.162	2026-10-24 12:34:36.162
cmvk2e0ok007z10qov935pzsm	cmvk2e0oi007y10qo7g8zg9md	cmvk2dzta000910qo9l7zyikg	Vader	2026-10-22 21:39:59.346	2026-10-23 10:04:36.422
cmvk2e0fc005k10qoag0bgot7	cmvk2e0f8005j10qop7xz3aez	cmvk2dzse000210qoeo0r31ty	Vader	2026-10-22 21:39:59.012	2026-10-22 21:39:59.012
cmvk2e0ft005n10qo08le3xmp	cmvk2e0fr005m10qoxk85a4gx	cmvk2dzse000210qoeo0r31ty	Vader	2026-10-22 21:39:59.031	2026-10-22 21:39:59.031
cmvk2e0g6005q10qoozr0nod4	cmvk2e0g3005p10qomvyxe6dj	cmvk2dzse000210qoeo0r31ty	Vader	2026-10-22 21:39:59.043	2026-10-22 21:39:59.043
cmvk2e0gg005t10qojcokqe49	cmvk2e0ge005s10qo7a1ppbs9	cmvk2dzsl000310qolsw2wchn	Vader	2026-10-22 21:39:59.054	2026-10-22 21:39:59.054
cmvk2e0gr005w10qot6zz9c5d	cmvk2e0gp005v10qom1efo6sv	cmvk2dzsq000410qokmdshdul	Vader	2026-10-22 21:39:59.065	2026-10-22 21:39:59.065
cmvk2e0h1005z10qob8ff09dy	cmvk2e0gz005y10qotwaklrmg	cmvk2dzsv000510qob3n5s53v	Vader	2026-10-22 21:39:59.075	2026-10-22 21:39:59.075
cmvk2e0hb006210qoz3l9yqhr	cmvk2e0h9006110qoy3bg7l30	cmvk2dzt2000610qoyaeafvme	Vader	2026-10-22 21:39:59.085	2026-10-22 21:39:59.085
cmvk2e0hk006510qoqowdz7vz	cmvk2e0hi006410qoeec2qw1j	cmvk2dzt5000710qoin2ezimf	Vader	2026-10-22 21:39:59.094	2026-10-22 21:39:59.094
cmvk2e0hx006810qocbm4fg63	cmvk2e0hu006710qokk2xy663	cmvk2dzt5000710qoin2ezimf	Vader	2026-10-22 21:39:59.106	2026-10-22 21:39:59.106
cmvk2e0ig006b10qo7l83l7jb	cmvk2e0id006a10qo4fp7ykud	cmvk2dzt8000810qomgfmwlq2	Vader	2026-10-22 21:39:59.125	2026-10-22 21:39:59.125
cmvk2e0ir006e10qok6akc3do	cmvk2e0io006d10qo3rpuu4jx	cmvk2dzt8000810qomgfmwlq2	Vader	2026-10-22 21:39:59.136	2026-10-22 21:39:59.136
cmvk2e0j1006h10qod2hjnpdm	cmvk2e0iy006g10qop9g8g78n	cmvk2dzt8000810qomgfmwlq2	Vader	2026-10-22 21:39:59.146	2026-10-22 21:39:59.146
cmvk2e0jb006k10qo9ab9mnny	cmvk2e0j9006j10qooapareag	cmvk2e0by005710qowarm4ppg	Vader	2026-10-22 21:39:59.157	2026-10-22 21:39:59.157
cmvk2e0jn006n10qoswtgqnkn	cmvk2e0jk006m10qo671j2ft1	cmvk2dztc000a10qoudbz35ki	Vader	2026-10-22 21:39:59.168	2026-10-22 21:39:59.168
cmvk2e0jw006q10qodvlsein5	cmvk2e0ju006p10qo8s1059sq	cmvk2dzte000b10qo3h958bgw	Vader	2026-10-22 21:39:59.178	2026-10-22 21:39:59.178
cmvk2e0ke006t10qovsexufdz	cmvk2e0kd006s10qowzu5tucn	cmvk2dztg000c10qodngcphl0	Vader	2026-10-22 21:39:59.197	2026-10-22 21:39:59.197
cmvk2e0ks006w10qogpgbfyva	cmvk2e0ko006v10qocpipelf3	cmvk2dztg000c10qodngcphl0	Vader	2026-10-22 21:39:59.208	2026-10-22 21:39:59.208
cmvk2e0l5006z10qo4s9j91pk	cmvk2e0l2006y10qok6uxeupm	cmvk2dzti000d10qohcc9ghvt	Vader	2026-10-22 21:39:59.223	2026-10-22 21:39:59.223
cmvk2e0lh007210qofnqxw61h	cmvk2e0lf007110qox7244gt0	cmvk2dzti000d10qohcc9ghvt	Vader	2026-10-22 21:39:59.235	2026-10-22 21:39:59.235
cmvk2e0lq007510qot1i25fun	cmvk2e0lo007410qophya3uil	cmvk2dztl000e10qos19xdq22	Vader	2026-10-22 21:39:59.244	2026-10-22 21:39:59.244
cmvk2e0ly007810qofd0nehut	cmvk2e0lw007710qotmosrlq5	cmvk2dztl000e10qos19xdq22	Vader	2026-10-22 21:39:59.252	2026-10-22 21:39:59.252
cmvk2e0m6007b10qop9wbj70l	cmvk2e0m4007a10qotbwxc7eb	cmvk2dztp000f10qokb859eyq	Vader	2026-10-22 21:39:59.26	2026-10-22 21:39:59.26
cmvk2e0mf007e10qo9k9od486	cmvk2e0md007d10qo9zsykd0a	cmvk2dztp000f10qokb859eyq	Vader	2026-10-22 21:39:59.269	2026-10-22 21:39:59.269
cmvk2e0mq007h10qo4pbta66j	cmvk2e0mn007g10qogjizo77d	cmvk2dztp000f10qokb859eyq	Vader	2026-10-22 21:39:59.279	2026-10-22 21:39:59.279
cmvk2e0mz007k10qovuyfw0sc	cmvk2e0mx007j10qow4xt9f1o	cmvk2dztp000f10qokb859eyq	Vader	2026-10-22 21:39:59.289	2026-10-22 21:39:59.289
cmvk2e0n9007n10qon3i8c6wt	cmvk2e0n7007m10qo74e8y9jm	cmvk2dzts000g10qoqt52yrxa	Vader	2026-10-22 21:39:59.299	2026-10-22 21:39:59.299
cmvk2e0nm007q10qo4ubcuple	cmvk2e0nk007p10qoaxw6gch4	cmvk2dzts000g10qoqt52yrxa	Vader	2026-10-22 21:39:59.312	2026-10-22 21:39:59.312
cmvk2e0ny007t10qow66a52x6	cmvk2e0nu007s10qo0xmaj30h	cmvk2dztv000h10qo5z945znq	Vader	2026-10-22 21:39:59.323	2026-10-22 21:39:59.323
cmvk2e0o8007w10qow7g2o82s	cmvk2e0o6007v10qoxdixzsrp	cmvk2dztv000h10qo5z945znq	Vader	2026-10-22 21:39:59.334	2026-10-22 21:39:59.334
cmvk2e0p1008210qo06i2od6r	cmvk2e0oz008110qox0ws44dw	cmvk2dzu3000k10qo6uyf5mx8	Vader	2026-10-22 21:39:59.363	2026-10-22 21:39:59.363
cmvk2e0pb008510qo2vz7t287	cmvk2e0pa008410qo4r0eavjw	cmvk2dzu7000l10qo659rsm0i	Vader	2026-10-22 21:39:59.374	2026-10-22 21:39:59.374
cmvk2e0pl008810qo17uhhz50	cmvk2e0pi008710qo1720qe77	cmvk2dzu7000l10qo659rsm0i	Vader	2026-10-22 21:39:59.382	2026-10-22 21:39:59.382
cmvk2e0pw008b10qoipcbjxth	cmvk2e0pt008a10qo5f82vua2	cmvk2dzua000m10qoj7izfm97	Vader	2026-10-22 21:39:59.393	2026-10-22 21:39:59.393
cmvk2e0qj008e10qo3a01cjsb	cmvk2e0qh008d10qoanwe1tei	cmvk2dzuc000n10qoyabyh97f	Vader	2026-10-22 21:39:59.417	2026-10-22 21:39:59.417
cmvk2e0qw008h10qou89ynrui	cmvk2e0qs008g10qo49tbyhpf	cmvk2dzuc000n10qoyabyh97f	Vader	2026-10-22 21:39:59.428	2026-10-22 21:39:59.428
cmvk2e0r9008k10qo4x6itb8r	cmvk2e0r6008j10qow2kjqodr	cmvk2dzuf000o10qoss2znahr	Vader	2026-10-22 21:39:59.442	2026-10-22 21:39:59.442
cmvk2e0rh008n10qo42kv6x1e	cmvk2e0re008m10qoh4nxmdu8	cmvk2dzui000p10qog7wt4iuf	Vader	2026-10-22 21:39:59.45	2026-10-22 21:39:59.45
cmvk2e0rr008q10qobikdqnyi	cmvk2e0rp008p10qohkq8qlhx	cmvk2dzuk000q10qoc540bx1n	Vader	2026-10-22 21:39:59.461	2026-10-22 21:39:59.461
cmvk2e0s1008t10qopjnqxa8q	cmvk2e0rz008s10qojfdjm4m8	cmvk2dzuk000q10qoc540bx1n	Vader	2026-10-22 21:39:59.471	2026-10-22 21:39:59.471
cmvk2e0s8008w10qoiug27wlb	cmvk2e0s5008v10qopeicutss	cmvk2dzut000t10qo3ihr1dyf	Vader	2026-10-22 21:39:59.477	2026-10-22 21:39:59.477
cmvk2e0si008z10qo7t6ul0b6	cmvk2e0sg008y10qo3jv48tmq	cmvk2dzuv000u10qox9mcd4px	Vader	2026-10-22 21:39:59.488	2026-10-22 21:39:59.488
cmvk2e0ss009210qoyi5sp47a	cmvk2e0sq009110qorf0zejq7	cmvk2dzux000v10qo3uah8fbb	Vader	2026-10-22 21:39:59.498	2026-10-22 21:39:59.498
cmvk2e0sz009510qo3zqsxk2f	cmvk2e0sy009410qo6gdrb9th	cmvk2dzv0000w10qoejy823mp	Vader	2026-10-22 21:39:59.506	2026-10-22 21:39:59.506
cmvk2e0t5009810qowi3m6zvx	cmvk2e0t4009710qo6y5w6a8d	cmvk2dzv0000w10qoejy823mp	Vader	2026-10-22 21:39:59.512	2026-10-22 21:39:59.512
cmvk2e0te009b10qo45fs0bnz	cmvk2e0tc009a10qopmfmhk8v	cmvk2dzv0000w10qoejy823mp	Vader	2026-10-22 21:39:59.52	2026-10-22 21:39:59.52
cmvk2e0tr009e10qouqr2cs5e	cmvk2e0tp009d10qotj9m8qof	cmvk2dzv3000x10qowcjqlz1n	Vader	2026-10-22 21:39:59.533	2026-10-22 21:39:59.533
cmvk2e0u7009h10qof37k3zq2	cmvk2e0u4009g10qojvw6fzq2	cmvk2dzv5000y10qo04j9tune	Vader	2026-10-22 21:39:59.548	2026-10-22 21:39:59.548
cmvk2e0uh009k10qophvuh4py	cmvk2e0uf009j10qonmsrbolk	cmvk2dzv7000z10qohk9skbvs	Vader	2026-10-22 21:39:59.559	2026-10-22 21:39:59.559
cmvk2e0uz009n10qosfbzm4d0	cmvk2e0ux009m10qompgb7v0d	cmvk2dzv9001010qojo2zsy6i	Vader	2026-10-22 21:39:59.577	2026-10-22 21:39:59.577
cmvk2e0v9009q10qo7nclgw3k	cmvk2e0v8009p10qoxvtkgw0e	cmvk2dzvc001110qoxm0yzj0n	Vader	2026-10-22 21:39:59.588	2026-10-22 21:39:59.588
cmvk2e0vf009t10qo0blh7qvv	cmvk2e0ve009s10qocx5lazvz	cmvk2dzvc001110qoxm0yzj0n	Vader	2026-10-22 21:39:59.594	2026-10-22 21:39:59.594
cmvk2e0vl009w10qodyox6sqz	cmvk2e0vk009v10qocx5xules	cmvk2dzve001210qosrqrgvka	Vader	2026-10-22 21:39:59.6	2026-10-22 21:39:59.6
cmvk2e0w000a110qorfprvpas	cmvk2e0vz00a010qoqk2qppbc	cmvk2dzve001210qosrqrgvka	Vader	2026-10-22 21:39:59.615	2026-10-22 21:39:59.615
cmvk2e0w800a410qoehfojw4n	cmvk2e0w600a310qomk482mit	cmvk2dzvg001310qovvug1rof	Vader	2026-10-22 21:39:59.622	2026-10-22 21:39:59.622
cmvk2e0wg00a710qoh1kd52cs	cmvk2e0we00a610qocxbkzyuy	cmvk2dzvk001410qo120b15yu	Vader	2026-10-22 21:39:59.63	2026-10-22 21:39:59.63
cmvk2e0wn00aa10qo54ipajwe	cmvk2e0wm00a910qoj3lq7cib	cmvk2dzvk001410qo120b15yu	Vader	2026-10-22 21:39:59.638	2026-10-22 21:39:59.638
cmvk2e0wv00ad10qo3vv6tm8e	cmvk2e0wt00ac10qo7vfmjd0a	cmvk2dzvp001510qogqc27o0r	Vader	2026-10-22 21:39:59.645	2026-10-22 21:39:59.645
cmvk2e0x500ag10qo6fhnkcnb	cmvk2e0x200af10qogjjlyhze	cmvk2e0c4005810qoacv4wgeb	Vader	2026-10-22 21:39:59.654	2026-10-22 21:39:59.654
cmvk2e0xe00aj10qohi4on758	cmvk2e0xb00ai10qokuc5bs2q	cmvk2dzvv001710qo79z1meiv	Vader	2026-10-22 21:39:59.663	2026-10-22 21:39:59.663
cmvk2e0xl00am10qoforw61fk	cmvk2e0xj00al10qovd7t53vj	cmvk2dzvy001810qo2nzpyqyv	Vader	2026-10-22 21:39:59.671	2026-10-22 21:39:59.671
cmvk2e0xr00ap10qoe6ctkahk	cmvk2e0xp00ao10qol3ssoyki	cmvk2dzvy001810qo2nzpyqyv	Vader	2026-10-22 21:39:59.677	2026-10-22 21:39:59.677
cmvk2e0xy00as10qod3q6uvdy	cmvk2e0xw00ar10qo73ok5r4k	cmvk2dzvy001810qo2nzpyqyv	Vader	2026-10-22 21:39:59.684	2026-10-22 21:39:59.684
cmvk2e0y400av10qorwxg5dv4	cmvk2e0y200au10qouns1kkb0	cmvk2dzw0001910qob1ei1fx9	Vader	2026-10-22 21:39:59.69	2026-10-22 21:39:59.69
cmvk2e0yd00ay10qovpc6th6l	cmvk2e0yb00ax10qopadd4f4c	cmvk2dzw3001a10qowigj85mp	Vader	2026-10-22 21:39:59.699	2026-10-22 21:39:59.699
cmvk2e0yl00b110qouna92u0h	cmvk2e0yj00b010qowwfl1nln	cmvk2dzw6001b10qocyriouz6	Vader	2026-10-22 21:39:59.707	2026-10-22 21:39:59.707
cmvk2e0yu00b410qovart0fha	cmvk2e0ys00b310qomfp2y9kx	cmvk2dzw9001c10qo5ysgiqnt	Vader	2026-10-22 21:39:59.716	2026-10-22 21:39:59.716
cmvk2e0z400b710qom9ea4dkd	cmvk2e0z200b610qoz3wbt9k3	cmvk2dzwb001d10qolylk42fm	Vader	2026-10-22 21:39:59.726	2026-10-22 21:39:59.726
cmvk2e0z900ba10qoopq9c9j8	cmvk2e0z900b910qorgtkuon9	cmvk2dzwb001d10qolylk42fm	Vader	2026-10-22 21:39:59.733	2026-10-22 21:39:59.733
cmvk2e0zf00bd10qodi2qjc3i	cmvk2e0ze00bc10qogbcciv39	cmvk2e0c4005810qoacv4wgeb	Vader	2026-10-22 21:39:59.738	2026-10-22 21:39:59.738
cmvk2e0zm00bg10qojeoalrkb	cmvk2e0zl00bf10qouw396q6q	cmvk2dzwg001f10qotb5nujr8	Vader	2026-10-22 21:39:59.745	2026-10-22 21:39:59.745
cmvk2e0zv00bj10qoov0kclkn	cmvk2e0zr00bi10qofdc5fch4	cmvk2dzwg001f10qotb5nujr8	Vader	2026-10-22 21:39:59.751	2026-10-22 21:39:59.751
cmvk2e10500bm10qodjbojar0	cmvk2e10200bl10qoxc22xsjq	cmvk2dzwg001f10qotb5nujr8	Vader	2026-10-22 21:39:59.763	2026-10-22 21:39:59.763
cmvk2e10e00bp10qowwqevn9i	cmvk2e10c00bo10qoclc4ctlx	cmvk2e0c4005810qoacv4wgeb	Vader	2026-10-22 21:39:59.772	2026-10-22 21:39:59.772
cmvk2e10o00bs10qobyaz5ujk	cmvk2e10m00br10qo701zsodd	cmvk2dzwl001h10qocswi8271	Vader	2026-10-22 21:39:59.782	2026-10-22 21:39:59.782
cmvk2e10x00bv10qomd47mmwl	cmvk2e10v00bu10qocjrna6gx	cmvk2dzwl001h10qocswi8271	Vader	2026-10-22 21:39:59.791	2026-10-22 21:39:59.791
cmvk2e11600by10qoz0m9masu	cmvk2e11500bx10qoey8wmotp	cmvk2dzwl001h10qocswi8271	Vader	2026-10-22 21:39:59.801	2026-10-22 21:39:59.801
cmvk2e11f00c110qogwa2e0a0	cmvk2e11d00c010qoryncqogm	cmvk2dzwn001i10qoydgblakh	Vader	2026-10-22 21:39:59.809	2026-10-22 21:39:59.809
cmvk2e11o00c410qotuntmwm5	cmvk2e11m00c310qoopdaoqx8	cmvk2dzwq001j10qofdphn643	Vader	2026-10-22 21:39:59.818	2026-10-22 21:39:59.818
cmvk2e11t00c710qoum41myn2	cmvk2e11s00c610qo5ocm5vo0	cmvk2dzwq001j10qofdphn643	Vader	2026-10-22 21:39:59.824	2026-10-22 21:39:59.824
cmvk2e12200ca10qoktuig7c6	cmvk2e11y00c910qoplfuiyvr	cmvk2dzws001k10qoq7z4kfpa	Vader	2026-10-22 21:39:59.83	2026-10-22 21:39:59.83
cmvk2e12900cd10qo1inuhg4c	cmvk2e12800cc10qouya3fezi	cmvk2dzwv001l10qo8pb898u6	Vader	2026-10-22 21:39:59.84	2026-10-22 21:39:59.84
cmvk2e12i00cg10qozmyjxv9f	cmvk2e12e00cf10qosb0eh1aq	cmvk2dzwv001l10qo8pb898u6	Vader	2026-10-22 21:39:59.846	2026-10-22 21:39:59.846
cmvk2e12r00cj10qo0drdxkke	cmvk2e12q00ci10qoual19fsm	cmvk2dzwx001m10qo4oqkuxjr	Vader	2026-10-22 21:39:59.858	2026-10-22 21:39:59.858
cmvk2e13000cm10qob9ulyezz	cmvk2e12y00cl10qok0tp3x9k	cmvk2dzwx001m10qo4oqkuxjr	Vader	2026-10-22 21:39:59.866	2026-10-22 21:39:59.866
cmvk2e13800cp10qoz522hnts	cmvk2e13600co10qofwnaqw2z	cmvk2dzwz001n10qov3gpso48	Vader	2026-10-22 21:39:59.874	2026-10-22 21:39:59.874
cmvk2e13g00cs10qok933l27k	cmvk2e13e00cr10qox5qbg0cz	cmvk2dzx1001o10qo4p30kxbh	Vader	2026-10-22 21:39:59.882	2026-10-22 21:39:59.882
cmvk2e13o00cv10qo941d6fq7	cmvk2e13l00cu10qoti1pe8e6	cmvk2dzx1001o10qo4p30kxbh	Vader	2026-10-22 21:39:59.89	2026-10-22 21:39:59.89
cmvk2e13y00cy10qourslgqjz	cmvk2e13w00cx10qo8dkntsp3	cmvk2dzx3001p10qop5lezwp5	Vader	2026-10-22 21:39:59.9	2026-10-22 21:39:59.9
cmvk2e14500d110qolgep5p70	cmvk2e14400d010qoperb2tqj	cmvk2dzx5001q10qotybjg1o3	Vader	2026-10-22 21:39:59.908	2026-10-22 21:39:59.908
cmvk2e14e00d410qocwx98oqu	cmvk2e14c00d310qoag2wsgyp	cmvk2dzxa001s10qozpodcwpv	Vader	2026-10-22 21:39:59.916	2026-10-22 21:39:59.916
cmvk2e14l00d710qoq1tl50ry	cmvk2e14k00d610qob0botcsz	cmvk2dzxd001t10qopewcvdp0	Vader	2026-10-22 21:39:59.924	2026-10-22 21:39:59.924
cmvk2e14y00da10qo9gu0ifw2	cmvk2e14v00d910qojo53f9k3	cmvk2e0bm005510qoyn47kyzb	Vader	2026-10-22 21:39:59.935	2026-10-22 21:39:59.935
cmvk2e15800dd10qovnmtcjpc	cmvk2e15700dc10qoiwgsj8f9	cmvk2e0bm005510qoyn47kyzb	Vader	2026-10-22 21:39:59.947	2026-10-22 21:39:59.947
cmvk2e15g00dg10qo7r8ptwva	cmvk2e15e00df10qoad1n2rjx	cmvk2dzxg001u10qo272xz2kk	Vader	2026-10-22 21:39:59.955	2026-10-22 21:39:59.955
cmvk2e15p00dj10qotdbgu0tn	cmvk2e15o00di10qo657spol2	cmvk2dzxg001u10qo272xz2kk	Vader	2026-10-22 21:39:59.964	2026-10-22 21:39:59.964
cmvk2e16300dm10qou3vl2fsc	cmvk2e16200dl10qobzwefbsi	cmvk2dzxg001u10qo272xz2kk	Vader	2026-10-22 21:39:59.978	2026-10-22 21:39:59.978
cmvk2e16900dp10qo4rxkt79y	cmvk2e16700do10qoked9sudv	cmvk2dzxi001v10qour53x00t	Vader	2026-10-22 21:39:59.983	2026-10-22 21:39:59.983
cmvk2e16j00ds10qosfwsxto0	cmvk2e16h00dr10qotnvucg70	cmvk2dzxi001v10qour53x00t	Vader	2026-10-22 21:39:59.993	2026-10-22 21:39:59.993
cmvk2e17400dv10qo5xgmuwmp	cmvk2e16w00du10qoskeyh0lb	cmvk2dzxl001w10qoobn99zra	Vader	2026-10-22 21:40:00.008	2026-10-22 21:40:00.008
cmvk2e17x00dy10qozo2hhw42	cmvk2e17u00dx10qonhsbuina	cmvk2dzxr001y10qoeb29pm3u	Vader	2026-10-22 21:40:00.042	2026-10-22 21:40:00.042
cmvk2e18u00e110qoo4py009i	cmvk2e18k00e010qokp92c4cf	cmvk2dzxu001z10qo5h8sito1	Vader	2026-10-22 21:40:00.068	2026-10-22 21:40:00.068
cmvk2e19900e410qohvuq4k1n	cmvk2e19600e310qoc9g43cye	cmvk2dzxu001z10qo5h8sito1	Vader	2026-10-22 21:40:00.09	2026-10-22 21:40:00.09
cmvk2e19o00e710qon71hiozz	cmvk2e19m00e610qovhbftiyr	cmvk2dzxw002010qo7w4lyzfg	Vader	2026-10-22 21:40:00.106	2026-10-22 21:40:00.106
cmvk2e1aq00ea10qo6pkc00le	cmvk2e1af00e910qoj9m97yrh	cmvk2dzxw002010qo7w4lyzfg	Vader	2026-10-22 21:40:00.135	2026-10-22 21:40:00.135
cmvk2e1cf00ed10qo3gdvn7z5	cmvk2e1c800ec10qofadi7fwm	cmvk2dzxw002010qo7w4lyzfg	Vader	2026-10-22 21:40:00.2	2026-10-22 21:40:00.2
cmvk2e1db00eg10qo6t1fpeo9	cmvk2e1d700ef10qoj7lafdi6	cmvk2dzxz002110qov9gtndoa	Vader	2026-10-22 21:40:00.235	2026-10-22 21:40:00.235
cmvk2e1ds00ej10qos4g7popw	cmvk2e1dq00ei10qo1e12120n	cmvk2dzxz002110qov9gtndoa	Vader	2026-10-22 21:40:00.254	2026-10-22 21:40:00.254
cmvk2e1ht00em10qou2t22y01	cmvk2e1hr00el10qorft4v8hb	cmvk2dzy1002210qo4hyr3nht	Vader	2026-10-22 21:40:00.399	2026-10-22 21:40:00.399
cmvk2e1i400ep10qo0y08wnqe	cmvk2e1i300eo10qoactgc813	cmvk2dzy9002410qogrc2xyq3	Vader	2026-10-22 21:40:00.411	2026-10-22 21:40:00.411
cmvk2e1ic00es10qo962ldowl	cmvk2e1ib00er10qo0dxjt8q4	cmvk2dzy9002410qogrc2xyq3	Vader	2026-10-22 21:40:00.419	2026-10-22 21:40:00.419
cmvk2e1ij00ev10qoli0sib8i	cmvk2e1ii00eu10qouggo8ohv	cmvk2dzyb002510qofy5dr6tt	Vader	2026-10-22 21:40:00.426	2026-10-22 21:40:00.426
cmvk2e1iq00ey10qo1wdfgl2u	cmvk2e1iq00ex10qolv7h3znf	cmvk2dzye002610qo0eq0lsz9	Vader	2026-10-22 21:40:00.434	2026-10-22 21:40:00.434
cmvk2e1ix00f110qond21z3p8	cmvk2e1iw00f010qouldd0whw	cmvk2dzyi002810qoi6bcy6d2	Vader	2026-10-22 21:40:00.44	2026-10-22 21:40:00.44
cmvk2e1j400f410qot6l6vc3g	cmvk2e1j300f310qokwlctw42	cmvk2dzyi002810qoi6bcy6d2	Vader	2026-10-22 21:40:00.447	2026-10-22 21:40:00.447
cmvk2e1j800f710qowynzduf6	cmvk2e1j700f610qoqieb3sy7	cmvk2dzyl002910qoys4w9gze	Vader	2026-10-22 21:40:00.451	2026-10-22 21:40:00.451
cmvk2e1jc00fa10qounpc33gk	cmvk2e1jb00f910qoxwwq9wec	cmvk2dzyq002a10qoebimwdak	Vader	2026-10-22 21:40:00.455	2026-10-22 21:40:00.455
cmvk2e1jj00fd10qot7njbc1y	cmvk2e1jf00fc10qodoqzhons	cmvk2dzyu002b10qofmjm4adf	Vader	2026-10-22 21:40:00.459	2026-10-22 21:40:00.459
cmvk2e1jo00fg10qo9v0fpbie	cmvk2e1jn00ff10qo6b20bk1d	cmvk2dzz0002d10qofn32e4e1	Vader	2026-10-22 21:40:00.467	2026-10-22 21:40:00.467
cmvk2e1jt00fj10qok8hs4cip	cmvk2e1js00fi10qoblhlylqf	cmvk2dzz0002d10qofn32e4e1	Vader	2026-10-22 21:40:00.472	2026-10-22 21:40:00.472
cmvk2e1kj00fm10qocqyh77y1	cmvk2e1k100fl10qohvdgqlc8	cmvk2dzz2002e10qo12ibofwy	Vader	2026-10-22 21:40:00.481	2026-10-22 21:40:00.481
cmvk2e1ky00fp10qo6vbcjpew	cmvk2e1ku00fo10qodpfpq0ib	cmvk2dzz8002g10qo0jkvuybi	Vader	2026-10-22 21:40:00.51	2026-10-22 21:40:00.51
cmvk2e1lb00fs10qozvhkz3uv	cmvk2e1l900fr10qo6euq3n2l	cmvk2e0c8005910qo6snas5k7	Vader	2026-10-22 21:40:00.526	2026-10-22 21:40:00.526
cmvk2e1lj00fv10qotye5viu2	cmvk2e1lh00fu10qodi34nlo8	cmvk2e0cd005a10qodtv0o5s2	Vader	2026-10-22 21:40:00.533	2026-10-22 21:40:00.533
cmvk2e1lo00fy10qop2uwosco	cmvk2e1ln00fx10qob4gtsuxb	cmvk2e0cd005a10qodtv0o5s2	Vader	2026-10-22 21:40:00.539	2026-10-22 21:40:00.539
cmvk2e1m000g110qoud8nzxvj	cmvk2e1lz00g010qor4spgnh3	cmvk2dzzk002j10qo1a17wuz7	Vader	2026-10-22 21:40:00.551	2026-10-22 21:40:00.551
cmvk2e1m600g410qo224yprpy	cmvk2e1m500g310qogosi93ht	cmvk2dzzp002k10qodrblt1ll	Vader	2026-10-22 21:40:00.557	2026-10-22 21:40:00.557
cmvk2e1md00g710qo0hk86oh0	cmvk2e1mc00g610qokmrvsajm	cmvk2dzzs002l10qooafcu6iv	Vader	2026-10-22 21:40:00.564	2026-10-22 21:40:00.564
cmvk2e1mp00ga10qoirszrrih	cmvk2e1mh00g910qof9zdk9s0	cmvk2dzzs002l10qooafcu6iv	Vader	2026-10-22 21:40:00.569	2026-10-22 21:40:00.569
cmvk2e1n300gd10qovfifa9dd	cmvk2e1n100gc10qoy5htea82	cmvk2dzzv002m10qoe7vbq5nv	Vader	2026-10-22 21:40:00.589	2026-10-22 21:40:00.589
cmvk2e1na00gg10qo35tt6vy5	cmvk2e1n800gf10qopkdmfra7	cmvk2dzzv002m10qoe7vbq5nv	Vader	2026-10-22 21:40:00.596	2026-10-22 21:40:00.596
cmvk2e1nl00gj10qon31j2y67	cmvk2e1nj00gi10qo6ptkzrjw	cmvk2e00c002n10qos8jn3zkz	Vader	2026-10-22 21:40:00.607	2026-10-22 21:40:00.607
cmvk2e1nr00gm10qocdx43zui	cmvk2e1nq00gl10qok2h5e8h8	cmvk2e00c002n10qos8jn3zkz	Vader	2026-10-22 21:40:00.614	2026-10-22 21:40:00.614
cmvk2e1o100gp10qophjiraiv	cmvk2e1nz00go10qosv3meac4	cmvk2e00c002n10qos8jn3zkz	Vader	2026-10-22 21:40:00.623	2026-10-22 21:40:00.623
cmvk2e1o700gs10qoou1te021	cmvk2e1o600gr10qourhjh39x	cmvk2e00j002p10qop1t141a0	Vader	2026-10-22 21:40:00.63	2026-10-22 21:40:00.63
cmvk2e1oc00gv10qoy4zcfsoi	cmvk2e1oc00gu10qoce37z8sn	cmvk2e00j002p10qop1t141a0	Vader	2026-10-22 21:40:00.636	2026-10-22 21:40:00.636
cmvk2e1oj00gy10qotyb7uxu0	cmvk2e1oh00gx10qobcvz39da	cmvk2e00m002q10qo4uxhui6w	Vader	2026-10-22 21:40:00.641	2026-10-22 21:40:00.641
cmvk2e1os00h110qo5zxa8kbk	cmvk2e1on00h010qoznju2wm0	cmvk2e00m002q10qo4uxhui6w	Vader	2026-10-22 21:40:00.647	2026-10-22 21:40:00.647
cmvk2e1p200h410qowqv7f022	cmvk2e1p000h310qoy77ot97c	cmvk2e00q002r10qolupqdwoq	Vader	2026-10-22 21:40:00.66	2026-10-22 21:40:00.66
cmvk2e1pf00h710qo3qwjblth	cmvk2e1pb00h610qohomlnt99	cmvk2e00q002r10qolupqdwoq	Vader	2026-10-22 21:40:00.671	2026-10-22 21:40:00.671
cmvk2e1po00ha10qomh6z0dmr	cmvk2e1pn00h910qo26r9kzvv	cmvk2e00u002s10qo0zuphl6q	Vader	2026-10-22 21:40:00.683	2026-10-22 21:40:00.683
cmvk2e1py00hd10qokkieeev2	cmvk2e1pv00hc10qo70s7eud4	cmvk2e011002u10qoqqrcb9x1	Vader	2026-10-22 21:40:00.691	2026-10-22 21:40:00.691
cmvk2e1qf00hg10qo82iyvvqf	cmvk2e1qc00hf10qolumdg9rh	cmvk2e017002v10qongzz981k	Vader	2026-10-22 21:40:00.708	2026-10-22 21:40:00.708
cmvk2e1qn00hj10qozeb0vlxc	cmvk2e1ql00hi10qomvtqdm69	cmvk2e017002v10qongzz981k	Vader	2026-10-22 21:40:00.717	2026-10-22 21:40:00.717
cmvk2e1qw00hm10qow9dwn9d3	cmvk2e1qu00hl10qol44lbi9l	cmvk2e01a002w10qo0odhm3du	Vader	2026-10-22 21:40:00.726	2026-10-22 21:40:00.726
cmvk2e1r600hp10qo5s99v4y9	cmvk2e1r300ho10qoohbq1j9b	cmvk2e01f002x10qoz119295f	Vader	2026-10-22 21:40:00.735	2026-10-22 21:40:00.735
cmvk2e1ro00hs10qo332mayqm	cmvk2e1rl00hr10qoln6c107h	cmvk2e01j002y10qosb3vvraw	Vader	2026-10-22 21:40:00.753	2026-10-22 21:40:00.753
cmvk2e1s200hv10qolvqbm8kl	cmvk2e1s000hu10qovy3i6l19	cmvk2e01j002y10qosb3vvraw	Vader	2026-10-22 21:40:00.769	2026-10-22 21:40:00.769
cmvk2e1t800hy10qocdbzmje0	cmvk2e1t400hx10qody17xdw5	cmvk2e0cg005b10qo0zjfp6ds	Vader	2026-10-22 21:40:00.808	2026-10-22 21:40:00.808
cmvk2e1tn00i110qoxh34cgod	cmvk2e1tk00i010qonijxikwe	cmvk2e01l002z10qo4ze66ahu	Vader	2026-10-22 21:40:00.824	2026-10-22 21:40:00.824
cmvk2e1u200i410qotrpmcbn8	cmvk2e1tz00i310qoo67eujha	cmvk2e01p003010qoxiion3je	Vader	2026-10-22 21:40:00.839	2026-10-22 21:40:00.839
cmvk2e1uk00i710qo814azlkf	cmvk2e1ug00i610qo7n6jek1u	cmvk2e01s003110qoi5te7qir	Vader	2026-10-22 21:40:00.856	2026-10-22 21:40:00.856
cmvk2e1uw00ia10qonl6vvbwv	cmvk2e1ut00i910qocffcgu3k	cmvk2e01v003210qorg0zq5nr	Vader	2026-10-22 21:40:00.869	2026-10-22 21:40:00.869
cmvk2e1va00id10qowj0mkavr	cmvk2e1v700ic10qont684rtb	cmvk2e01y003310qo6ozjb1b2	Vader	2026-10-22 21:40:00.883	2026-10-22 21:40:00.883
cmvk2e1vp00ig10qojv258y69	cmvk2e1vn00if10qoa5gn8yl7	cmvk2e01y003310qo6ozjb1b2	Vader	2026-10-22 21:40:00.899	2026-10-22 21:40:00.899
cmvk2e1vz00ij10qo3nfvx72s	cmvk2e1vx00ii10qoh5v4lhfn	cmvk2e023003410qo09vac6hc	Vader	2026-10-22 21:40:00.909	2026-10-22 21:40:00.909
cmvk2e1w600im10qotbefcsdo	cmvk2e1w500il10qoq9493xwt	cmvk2e023003410qo09vac6hc	Vader	2026-10-22 21:40:00.917	2026-10-22 21:40:00.917
cmvk2e1we00ip10qo2uvu23f6	cmvk2e1wd00io10qool1z6725	cmvk2e023003410qo09vac6hc	Vader	2026-10-22 21:40:00.925	2026-10-22 21:40:00.925
cmvk2e1wn00is10qovm0tkr2w	cmvk2e1wl00ir10qozqju3tjf	cmvk2e026003510qopqyq13g8	Vader	2026-10-22 21:40:00.933	2026-10-22 21:40:00.933
cmvk2e1x600iv10qovjckat8o	cmvk2e1wx00iu10qocetv78hy	cmvk2e029003610qob30mupr4	Vader	2026-10-22 21:40:00.946	2026-10-22 21:40:00.946
cmvk2e1y000iy10qolixw3tcz	cmvk2e1xx00ix10qo5qpio2jr	cmvk2e029003610qob30mupr4	Vader	2026-10-22 21:40:00.981	2026-10-22 21:40:00.981
cmvk2e1yc00j110qozzftnvqw	cmvk2e1ya00j010qocpb43z1p	cmvk2e02b003710qoov178x4q	Vader	2026-10-22 21:40:00.994	2026-10-22 21:40:00.994
cmvk2e1yn00j410qoopt9109e	cmvk2e1yj00j310qo2h047zs8	cmvk2e02b003710qoov178x4q	Vader	2026-10-22 21:40:01.003	2026-10-22 21:40:01.003
cmvk2e1yx00j710qomfpfmz0c	cmvk2e1yv00j610qo8qsw1g91	cmvk2e02d003810qoz7jhpqg7	Vader	2026-10-22 21:40:01.015	2026-10-22 21:40:01.015
cmvk2e1z400ja10qoopphukks	cmvk2e1z300j910qoprojkzkj	cmvk2e02f003910qorbq9cwho	Vader	2026-10-22 21:40:01.023	2026-10-22 21:40:01.023
cmvk2e1zg00jd10qo3o3sc1ln	cmvk2e1zd00jc10qoekwj6a2m	cmvk2e02f003910qorbq9cwho	Vader	2026-10-22 21:40:01.033	2026-10-22 21:40:01.033
cmvk2e1zt00jg10qotid0xafp	cmvk2e1zq00jf10qon2rqyrl1	cmvk2e02h003a10qoxlkq0rdl	Vader	2026-10-22 21:40:01.046	2026-10-22 21:40:01.046
cmvk2e20400jj10qoy2v7t5to	cmvk2e20200ji10qoprpn0uqy	cmvk2e0ci005c10qoth8k5c6m	Vader	2026-10-22 21:40:01.058	2026-10-22 21:40:01.058
cmvk2e20g00jm10qo4qgmcddq	cmvk2e20e00jl10qow8e1yiow	cmvk2e0ci005c10qoth8k5c6m	Vader	2026-10-22 21:40:01.07	2026-10-22 21:40:01.07
cmvk2e20r00jp10qop7vug8ju	cmvk2e20p00jo10qoxqql70bo	cmvk2e02m003c10qofdxmo5sx	Vader	2026-10-22 21:40:01.081	2026-10-22 21:40:01.081
cmvk2e21100js10qopaxvvlcz	cmvk2e20y00jr10qoh8pjk1e2	cmvk2e02y003e10qo1h8vl2xc	Vader	2026-10-22 21:40:01.09	2026-10-22 21:40:01.09
cmvk2e21700jv10qo5hk0i742	cmvk2e21700ju10qo6yrh8nn9	cmvk2e031003f10qothp9g2ve	Vader	2026-10-22 21:40:01.099	2026-10-22 21:40:01.099
cmvk2e21m00jy10qon8vmo4jk	cmvk2e21i00jx10qo09v4vqf9	cmvk2e031003f10qothp9g2ve	Vader	2026-10-22 21:40:01.11	2026-10-22 21:40:01.11
cmvk2e21w00k110qoq0nzr04s	cmvk2e21u00k010qooq70hbjl	cmvk2e031003f10qothp9g2ve	Vader	2026-10-22 21:40:01.122	2026-10-22 21:40:01.122
cmvk2e22500k410qoq8cu6ps5	cmvk2e22300k310qoaweja2qk	cmvk2e037003g10qol44iwetw	Vader	2026-10-22 21:40:01.132	2026-10-22 21:40:01.132
cmvk2e22e00k710qo50wi7sek	cmvk2e22c00k610qoezyj455i	cmvk2e037003g10qol44iwetw	Vader	2026-10-22 21:40:01.14	2026-10-22 21:40:01.14
cmvk2e22k00ka10qol50y16mn	cmvk2e22j00k910qobkyi27z6	cmvk2e03a003h10qou2l0ku7h	Vader	2026-10-22 21:40:01.147	2026-10-22 21:40:01.147
cmvk2e22s00kd10qoywqzo818	cmvk2e22q00kc10qomrp1weci	cmvk2e03d003i10qoslsc0xnu	Vader	2026-10-22 21:40:01.154	2026-10-22 21:40:01.154
cmvk2e23500kg10qot9xltmyu	cmvk2e23200kf10qo6q0e2tic	cmvk2e03d003i10qoslsc0xnu	Vader	2026-10-22 21:40:01.166	2026-10-22 21:40:01.166
cmvk2e23q00kj10qo9tt8mlg7	cmvk2e23m00ki10qoulyqnae4	cmvk2e03h003j10qoxycmqktn	Vader	2026-10-22 21:40:01.186	2026-10-22 21:40:01.186
cmvk2e24300km10qoo45kkdkr	cmvk2e24100kl10qorjekwidz	cmvk2e03h003j10qoxycmqktn	Vader	2026-10-22 21:40:01.201	2026-10-22 21:40:01.201
cmvk2e24i00kp10qob8j29el8	cmvk2e24f00ko10qowjirabgu	cmvk2e03s003m10qoyu9jpore	Vader	2026-10-22 21:40:01.215	2026-10-22 21:40:01.215
cmvk2e24u00ks10qoyjjr261l	cmvk2e24s00kr10qoea9lhkmq	cmvk2e03v003n10qow1m9tin6	Vader	2026-10-22 21:40:01.228	2026-10-22 21:40:01.228
cmvk2e25600kv10qoghx2jge2	cmvk2e25200ku10qofc0p978p	cmvk2dzzv002m10qoe7vbq5nv	Vader	2026-10-22 21:40:01.238	2026-10-22 21:40:01.238
cmvk2e25t00ky10qovd34bp62	cmvk2e25r00kx10qobmpq91u6	cmvk2e0ck005d10qouxdg7bwm	Vader	2026-10-22 21:40:01.263	2026-10-22 21:40:01.263
cmvk2e26500l110qoixmnlrxl	cmvk2e26400l010qoq73zmzm7	cmvk2e0ck005d10qouxdg7bwm	Vader	2026-10-22 21:40:01.276	2026-10-22 21:40:01.276
cmvk2e26h00l410qoujvfw2rj	cmvk2e26d00l310qo5tfcm5iv	cmvk2e048003r10qonwehff0f	Vader	2026-10-22 21:40:01.285	2026-10-22 21:40:01.285
cmvk2e26s00l710qo9ryqxsqb	cmvk2e26q00l610qonpxspp6x	cmvk2e04f003s10qoet1m9otw	Vader	2026-10-22 21:40:01.298	2026-10-22 21:40:01.298
cmvk2e27500la10qocrdwo7de	cmvk2e27100l910qocx3ex4iz	cmvk2e04f003s10qoet1m9otw	Vader	2026-10-22 21:40:01.309	2026-10-22 21:40:01.309
cmvk2e27n00ld10qo3m2gjssm	cmvk2e27h00lc10qo7gh0hsiq	cmvk2e04j003t10qou5vdmlxu	Vader	2026-10-22 21:40:01.325	2026-10-22 21:40:01.325
cmvk2e27x00lg10qo0frb0an5	cmvk2e27w00lf10qom9p26wiz	cmvk2e00y002t10qok8edizk0	Vader	2026-10-22 21:40:01.34	2026-10-22 21:40:01.34
cmvk2e28400lj10qot97ic0x7	cmvk2e28200li10qovdat671z	cmvk2e00y002t10qok8edizk0	Vader	2026-10-22 21:40:01.346	2026-10-22 21:40:01.346
cmvk2e28j00lm10qoaeopblkf	cmvk2e28e00ll10qowlkawpgt	cmvk2e04v003w10qow4ztib5v	Vader	2026-10-22 21:40:01.358	2026-10-22 21:40:01.358
cmvk2e28w00lp10qoo0kip3b6	cmvk2e28s00lo10qo7e2bp1o3	cmvk2e04y003x10qoh3s7idcv	Vader	2026-10-22 21:40:01.372	2026-10-22 21:40:01.372
cmvk2e29500ls10qothiunig5	cmvk2e29400lr10qocjdvc6b6	cmvk2e052003y10qo5fbjl02o	Vader	2026-10-22 21:40:01.384	2026-10-22 21:40:01.384
cmvk2e29d00lv10qonx256gf0	cmvk2e29b00lu10qog7rpgkcr	cmvk2e055003z10qor4z8bz65	Vader	2026-10-22 21:40:01.391	2026-10-22 21:40:01.391
cmvk2e29n00ly10qootnlwg9v	cmvk2e29m00lx10qo101embvd	cmvk2e059004010qozitt32od	Vader	2026-10-22 21:40:01.402	2026-10-22 21:40:01.402
cmvk2e2ap00m110qosgoeo8wr	cmvk2e2ac00m010qo5ptppc5o	cmvk2e05c004110qoamkrpmni	Vader	2026-10-22 21:40:01.428	2026-10-22 21:40:01.428
cmvk2e2bj00m410qozuj2rq24	cmvk2e2bg00m310qo6pqqxpjl	cmvk2e05c004110qoamkrpmni	Vader	2026-10-22 21:40:01.468	2026-10-22 21:40:01.468
cmvk2e2c400m710qoe9alu1ji	cmvk2e2c200m610qoor5xfdo6	cmvk2e05k004210qoan7wg9y7	Vader	2026-10-22 21:40:01.49	2026-10-22 21:40:01.49
cmvk2e2cf00ma10qoefavak58	cmvk2e2cd00m910qon6uxqyar	cmvk2e02j003b10qoice44sc6	Vader	2026-10-22 21:40:01.501	2026-10-22 21:40:01.501
cmvk2e2cw00md10qobyl87u2w	cmvk2e2cr00mc10qobys4bvnw	cmvk2e05v004410qoz0tscxpi	Vader	2026-10-22 21:40:01.515	2026-10-22 21:40:01.515
cmvk2e2da00mg10qofydy7njp	cmvk2e2d700mf10qoox604aky	cmvk2e0co005e10qohukjpss4	Vader	2026-10-22 21:40:01.531	2026-10-22 21:40:01.531
cmvk2e2dp00mj10qovw4xax2a	cmvk2e2dk00mi10qob19yp1hd	cmvk2e06i004610qo9zjye869	Vader	2026-10-22 21:40:01.544	2026-10-22 21:40:01.544
cmvk2e2e900mm10qow7wnedhw	cmvk2e2e600ml10qoxvm5sc2r	cmvk2e06i004610qo9zjye869	Vader	2026-10-22 21:40:01.566	2026-10-22 21:40:01.566
cmvk2e2eu00mp10qozeazem7g	cmvk2e2eg00mo10qokzbvud3z	cmvk2e06u004710qob7xfcl6l	Vader	2026-10-22 21:40:01.576	2026-10-22 21:40:01.576
cmvk2e2fe00ms10qopts93o9g	cmvk2e2fa00mr10qok97kyvqg	cmvk2e074004810qog6lax1h0	Vader	2026-10-22 21:40:01.606	2026-10-22 21:40:01.606
cmvk2e2fu00mv10qolf0le31a	cmvk2e2fr00mu10qohapjlfv8	cmvk2e078004910qo30rtyuao	Vader	2026-10-22 21:40:01.623	2026-10-22 21:40:01.623
cmvk2e2ge00my10qoapevwtne	cmvk2e2ga00mx10qoxq9y911o	cmvk2e0cq005f10qo32f2jore	Vader	2026-10-22 21:40:01.642	2026-10-22 21:40:01.642
cmvk2e2gr00n110qotp2zznej	cmvk2e2gp00n010qop5winihn	cmvk2e0cq005f10qo32f2jore	Vader	2026-10-22 21:40:01.657	2026-10-22 21:40:01.657
cmvk2e2h300n410qo9b3l34nr	cmvk2e2h100n310qoxejneoi1	cmvk2e07g004b10qoqzabhi1w	Vader	2026-10-22 21:40:01.669	2026-10-22 21:40:01.669
cmvk2e2hj00n710qonoy9uz3d	cmvk2e2he00n610qoqjycfgkw	cmvk2e07m004c10qojv6rfb08	Vader	2026-10-22 21:40:01.682	2026-10-22 21:40:01.682
cmvk2e2hv00na10qoco87x7qp	cmvk2e2hs00n910qo4wyqhz7b	cmvk2e07s004d10qot31pdbfk	Vader	2026-10-22 21:40:01.696	2026-10-22 21:40:01.696
cmvk2e2i300nd10qo3wm89f54	cmvk2e2i200nc10qoy0x32f8q	cmvk2e07v004e10qofyk5hqbk	Vader	2026-10-22 21:40:01.706	2026-10-22 21:40:01.706
cmvk2e2il00ng10qolfhjhrhd	cmvk2e2ie00nf10qoz6ai0dmm	cmvk2e07y004f10qom17203k8	Vader	2026-10-22 21:40:01.718	2026-10-22 21:40:01.718
cmvk2e2iy00nj10qo7l3o4xdl	cmvk2e2iw00ni10qoywbqnai5	cmvk2e07y004f10qom17203k8	Vader	2026-10-22 21:40:01.736	2026-10-22 21:40:01.736
cmvk2e2je00nm10qooiewc9mb	cmvk2e2ja00nl10qoc5fvj7au	cmvk2e082004g10qoeupz1l26	Vader	2026-10-22 21:40:01.75	2026-10-22 21:40:01.75
cmvk2e2kt00np10qor6sh97a7	cmvk2e2kl00no10qo92hh1f3b	cmvk2e08d004h10qoc9lqzuhz	Vader	2026-10-22 21:40:01.797	2026-10-22 21:40:01.797
cmvk2e2mi00ns10qo6plthxdd	cmvk2e2m000nr10qo7irsk46h	cmvk2e08r004i10qoerxl1vj2	Vader	2026-10-22 21:40:01.848	2026-10-22 21:40:01.848
cmvk2e2ne00nv10qozw2b8gqy	cmvk2e2mz00nu10qoahpq6en1	cmvk2e08r004i10qoerxl1vj2	Vader	2026-10-22 21:40:01.883	2026-10-22 21:40:01.883
cmvk2e2ny00ny10qos415ab54	cmvk2e2nv00nx10qoicxjuufx	cmvk2e08r004i10qoerxl1vj2	Vader	2026-10-22 21:40:01.915	2026-10-22 21:40:01.915
cmvk2e2oe00o110qoiu0xocua	cmvk2e2oa00o010qo3nqbcmwy	cmvk2e08w004j10qo8u4g42hs	Vader	2026-10-22 21:40:01.93	2026-10-22 21:40:01.93
cmvk2e2p100o410qod66sz902	cmvk2e2ox00o310qo1fp7jf9k	cmvk2e08w004j10qo8u4g42hs	Vader	2026-10-22 21:40:01.953	2026-10-22 21:40:01.953
cmvk2e2pf00o710qozi7nsl79	cmvk2e2pd00o610qodd2hmfys	cmvk2e090004k10qo1uq97pr1	Vader	2026-10-22 21:40:01.969	2026-10-22 21:40:01.969
cmvk2e2pt00oa10qojl5019lh	cmvk2e2pq00o910qo2730l4yw	cmvk2e093004l10qonqeu45pf	Vader	2026-10-22 21:40:01.982	2026-10-22 21:40:01.982
cmvk2e2q700od10qo2dh5pphj	cmvk2e2q300oc10qot2xa2ayx	cmvk2e097004m10qo3gkab08j	Vader	2026-10-22 21:40:01.995	2026-10-22 21:40:01.995
cmvk2e2qn00og10qo0gh5ssph	cmvk2e2qi00of10qob9mtp95m	cmvk2e09a004n10qoue735gut	Vader	2026-10-22 21:40:02.01	2026-10-22 21:40:02.01
cmvk2e2qy00oj10qogyc9fm93	cmvk2e2qv00oi10qotvkb5gwr	cmvk2e09c004o10qo7qo04wio	Vader	2026-10-22 21:40:02.023	2026-10-22 21:40:02.023
cmvk2e2r600om10qol9ig4386	cmvk2e2r400ol10qo3w3iir2x	cmvk2e09j004p10qo8rsa9une	Vader	2026-10-22 21:40:02.032	2026-10-22 21:40:02.032
cmvk2e2rh00op10qomm37qtui	cmvk2e2rf00oo10qoel5fv9j7	cmvk2e09j004p10qo8rsa9une	Vader	2026-10-22 21:40:02.043	2026-10-22 21:40:02.043
cmvk2e2ru00os10qonmp8w7xp	cmvk2e2rs00or10qogy8fva6b	cmvk2e0a0004r10qo3c3ychu1	Vader	2026-10-22 21:40:02.056	2026-10-22 21:40:02.056
cmvk2e2sb00ov10qox3khoa1n	cmvk2e2s900ou10qolb7uyr4q	cmvk2e0a0004r10qo3c3ychu1	Vader	2026-10-22 21:40:02.073	2026-10-22 21:40:02.073
cmvk2e2sr00oy10qolem2ivtg	cmvk2e2so00ox10qorvrpc40u	cmvk2e0a4004s10qop51oqauy	Vader	2026-10-22 21:40:02.088	2026-10-22 21:40:02.088
cmvk2e2t400p110qoawdh1nq7	cmvk2e2t200p010qo7ywriqdq	cmvk2e0a4004s10qop51oqauy	Vader	2026-10-22 21:40:02.102	2026-10-22 21:40:02.102
cmvk2e2te00p410qo5i8gf4fc	cmvk2e2tc00p310qoefmn8evv	cmvk2e0a7004t10qokx0paehf	Vader	2026-10-22 21:40:02.112	2026-10-22 21:40:02.112
cmvk2e2tu00p710qoiu8yiux7	cmvk2e2ts00p610qosvzydygr	cmvk2e0cu005g10qomvwgfkkh	Vader	2026-10-22 21:40:02.128	2026-10-22 21:40:02.128
cmvk2e2u600pa10qoxjw1jdzj	cmvk2e2u300p910qoppseznc5	cmvk2e0cu005g10qomvwgfkkh	Vader	2026-10-22 21:40:02.139	2026-10-22 21:40:02.139
cmvk2e2uk00pd10qosx6npic4	cmvk2e2ui00pc10qopcqo26em	cmvk2e0cq005f10qo32f2jore	Vader	2026-10-22 21:40:02.154	2026-10-22 21:40:02.154
cmvk2e2vm00pg10qobp7j1bhh	cmvk2e2vc00pf10qo3t9lj3li	cmvk2e0cx005h10qoqbyvem6q	Vader	2026-10-22 21:40:02.184	2026-10-22 21:40:02.184
cmvk2e2wa00pj10qog1v79n0a	cmvk2e2w500pi10qovwf8e6aw	cmvk2e0ag004w10qoo41lwhgq	Vader	2026-10-22 21:40:02.213	2026-10-22 21:40:02.213
cmvk2e2wv00pm10qo6h6kenk3	cmvk2e2wt00pl10qor4zldg40	cmvk2e0ag004w10qoo41lwhgq	Vader	2026-10-22 21:40:02.238	2026-10-22 21:40:02.238
cmvk2e2x700pp10qoagt6td3e	cmvk2e2x500po10qomph1l3p6	cmvk2e0cz005i10qo5lb871sy	Vader	2026-10-22 21:40:02.249	2026-10-22 21:40:02.249
cmvk2e2xm00ps10qo0yl9vkrx	cmvk2e2xi00pr10qoyc5wzqn7	cmvk2e0cz005i10qo5lb871sy	Vader	2026-10-22 21:40:02.262	2026-10-22 21:40:02.262
cmvk2e2xz00pv10qoehd151lv	cmvk2e2xw00pu10qofmc21wia	cmvk2e0aq004y10qo2hcxl457	Vader	2026-10-22 21:40:02.276	2026-10-22 21:40:02.276
cmvk2e2yh00py10qo3uv8txdj	cmvk2e2yc00px10qoh5przmtm	cmvk2e0at004z10qopprxrufs	Vader	2026-10-22 21:40:02.292	2026-10-22 21:40:02.292
cmvk2e2yq00q110qoqy5fbx3k	cmvk2e2yn00q010qonug7nlo4	cmvk2e0at004z10qopprxrufs	Vader	2026-10-22 21:40:02.303	2026-10-22 21:40:02.303
cmvk2e2z400q410qoemq3qmtm	cmvk2e2z200q310qobwzccw2u	cmvk2e0b0005110qo63mtklw1	Vader	2026-10-22 21:40:02.318	2026-10-22 21:40:02.318
cmvk2e2zg00q710qo2tj7em8u	cmvk2e2zb00q610qopmdhaaas	cmvk2e0c4005810qoacv4wgeb	Vader	2026-10-22 21:40:02.328	2026-10-22 21:40:02.328
cmvk2e30400qa10qoderc17ij	cmvk2e30100q910qo8yqwve66	cmvk2e0bb005310qopcqsq173	Vader	2026-10-22 21:40:02.353	2026-10-22 21:40:02.353
cmvk2e30h00qd10qogmd2fsay	cmvk2e30f00qc10qozdumo62o	cmvk2e0bb005310qopcqsq173	Vader	2026-10-22 21:40:02.367	2026-10-22 21:40:02.367
cmvk2e30s00qg10qog0uun82g	cmvk2e30p00qf10qo2i71tdoy	cmvk2e0bi005410qou4v27t6t	Vader	2026-10-22 21:40:02.378	2026-10-22 21:40:02.378
cmvk2e31400qj10qoniqkcmqx	cmvk2e31200qi10qo9hc0wu8y	cmvk2e0bs005610qocf4x2m4x	Vader	2026-10-22 21:40:02.39	2026-10-22 21:40:02.39
\.


--
-- Data for Name: student_status_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_status_events (id, "studentId", "fromStatus", "toStatus", "changedById", "changedAt", note) FROM stdin;
cmvksfxqc000a01qqq68nl2uk	cmvks93uf000801qq4m9mtqfd	WAITING_LIST	ARCHIVED	c724d280-7f41-4b0f-bb24-fc29e1e7f73b	2026-10-23 09:49:18.852	Ouder/verzorger gearchiveerd
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, "firstName", "lastName", sex, "dateOfBirth", "createdAt", "updatedAt", image, status, "enrolledAt", "archivedAt") FROM stdin;
cmvk2e0xj00al10qovd7t53vj	Hafsa	Azerkaan	FEMALE	2016-01-03 00:00:00	2026-10-22 21:39:59.671	2026-10-22 21:42:52.772	/uploads/students/1a88e3f7-323c-4900-802d-e5ba7d762a0f.png	ACTIVE	2026-10-22	\N
cmvks0n1g000401qq3smpb93i	Binta	Doumboya	FEMALE	2019-06-20 00:00:00	2026-10-23 09:37:25.156	2026-10-23 09:37:25.156	/uploads/students/7f4c69f2-ce51-4813-a8ce-7c1a9bcad9aa.png	WAITING_LIST	2026-10-23	\N
cmvks93uf000801qq4m9mtqfd	Ammar	Qadri	MALE	2026-10-17 00:00:00	2026-10-23 09:44:00.184	2026-10-23 09:49:18.846	\N	ARCHIVED	2026-10-23	2026-10-23
cmvmdscn6002o01qqgj8ki8g4	Ggh	Ggh	MALE	2026-10-24 00:00:00	2026-10-24 12:34:36.162	2026-10-24 12:34:36.162	\N	WAITING_LIST	2026-10-24	\N
cmvk2e0f8005j10qop7xz3aez	Adam	Maraghich	MALE	2015-02-17 00:00:00	2026-10-22 21:39:59.012	2026-10-22 21:39:59.012	\N	ACTIVE	2022-03-05	\N
cmvk2e0fr005m10qoxk85a4gx	Zakaria	Maraghich	MALE	2017-12-02 00:00:00	2026-10-22 21:39:59.031	2026-10-22 21:39:59.031	\N	ACTIVE	2023-10-14	\N
cmvk2e0g3005p10qomvyxe6dj	Houda	Marghich	FEMALE	2020-01-29 00:00:00	2026-10-22 21:39:59.043	2026-10-22 21:39:59.043	\N	ACTIVE	2026-10-11	\N
cmvk2e0ge005s10qo7a1ppbs9	Sarah	Sialioua	FEMALE	2016-11-26 00:00:00	2026-10-22 21:39:59.054	2026-10-22 21:39:59.054	\N	ACTIVE	2024-01-13	\N
cmvk2e0gp005v10qom1efo6sv	Insaf	Bourdif	FEMALE	2014-10-28 00:00:00	2026-10-22 21:39:59.065	2026-10-22 21:39:59.065	\N	ACTIVE	2022-11-05	\N
cmvk2e0gz005y10qotwaklrmg	Rayan	Sahraoui	MALE	2013-02-25 00:00:00	2026-10-22 21:39:59.075	2026-10-22 21:39:59.075	\N	ACTIVE	2026-10-22	\N
cmvk2e0h9006110qoy3bg7l30	Nour	Ben gharda	FEMALE	2019-05-14 00:00:00	2026-10-22 21:39:59.085	2026-10-22 21:39:59.085	\N	ACTIVE	2025-10-21	\N
cmvk2e0hi006410qoeec2qw1j	Assia	Belhadi	FEMALE	2010-04-22 00:00:00	2026-10-22 21:39:59.094	2026-10-22 21:39:59.094	\N	ACTIVE	2026-10-22	\N
cmvk2e0hu006710qokk2xy663	Houdayfa	Belhadi	MALE	2017-12-10 00:00:00	2026-10-22 21:39:59.106	2026-10-22 21:39:59.106	\N	ACTIVE	2023-03-04	\N
cmvk2e0id006a10qo4fp7ykud	Nisrine	El Mahdadi	FEMALE	2016-01-10 00:00:00	2026-10-22 21:39:59.125	2026-10-22 21:39:59.125	\N	ACTIVE	2026-10-22	\N
cmvk2e0io006d10qo3rpuu4jx	Omayra	El Mahdadi	FEMALE	2018-05-31 00:00:00	2026-10-22 21:39:59.136	2026-10-22 21:39:59.136	\N	ACTIVE	2026-10-22	\N
cmvk2e0iy006g10qop9g8g78n	Safouan	El Mahdadi	MALE	2017-03-13 00:00:00	2026-10-22 21:39:59.146	2026-10-22 21:39:59.146	\N	ACTIVE	2026-10-22	\N
cmvk2e0j9006j10qooapareag	Youssef	Bourarach	MALE	2020-08-21 00:00:00	2026-10-22 21:39:59.157	2026-10-22 21:39:59.157	\N	ACTIVE	2026-10-04	\N
cmvk2e0jk006m10qo671j2ft1	Aya	Bouhaoulian	FEMALE	2020-03-22 00:00:00	2026-10-22 21:39:59.168	2026-10-22 21:39:59.168	\N	ACTIVE	2026-10-22	\N
cmvk2e0ju006p10qo8s1059sq	Mohamed-Anuar	Elbaouti	MALE	2014-05-27 00:00:00	2026-10-22 21:39:59.178	2026-10-22 21:39:59.178	\N	ACTIVE	2021-10-10	\N
cmvk2e0kd006s10qowzu5tucn	rayan	el Meryaoui	MALE	1900-01-01 00:00:00	2026-10-22 21:39:59.197	2026-10-22 21:39:59.197	\N	ACTIVE	2026-05-24	\N
cmvk2e0ko006v10qocpipelf3	amira	el Meryaoui	FEMALE	1900-01-01 00:00:00	2026-10-22 21:39:59.208	2026-10-22 21:39:59.208	\N	ACTIVE	2026-05-24	\N
cmvk2e0l2006y10qok6uxeupm	Amber	Hitou	FEMALE	2018-10-17 00:00:00	2026-10-22 21:39:59.223	2026-10-22 21:39:59.223	\N	ACTIVE	2026-10-22	\N
cmvk2e0lf007110qox7244gt0	Amin	Hitou	MALE	2017-02-06 00:00:00	2026-10-22 21:39:59.235	2026-10-22 21:39:59.235	\N	ACTIVE	2026-10-22	\N
cmvk2e0lo007410qophya3uil	Houdaifa	Moussi	MALE	2016-02-03 00:00:00	2026-10-22 21:39:59.244	2026-10-22 21:39:59.244	\N	ACTIVE	2022-03-05	\N
cmvk2e0lw007710qotmosrlq5	Reda	Moussi	MALE	2018-07-30 00:00:00	2026-10-22 21:39:59.252	2026-10-22 21:39:59.252	\N	ACTIVE	2026-10-22	\N
cmvk2e0m4007a10qotbwxc7eb	Ayoub	El Abbassi	MALE	2012-07-12 00:00:00	2026-10-22 21:39:59.26	2026-10-22 21:39:59.26	\N	ACTIVE	2026-10-22	\N
cmvk2e0md007d10qo9zsykd0a	Hafsa	El Abbassi	FEMALE	2018-12-14 00:00:00	2026-10-22 21:39:59.269	2026-10-22 21:39:59.269	\N	ACTIVE	2026-10-22	\N
cmvk2e0mn007g10qogjizo77d	Mohamed	El Abbassi	MALE	2012-07-12 00:00:00	2026-10-22 21:39:59.279	2026-10-22 21:39:59.279	\N	ACTIVE	2026-10-22	\N
cmvk2e0mx007j10qow4xt9f1o	Zeyneb	El Abbassi	FEMALE	2015-10-29 00:00:00	2026-10-22 21:39:59.289	2026-10-22 21:39:59.289	\N	ACTIVE	2022-11-05	\N
cmvk2e0n7007m10qo74e8y9jm	Liya	Badr	FEMALE	2021-04-02 00:00:00	2026-10-22 21:39:59.299	2026-10-22 21:39:59.299	\N	ACTIVE	2025-10-11	\N
cmvk2e0nk007p10qoaxw6gch4	Soraya	Badr	FEMALE	2016-10-08 00:00:00	2026-10-22 21:39:59.312	2026-10-22 21:39:59.312	\N	ACTIVE	2023-03-04	\N
cmvk2e0nu007s10qo0xmaj30h	Djennat	Lamchachti	FEMALE	2020-05-26 00:00:00	2026-10-22 21:39:59.323	2026-10-22 21:39:59.323	\N	ACTIVE	2025-05-24	\N
cmvk2e0o6007v10qoxdixzsrp	Hidaya	Lamchachti	FEMALE	2016-04-02 00:00:00	2026-10-22 21:39:59.334	2026-10-22 21:39:59.334	\N	ACTIVE	2022-11-05	\N
cmvk2e0oz008110qox0ws44dw	Farah	Karoum	FEMALE	2015-11-03 00:00:00	2026-10-22 21:39:59.363	2026-10-22 21:39:59.363	\N	ACTIVE	2022-11-05	\N
cmvk2e0pa008410qo4r0eavjw	Hajar	Es-saken	FEMALE	2018-11-04 00:00:00	2026-10-22 21:39:59.374	2026-10-22 21:39:59.374	\N	ACTIVE	2025-10-04	\N
cmvk2e0pi008710qo1720qe77	Mohamed	Es-Saken	MALE	2015-08-21 00:00:00	2026-10-22 21:39:59.382	2026-10-22 21:39:59.382	\N	ACTIVE	2026-10-22	\N
cmvk2e0pt008a10qo5f82vua2	Safuan	Adda	MALE	2011-03-05 00:00:00	2026-10-22 21:39:59.393	2026-10-22 21:39:59.393	\N	ACTIVE	2026-10-22	\N
cmvk2e0qh008d10qoanwe1tei	Safae	Akchich/Bourakba	FEMALE	2015-02-07 00:00:00	2026-10-22 21:39:59.417	2026-10-22 21:39:59.417	\N	ACTIVE	2021-11-06	\N
cmvk2e0qs008g10qo49tbyhpf	Oumaima	Akchich	FEMALE	2020-11-06 00:00:00	2026-10-22 21:39:59.428	2026-10-22 21:39:59.428	\N	ACTIVE	2026-10-11	\N
cmvk2e0r6008j10qow2kjqodr	Yasser	Boutahir	MALE	2018-09-22 00:00:00	2026-10-22 21:39:59.442	2026-10-22 21:39:59.442	\N	ACTIVE	2026-10-22	\N
cmvk2e0re008m10qoh4nxmdu8	Naoufal	Talhaoui	MALE	2013-07-01 00:00:00	2026-10-22 21:39:59.45	2026-10-22 21:39:59.45	\N	ACTIVE	2026-10-22	\N
cmvk2e0rp008p10qohkq8qlhx	Ayoub	El kaydi	MALE	2016-02-17 00:00:00	2026-10-22 21:39:59.461	2026-10-22 21:39:59.461	\N	ACTIVE	2026-10-22	\N
cmvk2e0rz008s10qojfdjm4m8	Safae	El kaydi	FEMALE	2019-10-11 00:00:00	2026-10-22 21:39:59.471	2026-10-22 21:39:59.471	\N	ACTIVE	2026-10-22	\N
cmvk2e0s5008v10qopeicutss	Safiya El Mansouri	Azzamouri	FEMALE	2014-12-25 00:00:00	2026-10-22 21:39:59.477	2026-10-22 21:39:59.477	\N	ACTIVE	2026-10-22	\N
cmvk2e0sg008y10qo3jv48tmq	Maher	Esadik	MALE	2018-06-22 00:00:00	2026-10-22 21:39:59.488	2026-10-22 21:39:59.488	\N	ACTIVE	2026-10-22	\N
cmvk2e0sq009110qorf0zejq7	Amir	Ould Hamou	MALE	2011-05-24 00:00:00	2026-10-22 21:39:59.498	2026-10-22 21:39:59.498	\N	ACTIVE	2026-10-04	\N
cmvk2e0sy009410qo6gdrb9th	Amira	Boukhachkhach	FEMALE	2017-09-04 00:00:00	2026-10-22 21:39:59.506	2026-10-22 21:39:59.506	\N	ACTIVE	2026-10-22	\N
cmvk2e0t4009710qo6y5w6a8d	Hajar	Boukhachkhach	FEMALE	2019-12-28 00:00:00	2026-10-22 21:39:59.512	2026-10-22 21:39:59.512	\N	ACTIVE	2026-10-22	\N
cmvk2e0tc009a10qopmfmhk8v	Maysa	Boukhachkhach	FEMALE	1900-01-01 00:00:00	2026-10-22 21:39:59.52	2026-10-22 21:39:59.52	\N	ACTIVE	2022-11-05	\N
cmvk2e0tp009d10qotj9m8qof	Salsabila	Lakbiach	FEMALE	2019-04-15 00:00:00	2026-10-22 21:39:59.533	2026-10-22 21:39:59.533	\N	ACTIVE	2026-10-09	\N
cmvk2e0u4009g10qojvw6fzq2	Nabil	Aouad	MALE	2007-12-12 00:00:00	2026-10-22 21:39:59.548	2026-10-22 21:39:59.548	\N	ACTIVE	2023-10-14	\N
cmvk2e0uf009j10qonmsrbolk	Firdaous	Ochen	FEMALE	2017-10-11 00:00:00	2026-10-22 21:39:59.559	2026-10-22 21:39:59.559	\N	ACTIVE	2026-10-10	\N
cmvk2e0ux009m10qompgb7v0d	Amira	Zoundri	MALE	2017-08-23 00:00:00	2026-10-22 21:39:59.577	2026-10-22 21:39:59.577	\N	ACTIVE	2023-03-04	\N
cmvk2e0v8009p10qoxvtkgw0e	Abdoullah	Belhadi	MALE	2015-09-08 00:00:00	2026-10-22 21:39:59.588	2026-10-22 21:39:59.588	\N	ACTIVE	2022-11-05	\N
cmvk2e0ve009s10qocx5lazvz	Maryam	Belhadi	FEMALE	2016-12-13 00:00:00	2026-10-22 21:39:59.594	2026-10-22 21:39:59.594	\N	ACTIVE	2022-11-05	\N
cmvk2e0vk009v10qocx5xules	Ayman	Lakbiach	MALE	2019-06-29 00:00:00	2026-10-22 21:39:59.6	2026-10-22 21:39:59.6	\N	ACTIVE	2025-10-04	\N
cmvk2e0vz00a010qoqk2qppbc	Isra	Lakbiyech	FEMALE	2014-09-07 00:00:00	2026-10-22 21:39:59.615	2026-10-22 21:39:59.615	\N	ACTIVE	2021-08-06	\N
cmvk2e0w600a310qomk482mit	Amir	Bouhjira	MALE	2013-02-20 00:00:00	2026-10-22 21:39:59.622	2026-10-22 21:39:59.622	\N	ACTIVE	2026-10-22	\N
cmvk2e0we00a610qocxbkzyuy	Adam	Loukili	MALE	2014-10-05 00:00:00	2026-10-22 21:39:59.63	2026-10-22 21:39:59.63	\N	ACTIVE	2026-10-22	\N
cmvk2e0wm00a910qoj3lq7cib	Douaa	Loukili	FEMALE	2017-03-25 00:00:00	2026-10-22 21:39:59.638	2026-10-22 21:39:59.638	\N	ACTIVE	2026-10-22	\N
cmvk2e0wt00ac10qo7vfmjd0a	Raihanna	El abadi	FEMALE	2026-09-19 00:00:00	2026-10-22 21:39:59.645	2026-10-22 21:39:59.645	\N	ACTIVE	2026-10-11	\N
cmvk2e0x200af10qogjjlyhze	Khalil	Mehdaoui	MALE	2018-08-28 00:00:00	2026-10-22 21:39:59.654	2026-10-22 21:39:59.654	\N	ACTIVE	2026-10-10	\N
cmvk2e0xb00ai10qokuc5bs2q	Nouh	Hamidi	MALE	2020-06-13 00:00:00	2026-10-22 21:39:59.663	2026-10-22 21:39:59.663	\N	ACTIVE	2026-10-22	\N
cmvk2e0xp00ao10qol3ssoyki	Zakarija	Azerkaan	MALE	2016-01-03 00:00:00	2026-10-22 21:39:59.677	2026-10-22 21:39:59.677	\N	ACTIVE	2022-03-05	\N
cmvk2e0xw00ar10qo73ok5r4k	Anas	Azarkane	MALE	2021-03-28 00:00:00	2026-10-22 21:39:59.684	2026-10-22 21:39:59.684	\N	ACTIVE	2026-10-18	\N
cmvk2e0y200au10qouns1kkb0	Caam Saif Al-Din	Chari	MALE	2020-09-12 00:00:00	2026-10-22 21:39:59.69	2026-10-22 21:39:59.69	\N	ACTIVE	2026-10-11	\N
cmvk2e0yb00ax10qopadd4f4c	Hajar	Assarraj	FEMALE	2009-09-07 00:00:00	2026-10-22 21:39:59.699	2026-10-22 21:39:59.699	\N	ACTIVE	2026-10-22	\N
cmvk2e0yj00b010qowwfl1nln	Dikra	Sajie	FEMALE	2017-12-05 00:00:00	2026-10-22 21:39:59.707	2026-10-22 21:39:59.707	\N	ACTIVE	2023-03-04	\N
cmvk2e0ys00b310qomfp2y9kx	Mohammed	El maryaoui	MALE	2020-01-30 00:00:00	2026-10-22 21:39:59.716	2026-10-22 21:39:59.716	\N	ACTIVE	2026-10-10	\N
cmvk2e0z200b610qoz3wbt9k3	Ayoub	Akalai	MALE	2017-05-20 00:00:00	2026-10-22 21:39:59.726	2026-10-22 21:39:59.726	\N	ACTIVE	2023-03-03	\N
cmvk2e0z900b910qorgtkuon9	Safae	Akalai	MALE	2017-05-20 00:00:00	2026-10-22 21:39:59.733	2026-10-22 21:39:59.733	\N	ACTIVE	2023-03-03	\N
cmvk2e0ze00bc10qogbcciv39	Adama	Bari	FEMALE	2019-09-13 00:00:00	2026-10-22 21:39:59.738	2026-10-22 21:39:59.738	\N	ACTIVE	2026-10-10	\N
cmvk2e0zl00bf10qouw396q6q	Ayşe	Özgör	FEMALE	2015-02-06 00:00:00	2026-10-22 21:39:59.745	2026-10-22 21:39:59.745	\N	ACTIVE	2025-10-11	\N
cmvk2e0zr00bi10qofdc5fch4	Leyla	Özgör	FEMALE	2017-12-06 00:00:00	2026-10-22 21:39:59.751	2026-10-22 21:39:59.751	\N	ACTIVE	2025-10-11	\N
cmvk2e10200bl10qoxc22xsjq	Ali	Özgör	MALE	2021-03-12 00:00:00	2026-10-22 21:39:59.763	2026-10-22 21:39:59.763	\N	ACTIVE	2026-10-11	\N
cmvk2e10c00bo10qoclc4ctlx	Rayan	Wachrine	MALE	2012-04-26 00:00:00	2026-10-22 21:39:59.772	2026-10-22 21:39:59.772	\N	ACTIVE	2026-10-10	\N
cmvk2e10m00br10qo701zsodd	Amani	Hemmit	FEMALE	2010-12-11 00:00:00	2026-10-22 21:39:59.782	2026-10-22 21:39:59.782	\N	ACTIVE	2020-03-15	\N
cmvk2e10v00bu10qocjrna6gx	Inaya	Hemmit	FEMALE	2013-03-16 00:00:00	2026-10-22 21:39:59.791	2026-10-22 21:39:59.791	\N	ACTIVE	2026-10-22	\N
cmvk2e11500bx10qoey8wmotp	Jounaid	Hemmit	MALE	2015-10-25 00:00:00	2026-10-22 21:39:59.801	2026-10-22 21:39:59.801	\N	ACTIVE	2022-03-05	\N
cmvk2e11d00c010qoryncqogm	Maysae	Abbou	FEMALE	2006-08-15 00:00:00	2026-10-22 21:39:59.809	2026-10-22 21:39:59.809	\N	ACTIVE	2026-10-22	\N
cmvk2e11m00c310qoopdaoqx8	Sumaya	Abdi	FEMALE	2014-06-10 00:00:00	2026-10-22 21:39:59.818	2026-10-22 21:39:59.818	\N	ACTIVE	2023-04-16	\N
cmvk2e11s00c610qo5ocm5vo0	Hamza	Abdi	MALE	2011-04-27 00:00:00	2026-10-22 21:39:59.824	2026-10-22 21:39:59.824	\N	ACTIVE	2026-10-11	\N
cmvk2e11y00c910qoplfuiyvr	Souhajb	Assou	MALE	2017-09-27 00:00:00	2026-10-22 21:39:59.83	2026-10-22 21:39:59.83	\N	ACTIVE	2024-01-13	\N
cmvk2e12800cc10qouya3fezi	Jounajd	Ouadou	MALE	2018-01-24 00:00:00	2026-10-22 21:39:59.84	2026-10-22 21:39:59.84	\N	ACTIVE	2024-01-13	\N
cmvk2e12e00cf10qosb0eh1aq	Rayan Nouri	Ouadou	MALE	2019-02-19 00:00:00	2026-10-22 21:39:59.846	2026-10-22 21:39:59.846	\N	ACTIVE	2025-11-15	\N
cmvk2e12q00ci10qoual19fsm	Inssaf	Elmousaoui	FEMALE	2017-07-30 00:00:00	2026-10-22 21:39:59.858	2026-10-22 21:39:59.858	\N	ACTIVE	2023-03-04	\N
cmvk2e12y00cl10qok0tp3x9k	Isra	Elmousaoui	FEMALE	2019-08-19 00:00:00	2026-10-22 21:39:59.866	2026-10-22 21:39:59.866	\N	ACTIVE	2023-03-04	\N
cmvk2e13600co10qofwnaqw2z	Rayan	El Maadouri	MALE	2020-03-06 00:00:00	2026-10-22 21:39:59.874	2026-10-22 21:39:59.874	\N	ACTIVE	2026-10-11	\N
cmvk2e13e00cr10qox5qbg0cz	Chaimaa	Sabti	FEMALE	2015-06-17 00:00:00	2026-10-22 21:39:59.882	2026-10-22 21:39:59.882	\N	ACTIVE	2024-01-14	\N
cmvk2e13l00cu10qoti1pe8e6	Rouayda	Sabti	FEMALE	2013-04-14 00:00:00	2026-10-22 21:39:59.89	2026-10-22 21:39:59.89	\N	ACTIVE	2024-01-13	\N
cmvk2e0oi007y10qo7g8zg9md	Youssef	Bourarach	MALE	2020-08-21 00:00:00	2026-10-22 21:39:59.346	2026-10-23 10:04:36.415	/uploads/students/83092b3d-6e36-4e88-a865-4a097e942d9a.png	ACTIVE	2023-03-04	\N
cmvk2e13w00cx10qo8dkntsp3	Tasnim	Bokhachkhach	FEMALE	2020-08-02 00:00:00	2026-10-22 21:39:59.9	2026-10-22 21:39:59.9	\N	ACTIVE	2026-10-11	\N
cmvk2e14400d010qoperb2tqj	Safouan	Zankoua	MALE	2018-03-18 00:00:00	2026-10-22 21:39:59.908	2026-10-22 21:39:59.908	\N	ACTIVE	2026-10-17	\N
cmvk2e14c00d310qoag2wsgyp	Issam	El Bounayi	MALE	2018-12-16 00:00:00	2026-10-22 21:39:59.916	2026-10-22 21:39:59.916	\N	ACTIVE	2024-01-13	\N
cmvk2e14k00d610qob0botcsz	Anouar	Moussi	MALE	2019-11-17 00:00:00	2026-10-22 21:39:59.924	2026-10-22 21:39:59.924	\N	ACTIVE	2026-10-09	\N
cmvk2e14v00d910qojo53f9k3	Amira	Ikken	FEMALE	2014-04-18 00:00:00	2026-10-22 21:39:59.935	2026-10-22 21:39:59.935	\N	ACTIVE	2026-10-22	\N
cmvk2e15700dc10qoiwgsj8f9	Malak	Ikken	FEMALE	2014-04-18 00:00:00	2026-10-22 21:39:59.947	2026-10-22 21:39:59.947	\N	ACTIVE	2026-10-22	\N
cmvk2e15e00df10qoad1n2rjx	Junaid	Asfad	MALE	2018-01-25 00:00:00	2026-10-22 21:39:59.955	2026-10-22 21:39:59.955	\N	ACTIVE	2025-11-16	\N
cmvk2e15o00di10qo657spol2	Rayaan	Asfad	MALE	2012-11-23 00:00:00	2026-10-22 21:39:59.964	2026-10-22 21:39:59.964	\N	ACTIVE	2026-10-22	\N
cmvk2e16200dl10qobzwefbsi	Rodaina	Asfad	FEMALE	2016-10-07 00:00:00	2026-10-22 21:39:59.978	2026-10-22 21:39:59.978	\N	ACTIVE	2025-11-16	\N
cmvk2e16700do10qoked9sudv	Muhammad Omar	KhaddamAllah	MALE	2013-09-23 00:00:00	2026-10-22 21:39:59.983	2026-10-22 21:39:59.983	\N	ACTIVE	2025-09-14	\N
cmvk2e16h00dr10qotnvucg70	Rayan	KhaddamAllah	MALE	2016-08-30 00:00:00	2026-10-22 21:39:59.993	2026-10-22 21:39:59.993	\N	ACTIVE	2025-09-14	\N
cmvk2e16w00du10qoskeyh0lb	Intissar	Elmonjed	FEMALE	2018-12-02 00:00:00	2026-10-22 21:40:00.008	2026-10-22 21:40:00.008	\N	ACTIVE	2026-10-22	\N
cmvk2e17u00dx10qonhsbuina	Adam	Zoundri	MALE	2016-01-01 00:00:00	2026-10-22 21:40:00.042	2026-10-22 21:40:00.042	\N	ACTIVE	2026-10-22	\N
cmvk2e18k00e010qokp92c4cf	Nouh	Azaroual	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.068	2026-10-22 21:40:00.068	\N	ACTIVE	2026-10-22	\N
cmvk2e19600e310qoc9g43cye	Adam	Azaroual	MALE	2021-08-25 00:00:00	2026-10-22 21:40:00.09	2026-10-22 21:40:00.09	\N	ACTIVE	2026-10-11	\N
cmvk2e19m00e610qovhbftiyr	Ishak-Amar	Bendriss	MALE	2016-06-28 00:00:00	2026-10-22 21:40:00.106	2026-10-22 21:40:00.106	\N	ACTIVE	2022-11-05	\N
cmvk2e1af00e910qoj9m97yrh	Jouwayriya	Bendriss	FEMALE	2016-06-28 00:00:00	2026-10-22 21:40:00.135	2026-10-22 21:40:00.135	\N	ACTIVE	2026-10-22	\N
cmvk2e1c800ec10qofadi7fwm	Oumaima	Bendriss	FEMALE	2016-06-28 00:00:00	2026-10-22 21:40:00.2	2026-10-22 21:40:00.2	\N	ACTIVE	2026-10-22	\N
cmvk2e1d700ef10qoj7lafdi6	Nour	Azeroual	FEMALE	2020-04-30 00:00:00	2026-10-22 21:40:00.235	2026-10-22 21:40:00.235	\N	ACTIVE	2025-10-04	\N
cmvk2e1dq00ei10qo1e12120n	Mohamed	Azeroual	MALE	2017-09-25 00:00:00	2026-10-22 21:40:00.254	2026-10-22 21:40:00.254	\N	ACTIVE	2025-10-04	\N
cmvk2e1hr00el10qorft4v8hb	Nousayba	Ahamiane	FEMALE	2016-01-04 00:00:00	2026-10-22 21:40:00.399	2026-10-22 21:40:00.399	\N	ACTIVE	2022-03-05	\N
cmvk2e1i300eo10qoactgc813	Hafsa	el Abbassi	FEMALE	2020-06-21 00:00:00	2026-10-22 21:40:00.411	2026-10-22 21:40:00.411	\N	ACTIVE	2025-10-04	\N
cmvk2e1ib00er10qo0dxjt8q4	Hajar	el Abbassi	FEMALE	2021-07-18 00:00:00	2026-10-22 21:40:00.419	2026-10-22 21:40:00.419	\N	ACTIVE	2026-10-11	\N
cmvk2e1ii00eu10qouggo8ohv	Nizar	Zaoumi	MALE	2017-08-12 00:00:00	2026-10-22 21:40:00.426	2026-10-22 21:40:00.426	\N	ACTIVE	2024-11-02	\N
cmvk2e1iq00ex10qolv7h3znf	Adam	Bakkich	FEMALE	2010-02-04 00:00:00	2026-10-22 21:40:00.434	2026-10-22 21:40:00.434	\N	ACTIVE	2026-10-22	\N
cmvk2e1iw00f010qouldd0whw	Noussair	El abassi	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.44	2026-10-22 21:40:00.44	\N	ACTIVE	2026-10-22	\N
cmvk2e1j300f310qokwlctw42	Oumayer	El Abbassi	MALE	2016-10-21 00:00:00	2026-10-22 21:40:00.447	2026-10-22 21:40:00.447	\N	ACTIVE	2022-11-05	\N
cmvk2e1j700f610qoqieb3sy7	Mohamed	El Harouachi	MALE	2009-05-16 00:00:00	2026-10-22 21:40:00.451	2026-10-22 21:40:00.451	\N	ACTIVE	2026-10-22	\N
cmvk2e1jb00f910qoxwwq9wec	Salama	Bouabid	FEMALE	2013-03-28 00:00:00	2026-10-22 21:40:00.455	2026-10-22 21:40:00.455	\N	ACTIVE	2026-10-22	\N
cmvk2e1jf00fc10qodoqzhons	Jounaid	Alhou	MALE	2015-12-24 00:00:00	2026-10-22 21:40:00.459	2026-10-22 21:40:00.459	\N	ACTIVE	2020-01-03	\N
cmvk2e1jn00ff10qo6b20bk1d	Firdaous	Ibrahimi	FEMALE	2017-06-09 00:00:00	2026-10-22 21:40:00.467	2026-10-22 21:40:00.467	\N	ACTIVE	2023-10-14	\N
cmvk2e1js00fi10qoblhlylqf	Maroua	Ibrahimi	FEMALE	2015-05-05 00:00:00	2026-10-22 21:40:00.472	2026-10-22 21:40:00.472	\N	ACTIVE	2026-10-22	\N
cmvk2e1k100fl10qohvdgqlc8	Mohamed Amine	Safi	MALE	2018-02-23 00:00:00	2026-10-22 21:40:00.481	2026-10-22 21:40:00.481	\N	ACTIVE	2026-10-22	\N
cmvk2e1ku00fo10qodpfpq0ib	Sami	Akbiach	MALE	2015-02-01 00:00:00	2026-10-22 21:40:00.51	2026-10-22 21:40:00.51	\N	ACTIVE	2026-10-22	\N
cmvk2e1l900fr10qo6euq3n2l	Nour	Barrani	FEMALE	2020-09-30 00:00:00	2026-10-22 21:40:00.526	2026-10-22 21:40:00.526	\N	ACTIVE	2026-10-22	\N
cmvk2e1lh00fu10qodi34nlo8	Inaya	Bouhjira	FEMALE	2017-10-08 00:00:00	2026-10-22 21:40:00.533	2026-10-22 21:40:00.533	\N	ACTIVE	2023-03-04	\N
cmvk2e1ln00fx10qob4gtsuxb	Lina	Bouhjira	FEMALE	2021-03-18 00:00:00	2026-10-22 21:40:00.539	2026-10-22 21:40:00.539	\N	ACTIVE	2026-10-10	\N
cmvk2e1lz00g010qor4spgnh3	Zakaria	Kamar/Azouzi	MALE	2014-12-11 00:00:00	2026-10-22 21:40:00.551	2026-10-22 21:40:00.551	\N	ACTIVE	2026-10-22	\N
cmvk2e1m500g310qogosi93ht	Jawhara	Zaim	FEMALE	2017-11-08 00:00:00	2026-10-22 21:40:00.557	2026-10-22 21:40:00.557	\N	ACTIVE	2023-10-14	\N
cmvk2e1mc00g610qokmrvsajm	Inaya	Darkaoui	FEMALE	2018-05-16 00:00:00	2026-10-22 21:40:00.564	2026-10-22 21:40:00.564	\N	ACTIVE	2023-10-14	\N
cmvk2e1mh00g910qof9zdk9s0	Israe	Darkaoui	FEMALE	2018-05-16 00:00:00	2026-10-22 21:40:00.569	2026-10-22 21:40:00.569	\N	ACTIVE	2023-10-14	\N
cmvk2e1n100gc10qoy5htea82	Hafsa	Tajjioui	FEMALE	2014-06-15 00:00:00	2026-10-22 21:40:00.589	2026-10-22 21:40:00.589	\N	ACTIVE	2026-10-22	\N
cmvk2e1n800gf10qopkdmfra7	Houdayfa	Tajjioui	MALE	2016-02-15 00:00:00	2026-10-22 21:40:00.596	2026-10-22 21:40:00.596	\N	ACTIVE	2026-10-22	\N
cmvk2e1nj00gi10qo6ptkzrjw	Naoufal	El Bouayadi	MALE	2018-07-09 00:00:00	2026-10-22 21:40:00.607	2026-10-22 21:40:00.607	\N	ACTIVE	2024-04-06	\N
cmvk2e1nq00gl10qok2h5e8h8	Nassim	El Bouayadi	MALE	2012-12-01 00:00:00	2026-10-22 21:40:00.614	2026-10-22 21:40:00.614	\N	ACTIVE	2019-09-05	\N
cmvk2e1nz00go10qosv3meac4	Nour	El Bouayadi	MALE	2015-02-27 00:00:00	2026-10-22 21:40:00.623	2026-10-22 21:40:00.623	\N	ACTIVE	2020-01-01	\N
cmvk2e1o600gr10qourhjh39x	Jaber	Erazzi	MALE	2017-09-15 00:00:00	2026-10-22 21:40:00.63	2026-10-22 21:40:00.63	\N	ACTIVE	2023-10-14	\N
cmvk2e1oc00gu10qoce37z8sn	Wail	Erazzi	MALE	2020-07-25 00:00:00	2026-10-22 21:40:00.636	2026-10-22 21:40:00.636	\N	ACTIVE	2026-10-10	\N
cmvk2e1oh00gx10qobcvz39da	Amira	Sakour	FEMALE	1900-01-01 00:00:00	2026-10-22 21:40:00.641	2026-10-22 21:40:00.641	\N	ACTIVE	2026-10-22	\N
cmvk2e1on00h010qoznju2wm0	Obaid	Sakour	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.647	2026-10-22 21:40:00.647	\N	ACTIVE	2026-10-22	\N
cmvk2e1p000h310qoy77ot97c	Izzat	Ben taleb	FEMALE	2018-09-17 00:00:00	2026-10-22 21:40:00.66	2026-10-22 21:40:00.66	\N	ACTIVE	2024-01-13	\N
cmvk2e1pb00h610qohomlnt99	Mohamed	Ben taleb	MALE	2014-08-15 00:00:00	2026-10-22 21:40:00.671	2026-10-22 21:40:00.671	\N	ACTIVE	2022-11-05	\N
cmvk2e1pn00h910qo26r9kzvv	Lyana	BOULALMA	FEMALE	2015-02-27 00:00:00	2026-10-22 21:40:00.683	2026-10-22 21:40:00.683	\N	ACTIVE	2023-10-14	\N
cmvk2e1pv00hc10qo70s7eud4	Nour	Ettahri	FEMALE	2019-11-28 00:00:00	2026-10-22 21:40:00.691	2026-10-22 21:40:00.691	\N	ACTIVE	2026-10-22	\N
cmvk2e1qc00hf10qolumdg9rh	Ajman	Alkhouli	MALE	2016-07-18 00:00:00	2026-10-22 21:40:00.708	2026-10-22 21:40:00.708	\N	ACTIVE	2024-01-13	\N
cmvk2e1ql00hi10qomvtqdm69	Mohammed	Alkhouli	MALE	2020-12-14 00:00:00	2026-10-22 21:40:00.717	2026-10-22 21:40:00.717	\N	ACTIVE	2026-10-10	\N
cmvk2e1qu00hl10qol44lbi9l	Jihane	Kassmi	FEMALE	2019-01-21 00:00:00	2026-10-22 21:40:00.726	2026-10-22 21:40:00.726	\N	ACTIVE	2024-11-02	\N
cmvk2e1r300ho10qoohbq1j9b	Zayd	Chentouf	MALE	2019-02-04 00:00:00	2026-10-22 21:40:00.735	2026-10-22 21:40:00.735	\N	ACTIVE	2026-10-22	\N
cmvk2e1rl00hr10qoln6c107h	Maysa	Bouhjira	FEMALE	2017-06-18 00:00:00	2026-10-22 21:40:00.753	2026-10-22 21:40:00.753	\N	ACTIVE	2026-10-22	\N
cmvk2e1s000hu10qovy3i6l19	Safouane	Bouhjira	MALE	2015-12-10 00:00:00	2026-10-22 21:40:00.769	2026-10-22 21:40:00.769	\N	ACTIVE	2026-10-22	\N
cmvk2e1t400hx10qody17xdw5	Aya	Talhaoui	FEMALE	2016-03-08 00:00:00	2026-10-22 21:40:00.808	2026-10-22 21:40:00.808	\N	ACTIVE	2026-10-22	\N
cmvk2e1tk00i010qonijxikwe	Yousra	Aissaoui	FEMALE	2019-10-30 00:00:00	2026-10-22 21:40:00.824	2026-10-22 21:40:00.824	\N	ACTIVE	2026-10-22	\N
cmvk2e1tz00i310qoo67eujha	Mariam	El Kouskous	FEMALE	2017-04-27 00:00:00	2026-10-22 21:40:00.839	2026-10-22 21:40:00.839	\N	ACTIVE	2023-10-14	\N
cmvk2e1ug00i610qo7n6jek1u	Adam	Elfaraousi	MALE	2018-06-28 00:00:00	2026-10-22 21:40:00.856	2026-10-22 21:40:00.856	\N	ACTIVE	2024-01-13	\N
cmvk2e1ut00i910qocffcgu3k	Zakaria	El Hajari	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.869	2026-10-22 21:40:00.869	\N	ACTIVE	2026-10-22	\N
cmvk2e1v700ic10qont684rtb	Jenat	Bouhdifi/Kala	FEMALE	2015-09-12 00:00:00	2026-10-22 21:40:00.883	2026-10-22 21:40:00.883	\N	ACTIVE	2023-10-14	\N
cmvk2e1vn00if10qoa5gn8yl7	Nouraine	Bouhdifi/Kala	FEMALE	2015-09-12 00:00:00	2026-10-22 21:40:00.899	2026-10-22 21:40:00.899	\N	ACTIVE	2023-10-14	\N
cmvk2e1vx00ii10qoh5v4lhfn	Amir	Zankoua	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.909	2026-10-22 21:40:00.909	\N	ACTIVE	2025-10-01	\N
cmvk2e1w500il10qoq9493xwt	Mohamed	Zankoua	MALE	1900-01-01 00:00:00	2026-10-22 21:40:00.917	2026-10-22 21:40:00.917	\N	ACTIVE	2025-10-01	\N
cmvk2e1wd00io10qool1z6725	Rofaida	Zankoua	FEMALE	2014-01-11 00:00:00	2026-10-22 21:40:00.925	2026-10-22 21:40:00.925	\N	ACTIVE	2026-10-22	\N
cmvk2e1wl00ir10qozqju3tjf	Jassine	El Jaghaoui	MALE	2014-11-27 00:00:00	2026-10-22 21:40:00.933	2026-10-22 21:40:00.933	\N	ACTIVE	2022-03-05	\N
cmvk2e1wx00iu10qocetv78hy	Aymane	Kadioui	MALE	2018-03-28 00:00:00	2026-10-22 21:40:00.946	2026-10-22 21:40:00.946	\N	ACTIVE	2021-04-03	\N
cmvk2e1xx00ix10qo5qpio2jr	Rayan	Kadioui	MALE	2015-07-01 00:00:00	2026-10-22 21:40:00.981	2026-10-22 21:40:00.981	\N	ACTIVE	2021-04-03	\N
cmvk2e1ya00j010qocpb43z1p	Abdourahmaan	Belhadi	MALE	2016-04-07 00:00:00	2026-10-22 21:40:00.994	2026-10-22 21:40:00.994	\N	ACTIVE	2022-03-05	\N
cmvk2e1yj00j310qo2h047zs8	Imane	Belhadi	FEMALE	2009-08-27 00:00:00	2026-10-22 21:40:01.003	2026-10-22 21:40:01.003	\N	ACTIVE	2026-10-22	\N
cmvk2e1yv00j610qo8qsw1g91	Bilal	Masouti	MALE	2018-09-23 00:00:00	2026-10-22 21:40:01.015	2026-10-22 21:40:01.015	\N	ACTIVE	2024-01-13	\N
cmvk2e1z300j910qoprojkzkj	Soufiane	Aarbi	MALE	2018-04-23 00:00:00	2026-10-22 21:40:01.023	2026-10-22 21:40:01.023	\N	ACTIVE	2024-01-13	\N
cmvk2e1zd00jc10qoekwj6a2m	Amanah	Aarbi	FEMALE	2020-12-06 00:00:00	2026-10-22 21:40:01.033	2026-10-22 21:40:01.033	\N	ACTIVE	2026-09-19	\N
cmvk2e1zq00jf10qon2rqyrl1	Anas	Maryaoui	MALE	2018-02-25 00:00:00	2026-10-22 21:40:01.046	2026-10-22 21:40:01.046	\N	ACTIVE	2023-10-15	\N
cmvk2e20200ji10qoprpn0uqy	Hassan	Alali	MALE	2011-01-07 00:00:00	2026-10-22 21:40:01.058	2026-10-22 21:40:01.058	\N	ACTIVE	2023-10-15	\N
cmvk2e20e00jl10qow8e1yiow	Lajine	Alali	FEMALE	2015-07-01 00:00:00	2026-10-22 21:40:01.07	2026-10-22 21:40:01.07	\N	ACTIVE	2023-10-21	\N
cmvk2e20p00jo10qoxqql70bo	Amaani	Boudount	FEMALE	2016-09-06 00:00:00	2026-10-22 21:40:01.081	2026-10-22 21:40:01.081	\N	ACTIVE	2026-10-22	\N
cmvk2e20y00jr10qoh8pjk1e2	Youssef	Azrioual	MALE	2019-09-22 00:00:00	2026-10-22 21:40:01.09	2026-10-22 21:40:01.09	\N	ACTIVE	2025-08-11	\N
cmvk2e21700ju10qo6yrh8nn9	Imraan	El hadri	MALE	2016-08-02 00:00:00	2026-10-22 21:40:01.099	2026-10-22 21:40:01.099	\N	ACTIVE	2022-03-05	\N
cmvk2e21i00jx10qo09v4vqf9	Mohamed Amine	El hadri	MALE	2014-08-02 00:00:00	2026-10-22 21:40:01.11	2026-10-22 21:40:01.11	\N	ACTIVE	2022-03-05	\N
cmvk2e21u00k010qooq70hbjl	youssef	El hadri	MALE	2014-08-02 00:00:00	2026-10-22 21:40:01.122	2026-10-22 21:40:01.122	\N	ACTIVE	2026-10-22	\N
cmvk2e22300k310qoaweja2qk	Maysa	Jaghaoui	FEMALE	2014-08-17 00:00:00	2026-10-22 21:40:01.132	2026-10-22 21:40:01.132	\N	ACTIVE	2026-10-22	\N
cmvk2e22c00k610qoezyj455i	Wisal	Jaghaoui	FEMALE	2016-01-01 00:00:00	2026-10-22 21:40:01.14	2026-10-22 21:40:01.14	\N	ACTIVE	2026-10-22	\N
cmvk2e22j00k910qobkyi27z6	Hafsa	Zaadoudi	FEMALE	2016-11-21 00:00:00	2026-10-22 21:40:01.147	2026-10-22 21:40:01.147	\N	ACTIVE	2026-10-22	\N
cmvk2e22q00kc10qomrp1weci	Inaya	Boussadkat	FEMALE	2013-06-07 00:00:00	2026-10-22 21:40:01.154	2026-10-22 21:40:01.154	\N	ACTIVE	2023-03-04	\N
cmvk2e23200kf10qo6q0e2tic	Israa	Boussadkat	FEMALE	2016-10-11 00:00:00	2026-10-22 21:40:01.166	2026-10-22 21:40:01.166	\N	ACTIVE	2021-11-06	\N
cmvk2e23m00ki10qoulyqnae4	Adam	Ben Taleb	MALE	2015-02-10 00:00:00	2026-10-22 21:40:01.186	2026-10-22 21:40:01.186	\N	ACTIVE	2026-10-22	\N
cmvk2e24100kl10qorjekwidz	Omar	Ben Taleb	MALE	1900-01-01 00:00:00	2026-10-22 21:40:01.201	2026-10-22 21:40:01.201	\N	ACTIVE	2025-05-24	\N
cmvk2e24f00ko10qowjirabgu	Ilyas	Bitich	MALE	2018-11-08 00:00:00	2026-10-22 21:40:01.215	2026-10-22 21:40:01.215	\N	ACTIVE	2024-01-06	\N
cmvk2e24s00kr10qoea9lhkmq	Jana	Lafkiri	FEMALE	2019-06-30 00:00:00	2026-10-22 21:40:01.228	2026-10-22 21:40:01.228	\N	ACTIVE	2025-11-15	\N
cmvk2e25200ku10qofc0p978p	Esrae	Tizra	FEMALE	2019-10-18 00:00:00	2026-10-22 21:40:01.238	2026-10-22 21:40:01.238	\N	ACTIVE	2026-10-22	\N
cmvk2e25r00kx10qobmpq91u6	Mourad	Laaboudi	MALE	2014-01-13 00:00:00	2026-10-22 21:40:01.263	2026-10-22 21:40:01.263	\N	ACTIVE	2024-04-06	\N
cmvk2e26400l010qoq73zmzm7	Wiaem	Laaboudi	MALE	2012-12-09 00:00:00	2026-10-22 21:40:01.276	2026-10-22 21:40:01.276	\N	ACTIVE	2021-11-06	\N
cmvk2e26d00l310qo5tfcm5iv	Amira	Adarghal	FEMALE	2018-10-19 00:00:00	2026-10-22 21:40:01.285	2026-10-22 21:40:01.285	\N	ACTIVE	2024-04-06	\N
cmvk2e26q00l610qonpxspp6x	Adam	Talhi	MALE	2015-11-03 00:00:00	2026-10-22 21:40:01.298	2026-10-22 21:40:01.298	\N	ACTIVE	2024-04-06	\N
cmvk2e27100l910qocx3ex4iz	Ilaaf	Talhi	FEMALE	2014-07-26 00:00:00	2026-10-22 21:40:01.309	2026-10-22 21:40:01.309	\N	ACTIVE	2024-04-06	\N
cmvk2e27h00lc10qo7gh0hsiq	Junayd	Naanai	MALE	2013-02-15 00:00:00	2026-10-22 21:40:01.325	2026-10-22 21:40:01.325	\N	ACTIVE	2024-04-06	\N
cmvk2e27w00lf10qom9p26wiz	Amar	Saloum Maha Haj Ahmed	MALE	2016-01-31 00:00:00	2026-10-22 21:40:01.34	2026-10-22 21:40:01.34	\N	ACTIVE	2024-04-06	\N
cmvk2e28200li10qovdat671z	Maais	Saloum Maha Haj Ahmed	MALE	2018-01-20 00:00:00	2026-10-22 21:40:01.346	2026-10-22 21:40:01.346	\N	ACTIVE	2024-04-06	\N
cmvk2e28e00ll10qowlkawpgt	Amir	Aachboun	MALE	2013-02-14 00:00:00	2026-10-22 21:40:01.358	2026-10-22 21:40:01.358	\N	ACTIVE	2021-02-13	\N
cmvk2e28s00lo10qo7e2bp1o3	Hicham	ElMakaoui	MALE	2013-01-23 00:00:00	2026-10-22 21:40:01.372	2026-10-22 21:40:01.372	\N	ACTIVE	2026-10-22	\N
cmvk2e29400lr10qocjdvc6b6	Nassira	Darrazi	FEMALE	2011-07-30 00:00:00	2026-10-22 21:40:01.384	2026-10-22 21:40:01.384	\N	ACTIVE	2024-04-06	\N
cmvk2e29b00lu10qog7rpgkcr	Soulaiman	Ouazil	MALE	2017-05-14 00:00:00	2026-10-22 21:40:01.391	2026-10-22 21:40:01.391	\N	ACTIVE	2024-04-06	\N
cmvk2e29m00lx10qo101embvd	Aya	Ousrout	FEMALE	2019-02-09 00:00:00	2026-10-22 21:40:01.402	2026-10-22 21:40:01.402	\N	ACTIVE	2025-11-16	\N
cmvk2e2ac00m010qo5ptppc5o	Mohamed Ali	Tamaoui	MALE	2013-12-19 00:00:00	2026-10-22 21:40:01.428	2026-10-22 21:40:01.428	\N	ACTIVE	2024-04-06	\N
cmvk2e2bg00m310qo6pqqxpjl	Nour	Tamaoui	FEMALE	2012-01-27 00:00:00	2026-10-22 21:40:01.468	2026-10-22 21:40:01.468	\N	ACTIVE	2024-04-06	\N
cmvk2e2c200m610qoor5xfdo6	Yassine	El Madaghri/El adoui	MALE	2015-08-10 00:00:00	2026-10-22 21:40:01.49	2026-10-22 21:40:01.49	\N	ACTIVE	2025-05-24	\N
cmvk2e2cd00m910qon6uxqyar	Samira	Mustapha	FEMALE	1900-01-01 00:00:00	2026-10-22 21:40:01.501	2026-10-22 21:40:01.501	\N	ACTIVE	2026-10-22	\N
cmvk2e2cr00mc10qobys4bvnw	Mohamed	Douiri	MALE	2016-03-02 00:00:00	2026-10-22 21:40:01.515	2026-10-22 21:40:01.515	\N	ACTIVE	2026-10-22	\N
cmvk2e2d700mf10qoox604aky	Safouan	Aissaoui/Kasmi	MALE	2019-04-25 00:00:00	2026-10-22 21:40:01.531	2026-10-22 21:40:01.531	\N	ACTIVE	2026-10-22	\N
cmvk2e2dk00mi10qob19yp1hd	Imane	Abdelli	FEMALE	2019-04-27 00:00:00	2026-10-22 21:40:01.544	2026-10-22 21:40:01.544	\N	ACTIVE	2025-11-22	\N
cmvk2e2e600ml10qoxvm5sc2r	Maysae	Abdelli	FEMALE	2019-01-13 00:00:00	2026-10-22 21:40:01.566	2026-10-22 21:40:01.566	\N	ACTIVE	2025-11-22	\N
cmvk2e2eg00mo10qokzbvud3z	Nadir	Tahiry	MALE	2018-12-29 00:00:00	2026-10-22 21:40:01.576	2026-10-22 21:40:01.576	\N	ACTIVE	2025-11-30	\N
cmvk2e2fa00mr10qok97kyvqg	Ilham	Bouabid	FEMALE	2016-06-30 00:00:00	2026-10-22 21:40:01.606	2026-10-22 21:40:01.606	\N	ACTIVE	2026-10-22	\N
cmvk2e2fr00mu10qohapjlfv8	Ishaq	Masnaoui	MALE	2019-12-01 00:00:00	2026-10-22 21:40:01.623	2026-10-22 21:40:01.623	\N	ACTIVE	2026-10-22	\N
cmvk2e2ga00mx10qoxq9y911o	Aya	Karoumi (meester)	FEMALE	1900-01-01 00:00:00	2026-10-22 21:40:01.642	2026-10-22 21:40:01.642	\N	ACTIVE	2022-11-05	\N
cmvk2e2gp00n010qop5winihn	Younes	Karoumi (meester)	MALE	1900-01-01 00:00:00	2026-10-22 21:40:01.657	2026-10-22 21:40:01.657	\N	ACTIVE	2026-10-22	\N
cmvk2e2h100n310qoxejneoi1	Imraan	El Ouarradi	MALE	2016-12-26 00:00:00	2026-10-22 21:40:01.669	2026-10-22 21:40:01.669	\N	ACTIVE	2026-10-22	\N
cmvk2e2he00n610qoqjycfgkw	Adam	Ajaoud	MALE	2012-02-06 00:00:00	2026-10-22 21:40:01.682	2026-10-22 21:40:01.682	\N	ACTIVE	2026-10-22	\N
cmvk2e2hs00n910qo4wyqhz7b	Asmae	Aissaoui	FEMALE	2012-07-30 00:00:00	2026-10-22 21:40:01.696	2026-10-22 21:40:01.696	\N	ACTIVE	2026-10-22	\N
cmvk2e2i200nc10qoy0x32f8q	Ikram	Hitou	FEMALE	2016-10-26 00:00:00	2026-10-22 21:40:01.706	2026-10-22 21:40:01.706	\N	ACTIVE	2026-10-22	\N
cmvk2e2ie00nf10qoz6ai0dmm	Nissrine	Ramdani	FEMALE	1900-01-01 00:00:00	2026-10-22 21:40:01.718	2026-10-22 21:40:01.718	\N	ACTIVE	2026-10-22	\N
cmvk2e2iw00ni10qoywbqnai5	Yasmin	Ramdani	FEMALE	1900-01-01 00:00:00	2026-10-22 21:40:01.736	2026-10-22 21:40:01.736	\N	ACTIVE	2024-01-13	\N
cmvk2e2ja00nl10qoc5fvj7au	Youssra	Balilou	FEMALE	2017-11-05 00:00:00	2026-10-22 21:40:01.75	2026-10-22 21:40:01.75	\N	ACTIVE	2026-10-22	\N
cmvk2e2kl00no10qo92hh1f3b	Ibrahim	Kissami	MALE	2015-05-31 00:00:00	2026-10-22 21:40:01.797	2026-10-22 21:40:01.797	\N	ACTIVE	2025-11-30	\N
cmvk2e2m000nr10qo7irsk46h	Amatu Allah	Belhadi	FEMALE	2017-02-08 00:00:00	2026-10-22 21:40:01.848	2026-10-22 21:40:01.848	\N	ACTIVE	2026-10-22	\N
cmvk2e2mz00nu10qoahpq6en1	Intesar	Belhadi	FEMALE	2010-05-27 00:00:00	2026-10-22 21:40:01.883	2026-10-22 21:40:01.883	\N	ACTIVE	2026-10-22	\N
cmvk2e2nv00nx10qoicxjuufx	Noussaiba	Belhadi	FEMALE	2014-02-11 00:00:00	2026-10-22 21:40:01.915	2026-10-22 21:40:01.915	\N	ACTIVE	2026-10-22	\N
cmvk2e2oa00o010qo3nqbcmwy	Wassim	Zaydi	MALE	2020-02-21 00:00:00	2026-10-22 21:40:01.93	2026-10-22 21:40:01.93	\N	ACTIVE	2025-11-30	\N
cmvk2e2ox00o310qo1fp7jf9k	Wiam	Zaydi	FEMALE	2020-02-21 00:00:00	2026-10-22 21:40:01.953	2026-10-22 21:40:01.953	\N	ACTIVE	2026-10-22	\N
cmvk2e2pd00o610qodd2hmfys	Adam	Bachiri	MALE	2014-12-09 00:00:00	2026-10-22 21:40:01.969	2026-10-22 21:40:01.969	\N	ACTIVE	2026-10-22	\N
cmvk2e2pq00o910qo2730l4yw	Nawfal	Doudalla	MALE	2014-09-23 00:00:00	2026-10-22 21:40:01.982	2026-10-22 21:40:01.982	\N	ACTIVE	2022-11-05	\N
cmvk2e2q300oc10qot2xa2ayx	Marwan	Hamdi	MALE	2020-01-01 00:00:00	2026-10-22 21:40:01.995	2026-10-22 21:40:01.995	\N	ACTIVE	2026-10-22	\N
cmvk2e2qi00of10qob9mtp95m	Selma	Sakkour	FEMALE	2005-09-19 00:00:00	2026-10-22 21:40:02.01	2026-10-22 21:40:02.01	\N	ACTIVE	2025-01-18	\N
cmvk2e2qv00oi10qotvkb5gwr	Zakaria	El Kachouti	MALE	2019-02-08 00:00:00	2026-10-22 21:40:02.023	2026-10-22 21:40:02.023	\N	ACTIVE	2026-10-22	\N
cmvk2e2r400ol10qo3w3iir2x	Oumyra	Rahou	FEMALE	2017-06-10 00:00:00	2026-10-22 21:40:02.032	2026-10-22 21:40:02.032	\N	ACTIVE	2026-10-22	\N
cmvk2e2rf00oo10qoel5fv9j7	Moussa	Rahou	MALE	2020-11-03 00:00:00	2026-10-22 21:40:02.043	2026-10-22 21:40:02.043	\N	ACTIVE	2026-10-22	\N
cmvk2e2rs00or10qogy8fva6b	Dimba	Dya	MALE	2019-08-04 00:00:00	2026-10-22 21:40:02.056	2026-10-22 21:40:02.056	\N	ACTIVE	2026-10-22	\N
cmvk2e2s900ou10qolb7uyr4q	Hamady Mohamed	Dia	MALE	2020-11-21 00:00:00	2026-10-22 21:40:02.073	2026-10-22 21:40:02.073	\N	ACTIVE	2026-10-17	\N
cmvk2e2so00ox10qorvrpc40u	Nouaim	Boutayeb	FEMALE	2018-01-11 00:00:00	2026-10-22 21:40:02.088	2026-10-22 21:40:02.088	\N	ACTIVE	2026-10-22	\N
cmvk2e2t200p010qo7ywriqdq	Yasmine	Boutayeb	FEMALE	2013-10-02 00:00:00	2026-10-22 21:40:02.102	2026-10-22 21:40:02.102	\N	ACTIVE	2026-10-22	\N
cmvk2e2tc00p310qoefmn8evv	Iyas	El Abbassi	MALE	2020-07-07 00:00:00	2026-10-22 21:40:02.112	2026-10-22 21:40:02.112	\N	ACTIVE	2024-01-13	\N
cmvk2e2ts00p610qosvzydygr	Oubada	Alyakoubi	MALE	2018-06-25 00:00:00	2026-10-22 21:40:02.128	2026-10-22 21:40:02.128	\N	ACTIVE	2026-10-22	\N
cmvk2e2u300p910qoppseznc5	Hafsae	ELyakoubi	FEMALE	2018-06-25 00:00:00	2026-10-22 21:40:02.139	2026-10-22 21:40:02.139	\N	ACTIVE	2026-10-22	\N
cmvk2e2ui00pc10qopcqo26em	Jounayd	Lahrach	FEMALE	2016-10-24 00:00:00	2026-10-22 21:40:02.154	2026-10-22 21:40:02.154	\N	ACTIVE	2026-10-22	\N
cmvk2e2vc00pf10qo3t9lj3li	Yousri	Lahrach	MALE	2020-10-27 00:00:00	2026-10-22 21:40:02.184	2026-10-22 21:40:02.184	\N	ACTIVE	2026-10-11	\N
cmvk2e2w500pi10qovwf8e6aw	Issa	Moumni	MALE	2019-03-12 00:00:00	2026-10-22 21:40:02.213	2026-10-22 21:40:02.213	\N	ACTIVE	2026-10-22	\N
cmvk2e2wt00pl10qor4zldg40	Nouh	Moumni	MALE	2017-02-26 00:00:00	2026-10-22 21:40:02.238	2026-10-22 21:40:02.238	\N	ACTIVE	2025-11-30	\N
cmvk2e2x500po10qomph1l3p6	joury	siraj	FEMALE	2015-06-15 00:00:00	2026-10-22 21:40:02.249	2026-10-22 21:40:02.249	\N	ACTIVE	2026-10-22	\N
cmvk2e2xi00pr10qoyc5wzqn7	Tulip	Siraj	FEMALE	2019-11-24 00:00:00	2026-10-22 21:40:02.262	2026-10-22 21:40:02.262	\N	ACTIVE	2026-10-22	\N
cmvk2e2xw00pu10qofmc21wia	Hind	Ouari	FEMALE	2015-08-28 00:00:00	2026-10-22 21:40:02.276	2026-10-22 21:40:02.276	\N	ACTIVE	2026-10-22	\N
cmvk2e2yc00px10qoh5przmtm	Maryam	Attalbi	FEMALE	2019-06-18 00:00:00	2026-10-22 21:40:02.292	2026-10-22 21:40:02.292	\N	ACTIVE	2025-11-30	\N
cmvk2e2yn00q010qonug7nlo4	Youssef	Attalbi	MALE	2017-03-03 00:00:00	2026-10-22 21:40:02.303	2026-10-22 21:40:02.303	\N	ACTIVE	2026-10-22	\N
cmvk2e2z200q310qobwzccw2u	Abdullah	Sbaa	MALE	2019-04-09 00:00:00	2026-10-22 21:40:02.318	2026-10-22 21:40:02.318	\N	ACTIVE	2025-11-30	\N
cmvk2e2zb00q610qopmdhaaas	Tuga	AL Khalaf	FEMALE	2019-08-11 00:00:00	2026-10-22 21:40:02.328	2026-10-22 21:40:02.328	\N	ACTIVE	2025-11-30	\N
cmvk2e30100q910qo8yqwve66	Mohamed Sabir	Aoulad l kadi	MALE	2014-12-30 00:00:00	2026-10-22 21:40:02.353	2026-10-22 21:40:02.353	\N	ACTIVE	2026-01-17	\N
cmvk2e30f00qc10qozdumo62o	Zakaria	Aoulad l Kadi	MALE	2018-05-01 00:00:00	2026-10-22 21:40:02.367	2026-10-22 21:40:02.367	\N	ACTIVE	2026-01-18	\N
cmvk2e30p00qf10qo2i71tdoy	Ammira	Fallous	FEMALE	2016-12-22 00:00:00	2026-10-22 21:40:02.378	2026-10-22 21:40:02.378	\N	ACTIVE	2026-10-22	\N
cmvk2e31200qi10qo9hc0wu8y	Safa	Essadik	FEMALE	2012-02-01 00:00:00	2026-10-22 21:40:02.39	2026-10-22 21:40:02.39	\N	ACTIVE	2026-10-22	\N
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subjects (id, "levelId", name, "sortOrder", "isActive", "createdAt", "updatedAt", description, image) FROM stdin;
cmuhik908000jb16dyg9m5nzl	cmuhhs8tp0001b16dttc1x8ci	2 القرآن الكريم	2	t	2026-09-25 22:09:43.064	2026-09-25 22:09:43.064	\N	\N
cmuhhun0m0004b16dx0abachg	cmuhhs3tw0000b16dt3vyjoxl	1 القرآن الكريم	1	t	2026-09-25 21:49:48.166	2026-10-02 20:23:49.084	Surat fatiha tot kafiroun	/uploads/subjects/516afff1-7b2b-4247-abbe-3c725cb9dfbf.jpg
cmurf6c5l0000yd6dt9ur8ke0	cmuhhshwq0002b16dmj4ohr4u	Quran 3	1	t	2026-10-02 20:32:36.873	2026-10-02 20:32:36.873	zalzala - nabaa	/uploads/subjects/6896c824-694e-4d8c-805b-ac891b220540.jpg
cmvcbh80j000n01rytqmdn90z	cmuhhs3tw0000b16dt3vyjoxl	التئسيس المتكامل رقم 1	2	t	2026-10-17 11:32:15.955	2026-10-18 05:05:19.381	من حرف ء الى حرف ج	/uploads/subjects/4545be4e-edf4-4fd8-8443-441d8dbebeb3.jpg
cmuhhu1f60003b16dfkcdtcs1	cmuhhs3tw0000b16dt3vyjoxl	الاملاء	4	t	2026-09-25 21:49:20.178	2026-10-18 05:05:46.92	الدرس الاول	/uploads/subjects/49fa4d19-3530-40fe-9b35-4d48ff0c502f.jpg
cmuzwptjp0000666da2gf1e10	cmuhhs3tw0000b16dt3vyjoxl	القاعدة النورانية	3	t	2026-10-08 19:05:48.757	2026-10-18 05:07:02.157	les 1 - 4	/uploads/subjects/2edb0866-abdf-4b88-8a63-796e2555f63c.jpg
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terms (id, name, "sortOrder", "createdAt", "updatedAt", "startMonth", "endMonth") FROM stdin;
cmuhjncbq00017g6d3glxc9oh	الدورة الأولى	1	2026-09-25 22:40:06.95	2026-10-18 05:17:14.48	9	12
cmuhjnzih00027g6dqcn26vnl	الدورة الثانية	2	2026-09-25 22:40:37.001	2026-10-18 05:17:45.27	1	3
cmuhjotxs00037g6drh9jegfr	الدورة الثالثة	3	2026-09-25 22:41:16.432	2026-10-18 05:18:10.909	4	6
\.


--
-- Data for Name: year_report_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.year_report_observations (id, "studentId", "academicYearId", body, "recordedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Verification Verification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Verification"
    ADD CONSTRAINT "Verification_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: class_comments class_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_comments
    ADD CONSTRAINT class_comments_pkey PRIMARY KEY (id);


--
-- Name: class_session_links class_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_session_links
    ADD CONSTRAINT class_session_links_pkey PRIMARY KEY (id);


--
-- Name: class_sessions class_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_sessions
    ADD CONSTRAINT class_sessions_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: donation_payment_logs donation_payment_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payment_logs
    ADD CONSTRAINT donation_payment_logs_pkey PRIMARY KEY (id);


--
-- Name: donation_payments donation_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payments
    ADD CONSTRAINT donation_payments_pkey PRIMARY KEY (id);


--
-- Name: donation_settings donation_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_settings
    ADD CONSTRAINT donation_settings_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: guardian_comments guardian_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_comments
    ADD CONSTRAINT guardian_comments_pkey PRIMARY KEY (id);


--
-- Name: guardian_registration_tokens guardian_registration_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_registration_tokens
    ADD CONSTRAINT guardian_registration_tokens_pkey PRIMARY KEY (id);


--
-- Name: guardians guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardians
    ADD CONSTRAINT guardians_pkey PRIMARY KEY (id);


--
-- Name: levels levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.levels
    ADD CONSTRAINT levels_pkey PRIMARY KEY (id);


--
-- Name: period_report_observations period_report_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period_report_observations
    ADD CONSTRAINT period_report_observations_pkey PRIMARY KEY (id);


--
-- Name: registration_settings registration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_settings
    ADD CONSTRAINT registration_settings_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: student_comments student_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_comments
    ADD CONSTRAINT student_comments_pkey PRIMARY KEY (id);


--
-- Name: student_donations student_donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_donations
    ADD CONSTRAINT student_donations_pkey PRIMARY KEY (id);


--
-- Name: student_guardians student_guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_pkey PRIMARY KEY (id);


--
-- Name: student_status_events student_status_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_status_events
    ADD CONSTRAINT student_status_events_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: year_report_observations year_report_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.year_report_observations
    ADD CONSTRAINT year_report_observations_pkey PRIMARY KEY (id);


--
-- Name: Account_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Account_userId_idx" ON public."Account" USING btree ("userId");


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Verification_identifier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Verification_identifier_idx" ON public."Verification" USING btree (identifier);


--
-- Name: academic_years_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX academic_years_name_key ON public.academic_years USING btree (name);


--
-- Name: attendance_classId_sessionId_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attendance_classId_sessionId_date_idx" ON public.attendance USING btree ("classId", "sessionId", date);


--
-- Name: attendance_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attendance_recordedById_idx" ON public.attendance USING btree ("recordedById");


--
-- Name: attendance_studentId_classId_sessionId_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "attendance_studentId_classId_sessionId_date_key" ON public.attendance USING btree ("studentId", "classId", "sessionId", date);


--
-- Name: attendance_studentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attendance_studentId_idx" ON public.attendance USING btree ("studentId");


--
-- Name: class_comments_authorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "class_comments_authorId_idx" ON public.class_comments USING btree ("authorId");


--
-- Name: class_comments_classId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "class_comments_classId_idx" ON public.class_comments USING btree ("classId");


--
-- Name: class_session_links_classId_sessionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "class_session_links_classId_sessionId_key" ON public.class_session_links USING btree ("classId", "sessionId");


--
-- Name: class_session_links_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "class_session_links_sessionId_idx" ON public.class_session_links USING btree ("sessionId");


--
-- Name: class_sessions_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX class_sessions_label_key ON public.class_sessions USING btree (label);


--
-- Name: classes_levelId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "classes_levelId_idx" ON public.classes USING btree ("levelId");


--
-- Name: classes_roomId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "classes_roomId_idx" ON public.classes USING btree ("roomId");


--
-- Name: classes_teacherId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "classes_teacherId_idx" ON public.classes USING btree ("teacherId");


--
-- Name: donation_payment_logs_actorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payment_logs_actorId_idx" ON public.donation_payment_logs USING btree ("actorId");


--
-- Name: donation_payment_logs_paymentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payment_logs_paymentId_idx" ON public.donation_payment_logs USING btree ("paymentId");


--
-- Name: donation_payment_logs_studentId_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payment_logs_studentId_academicYearId_idx" ON public.donation_payment_logs USING btree ("studentId", "academicYearId");


--
-- Name: donation_payments_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payments_academicYearId_idx" ON public.donation_payments USING btree ("academicYearId");


--
-- Name: donation_payments_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payments_recordedById_idx" ON public.donation_payments USING btree ("recordedById");


--
-- Name: donation_payments_studentId_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donation_payments_studentId_academicYearId_idx" ON public.donation_payments USING btree ("studentId", "academicYearId");


--
-- Name: enrollments_classId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "enrollments_classId_idx" ON public.enrollments USING btree ("classId");


--
-- Name: enrollments_studentId_classId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "enrollments_studentId_classId_key" ON public.enrollments USING btree ("studentId", "classId");


--
-- Name: exams_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_academicYearId_idx" ON public.exams USING btree ("academicYearId");


--
-- Name: exams_classId_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_classId_academicYearId_idx" ON public.exams USING btree ("classId", "academicYearId");


--
-- Name: exams_classId_termId_subjectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_classId_termId_subjectId_idx" ON public.exams USING btree ("classId", "termId", "subjectId");


--
-- Name: exams_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_recordedById_idx" ON public.exams USING btree ("recordedById");


--
-- Name: exams_subjectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_subjectId_idx" ON public.exams USING btree ("subjectId");


--
-- Name: exams_termId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "exams_termId_idx" ON public.exams USING btree ("termId");


--
-- Name: grades_examId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grades_examId_idx" ON public.grades USING btree ("examId");


--
-- Name: grades_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grades_recordedById_idx" ON public.grades USING btree ("recordedById");


--
-- Name: grades_studentId_examId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "grades_studentId_examId_key" ON public.grades USING btree ("studentId", "examId");


--
-- Name: grades_studentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grades_studentId_idx" ON public.grades USING btree ("studentId");


--
-- Name: guardian_comments_authorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "guardian_comments_authorId_idx" ON public.guardian_comments USING btree ("authorId");


--
-- Name: guardian_comments_guardianId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "guardian_comments_guardianId_idx" ON public.guardian_comments USING btree ("guardianId");


--
-- Name: guardian_registration_tokens_guardianId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "guardian_registration_tokens_guardianId_idx" ON public.guardian_registration_tokens USING btree ("guardianId");


--
-- Name: guardian_registration_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX guardian_registration_tokens_token_key ON public.guardian_registration_tokens USING btree (token);


--
-- Name: guardians_archivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "guardians_archivedAt_idx" ON public.guardians USING btree ("archivedAt");


--
-- Name: guardians_donationNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "guardians_donationNumber_key" ON public.guardians USING btree ("donationNumber");


--
-- Name: guardians_educationNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "guardians_educationNumber_key" ON public.guardians USING btree ("educationNumber");


--
-- Name: guardians_lastName_firstName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "guardians_lastName_firstName_idx" ON public.guardians USING btree ("lastName", "firstName");


--
-- Name: guardians_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardians_status_idx ON public.guardians USING btree (status);


--
-- Name: levels_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX levels_name_key ON public.levels USING btree (name);


--
-- Name: period_report_observations_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "period_report_observations_academicYearId_idx" ON public.period_report_observations USING btree ("academicYearId");


--
-- Name: period_report_observations_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "period_report_observations_recordedById_idx" ON public.period_report_observations USING btree ("recordedById");


--
-- Name: period_report_observations_studentId_termId_academicYearId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "period_report_observations_studentId_termId_academicYearId_key" ON public.period_report_observations USING btree ("studentId", "termId", "academicYearId");


--
-- Name: period_report_observations_termId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "period_report_observations_termId_idx" ON public.period_report_observations USING btree ("termId");


--
-- Name: rooms_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX rooms_name_key ON public.rooms USING btree (name);


--
-- Name: student_comments_authorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_comments_authorId_idx" ON public.student_comments USING btree ("authorId");


--
-- Name: student_comments_studentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_comments_studentId_idx" ON public.student_comments USING btree ("studentId");


--
-- Name: student_donations_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_donations_academicYearId_idx" ON public.student_donations USING btree ("academicYearId");


--
-- Name: student_donations_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_donations_recordedById_idx" ON public.student_donations USING btree ("recordedById");


--
-- Name: student_donations_studentId_academicYearId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "student_donations_studentId_academicYearId_key" ON public.student_donations USING btree ("studentId", "academicYearId");


--
-- Name: student_guardians_guardianId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_guardians_guardianId_idx" ON public.student_guardians USING btree ("guardianId");


--
-- Name: student_guardians_studentId_guardianId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "student_guardians_studentId_guardianId_key" ON public.student_guardians USING btree ("studentId", "guardianId");


--
-- Name: student_status_events_changedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_status_events_changedById_idx" ON public.student_status_events USING btree ("changedById");


--
-- Name: student_status_events_studentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_status_events_studentId_idx" ON public.student_status_events USING btree ("studentId");


--
-- Name: students_archivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "students_archivedAt_idx" ON public.students USING btree ("archivedAt");


--
-- Name: students_lastName_firstName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "students_lastName_firstName_idx" ON public.students USING btree ("lastName", "firstName");


--
-- Name: students_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_status_idx ON public.students USING btree (status);


--
-- Name: subjects_levelId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "subjects_levelId_idx" ON public.subjects USING btree ("levelId");


--
-- Name: subjects_levelId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "subjects_levelId_name_key" ON public.subjects USING btree ("levelId", name);


--
-- Name: terms_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX terms_name_key ON public.terms USING btree (name);


--
-- Name: terms_sortOrder_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "terms_sortOrder_key" ON public.terms USING btree ("sortOrder");


--
-- Name: year_report_observations_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "year_report_observations_academicYearId_idx" ON public.year_report_observations USING btree ("academicYearId");


--
-- Name: year_report_observations_recordedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "year_report_observations_recordedById_idx" ON public.year_report_observations USING btree ("recordedById");


--
-- Name: year_report_observations_studentId_academicYearId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "year_report_observations_studentId_academicYearId_key" ON public.year_report_observations USING btree ("studentId", "academicYearId");


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendance attendance_classId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT "attendance_classId_fkey" FOREIGN KEY ("classId") REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendance attendance_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT "attendance_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: attendance attendance_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT "attendance_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.class_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: attendance attendance_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT "attendance_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_comments class_comments_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_comments
    ADD CONSTRAINT "class_comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: class_comments class_comments_classId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_comments
    ADD CONSTRAINT "class_comments_classId_fkey" FOREIGN KEY ("classId") REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_session_links class_session_links_classId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_session_links
    ADD CONSTRAINT "class_session_links_classId_fkey" FOREIGN KEY ("classId") REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_session_links class_session_links_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_session_links
    ADD CONSTRAINT "class_session_links_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.class_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: classes classes_levelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT "classes_levelId_fkey" FOREIGN KEY ("levelId") REFERENCES public.levels(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: classes classes_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT "classes_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: classes classes_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT "classes_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: donation_payment_logs donation_payment_logs_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payment_logs
    ADD CONSTRAINT "donation_payment_logs_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: donation_payment_logs donation_payment_logs_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payment_logs
    ADD CONSTRAINT "donation_payment_logs_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: donation_payment_logs donation_payment_logs_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payment_logs
    ADD CONSTRAINT "donation_payment_logs_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.donation_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: donation_payment_logs donation_payment_logs_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payment_logs
    ADD CONSTRAINT "donation_payment_logs_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: donation_payments donation_payments_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payments
    ADD CONSTRAINT "donation_payments_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: donation_payments donation_payments_studentId_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_payments
    ADD CONSTRAINT "donation_payments_studentId_academicYearId_fkey" FOREIGN KEY ("studentId", "academicYearId") REFERENCES public.student_donations("studentId", "academicYearId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollments enrollments_classId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT "enrollments_classId_fkey" FOREIGN KEY ("classId") REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollments enrollments_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT "enrollments_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exams exams_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: exams exams_classId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_classId_fkey" FOREIGN KEY ("classId") REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exams exams_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: exams exams_subjectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_subjectId_fkey" FOREIGN KEY ("subjectId") REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: exams exams_termId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_termId_fkey" FOREIGN KEY ("termId") REFERENCES public.terms(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: grades grades_examId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT "grades_examId_fkey" FOREIGN KEY ("examId") REFERENCES public.exams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grades grades_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT "grades_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: grades grades_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT "grades_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guardian_comments guardian_comments_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_comments
    ADD CONSTRAINT "guardian_comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: guardian_comments guardian_comments_guardianId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_comments
    ADD CONSTRAINT "guardian_comments_guardianId_fkey" FOREIGN KEY ("guardianId") REFERENCES public.guardians(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guardian_registration_tokens guardian_registration_tokens_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_registration_tokens
    ADD CONSTRAINT "guardian_registration_tokens_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: guardian_registration_tokens guardian_registration_tokens_guardianId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_registration_tokens
    ADD CONSTRAINT "guardian_registration_tokens_guardianId_fkey" FOREIGN KEY ("guardianId") REFERENCES public.guardians(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: period_report_observations period_report_observations_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period_report_observations
    ADD CONSTRAINT "period_report_observations_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: period_report_observations period_report_observations_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period_report_observations
    ADD CONSTRAINT "period_report_observations_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: period_report_observations period_report_observations_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period_report_observations
    ADD CONSTRAINT "period_report_observations_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: period_report_observations period_report_observations_termId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period_report_observations
    ADD CONSTRAINT "period_report_observations_termId_fkey" FOREIGN KEY ("termId") REFERENCES public.terms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_comments student_comments_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_comments
    ADD CONSTRAINT "student_comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: student_comments student_comments_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_comments
    ADD CONSTRAINT "student_comments_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_donations student_donations_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_donations
    ADD CONSTRAINT "student_donations_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_donations student_donations_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_donations
    ADD CONSTRAINT "student_donations_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: student_donations student_donations_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_donations
    ADD CONSTRAINT "student_donations_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_guardianId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT "student_guardians_guardianId_fkey" FOREIGN KEY ("guardianId") REFERENCES public.guardians(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT "student_guardians_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_status_events student_status_events_changedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_status_events
    ADD CONSTRAINT "student_status_events_changedById_fkey" FOREIGN KEY ("changedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: student_status_events student_status_events_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_status_events
    ADD CONSTRAINT "student_status_events_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subjects subjects_levelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT "subjects_levelId_fkey" FOREIGN KEY ("levelId") REFERENCES public.levels(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: year_report_observations year_report_observations_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.year_report_observations
    ADD CONSTRAINT "year_report_observations_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: year_report_observations year_report_observations_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.year_report_observations
    ADD CONSTRAINT "year_report_observations_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: year_report_observations year_report_observations_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.year_report_observations
    ADD CONSTRAINT "year_report_observations_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xaZQXDBDVVoh9zKwMdy0ZLTpmlaecfYRZqMoRCEOFsyhI2B7ErakRjPv1PSA2Kr

